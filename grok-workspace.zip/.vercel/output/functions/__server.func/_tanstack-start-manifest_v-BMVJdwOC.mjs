//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BMVJdwOC.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BS5j7iQZ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BS5j7iQZ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Bd76kGVR.js"]
	}
} });
//#endregion
export { tsrStartManifest };
