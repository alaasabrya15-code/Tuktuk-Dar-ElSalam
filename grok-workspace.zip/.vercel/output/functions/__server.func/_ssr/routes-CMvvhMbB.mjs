import { i as __toESM } from "../_runtime.mjs";
import { G as require_jsx_runtime, K as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Timer, c as Pause, d as Gauge, f as Fuel, h as ChevronLeft, l as Megaphone, m as ChevronRight, n as VolumeX, o as RotateCcw, p as Flag, r as Volume2, s as Play, t as Wallet, u as MapPin } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CMvvhMbB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var VEHICLES = [
	{
		id: "malaky",
		name: "ملاكي",
		blurb: "عدّى بسرعة",
		max: 32,
		accel: 15,
		brake: 28,
		turn: 1.55,
		width: 1.8,
		length: 4.4,
		seats: 3,
		fare: 1,
		freight: 0,
		speed: 4,
		grip: 4,
		haul: 2
	},
	{
		id: "taxi",
		name: "تاكسي",
		blurb: "واقف على الخط",
		max: 30,
		accel: 14,
		brake: 26,
		turn: 1.5,
		width: 1.8,
		length: 4.5,
		seats: 3,
		fare: 1.3,
		freight: 0,
		speed: 4,
		grip: 3,
		haul: 3
	},
	{
		id: "micro",
		name: "ميكروباص",
		blurb: "بيقف فجأة",
		max: 24,
		accel: 11,
		brake: 18,
		turn: 1.15,
		width: 2.1,
		length: 5.1,
		seats: 11,
		fare: 1,
		freight: 0,
		speed: 3,
		grip: 2,
		haul: 5
	},
	{
		id: "tuktuk",
		name: "توكتوك",
		blurb: "بتاع الشارع",
		max: 17,
		accel: 15,
		brake: 26,
		turn: 2.65,
		width: 1.35,
		length: 2.55,
		seats: 2,
		fare: .9,
		freight: 0,
		speed: 2,
		grip: 5.4,
		haul: 1
	},
	{
		id: "truck",
		name: "نقل",
		blurb: "خد بالك منه",
		max: 20,
		accel: 7,
		brake: 12,
		turn: .85,
		width: 2.45,
		length: 8.4,
		seats: 0,
		fare: 0,
		freight: 0,
		speed: 2,
		grip: 1,
		haul: 5
	}
];
var PAINTS = [
	{
		id: "yellow",
		hex: "#f0b429",
		name: "أصفر",
		swatch: "bg-amber"
	},
	{
		id: "nile",
		hex: "#1aa6a6",
		name: "زيتي",
		swatch: "bg-nile"
	},
	{
		id: "brick",
		hex: "#d4654a",
		name: "أحمر",
		swatch: "bg-brick"
	},
	{
		id: "white",
		hex: "#f4f1ea",
		name: "أبيض",
		swatch: "bg-ink"
	},
	{
		id: "soot",
		hex: "#2a3340",
		name: "فحمي",
		swatch: "bg-panel-2"
	}
];
var MODES = [
	{
		id: "shift",
		name: "وردية",
		blurb: "سدّد إيجار اليوم"
	},
	{
		id: "rush",
		name: "توصيلات",
		blurb: "أربع مشاوير على الساعة"
	},
	{
		id: "cruise",
		name: "فضاوة",
		blurb: "لف في الحتة"
	}
];
var DENSITIES = [
	{
		id: 0,
		name: "سالكة"
	},
	{
		id: 1,
		name: "زحمة"
	},
	{
		id: 2,
		name: "واقفة"
	}
];
var UPGRADES = [
	{
		id: "motor",
		name: "موتور",
		blurb: "يمشي أسرع",
		max: 3,
		costs: [
			80,
			160,
			280
		]
	},
	{
		id: "fuel",
		name: "بنزين أوفر",
		blurb: "التانك يطول",
		max: 3,
		costs: [
			70,
			140,
			240
		]
	},
	{
		id: "seats",
		name: "فرش",
		blurb: "الأجرة أعلى",
		max: 3,
		costs: [
			90,
			180,
			300
		]
	},
	{
		id: "tires",
		name: "كاوتش",
		blurb: "يلف في الزحمة",
		max: 3,
		costs: [
			60,
			130,
			220
		]
	}
];
var STOP_NAMES = [
	"كوبري دار السلام",
	"موقف الميكروباص",
	"سنترال دار السلام",
	"الإدارة التعليمية",
	"مجمع المدارس",
	"مدرسة جمال عبد الناصر",
	"محطة مترو دار السلام",
	"مكتب الصحة",
	"مكتب البريد",
	"الفرن البلدي",
	"قهوة الحج علي",
	"سناتر الدروس",
	"شارع المحجر",
	"دوران أحمد زكي"
];
function vehicleById(id) {
	return VEHICLES.find((v) => v.id === id) ?? VEHICLES[3];
}
var INITIAL = {
	mode: "shift",
	vehicle: "tuktuk",
	night: false,
	density: 1,
	paint: "#f0b429",
	sound: true
};
function formatTime(t) {
	const m = Math.floor(Math.max(0, t) / 60);
	const s = Math.floor(Math.max(0, t) % 60);
	return `${m}:${String(s).padStart(2, "0")}`;
}
function DarSalam() {
	const viewRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const gameRef = (0, import_react.useRef)(null);
	const holds = (0, import_react.useRef)({
		l: false,
		r: false,
		g: false,
		b: false
	});
	const [ready, setReady] = (0, import_react.useState)(false);
	const [cfg, setCfg] = (0, import_react.useState)(INITIAL);
	const [snap, setSnap] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const canvas = viewRef.current;
		const map = mapRef.current;
		if (!canvas || !map) return;
		let dead = false;
		let handle = null;
		import("./engine-y1-E5DBT.mjs").then(({ mountGame }) => {
			if (dead) return;
			handle = mountGame(canvas, map, setSnap);
			gameRef.current = handle;
			const heard = handle.getHud();
			setCfg((c) => ({
				...c,
				sound: heard.sound
			}));
			setReady(true);
		});
		return () => {
			dead = true;
			handle?.dispose();
			gameRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		gameRef.current?.setPreview(cfg);
	}, [cfg]);
	const phase = snap?.phase ?? "menu";
	const syncTouch = () => {
		const h = holds.current;
		const steer = (h.l ? 1 : 0) + (h.r ? -1 : 0);
		gameRef.current?.setTouch({
			steer,
			throttle: h.g ? 1 : 0,
			brake: h.b ? 1 : 0
		});
	};
	const hold = (key) => ({
		onPointerDown: (e) => {
			e.preventDefault();
			e.currentTarget.setPointerCapture(e.pointerId);
			holds.current[key] = true;
			syncTouch();
		},
		onPointerUp: () => {
			holds.current[key] = false;
			syncTouch();
		},
		onPointerCancel: () => {
			holds.current[key] = false;
			syncTouch();
		},
		onLostPointerCapture: () => {
			holds.current[key] = false;
			syncTouch();
		}
	});
	const patch = (partial) => setCfg((c) => ({
		...c,
		...partial
	}));
	const startLabel = cfg.mode === "rush" ? "ابدأ التوصيلات" : cfg.mode === "cruise" ? "انزل الشارع" : "ابدأ الوردية";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative h-dvh w-full overflow-hidden bg-asphalt font-sans text-ink touch-none select-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: viewRef,
				className: "absolute inset-0 h-full w-full"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: mapRef,
				width: 180,
				height: 180,
				className: phase === "play" || phase === "pause" ? "absolute top-2 left-1/2 z-20 h-14 w-14 -translate-x-1/2 rounded-full border border-line md:top-4 md:h-24 md:w-24" : "pointer-events-none absolute h-px w-px opacity-0"
			}),
			snap?.alert === "radar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 z-10 bg-brick/25" }) : null,
			snap?.alert === "crash" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 z-10 bg-brick/35" }) : null,
			snap?.lowFuel && phase === "play" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 z-10 bg-brick/15" }) : null,
			phase === "menu" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-end justify-center p-3 sm:items-center sm:p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex max-h-full w-full max-w-xl flex-col overflow-hidden rounded-2xl border border-line bg-panel/95 shadow-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1.5 bg-amber" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "overflow-y-auto p-4 sm:p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-bold text-brick",
									children: "شارع الفيوم · حي دار السلام · القاهرة"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "mt-1 text-3xl font-extrabold leading-tight sm:text-4xl",
									children: "توكتوك دار السلام"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm leading-relaxed text-muted",
									children: "الشارع من كوبري دار السلام — الزحمة فوقه والميكروباصات تحته على خطوط السيدة زينب والجيزة والزهراء والمعادي والهرم — لحد دوران أحمد زكي. باعة وإشغالات داخلة على الحارة اليمين، كوبري مشاة ناحية السوق، عمارات بلبان وهدوم منشورة، سنترال ومترو ومجمع مدارس وسناتر ومكتب صحة وبريد. المطبات والكمين في كل حتة، والناس بتعدّي بين العربيات. خد بالك من الميكروباص اللي بيقف فجأة."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 grid grid-cols-3 gap-2",
									children: MODES.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => patch({ mode: m.id }),
										className: cfg.mode === m.id ? "rounded-xl bg-amber px-2 py-3 text-amber-ink" : "rounded-xl bg-panel-2 px-2 py-3 text-ink",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-sm font-extrabold",
											children: m.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "mt-1 block text-xs leading-snug opacity-80",
											children: m.blurb
										})]
									}, m.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-xs font-bold text-muted",
									children: "لون التوكتوك"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap items-center gap-2",
									children: PAINTS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": p.name,
										onClick: () => patch({ paint: p.hex }),
										className: cfg.paint === p.hex ? `h-11 w-11 rounded-full border-2 border-ink ${p.swatch}` : `h-11 w-11 rounded-full border-2 border-line ${p.swatch}`
									}, p.id))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex flex-wrap items-center gap-2",
									children: [
										DENSITIES.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => patch({ density: d.id }),
											className: cfg.density === d.id ? "rounded-full bg-nile px-3 py-2 text-xs font-bold text-asphalt" : "rounded-full bg-panel-2 px-3 py-2 text-xs font-bold text-ink",
											children: d.name
										}, d.id)),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => patch({ night: !cfg.night }),
											className: "rounded-full bg-panel-2 px-3 py-2 text-xs font-bold",
											children: cfg.night ? "ليل الحتة" : "الضهر"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => patch({ sound: !cfg.sound }),
											className: "rounded-full bg-panel-2 p-2",
											"aria-label": cfg.sound ? "كتم الصوت" : "تشغيل الصوت",
											children: cfg.sound ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-5" })
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-extrabold",
										children: "الورشة"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-1 text-sm font-extrabold text-amber",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wallet, { className: "size-4" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												dir: "ltr",
												children: snap?.wallet ?? 0
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs font-bold text-muted",
												children: "ج"
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 grid grid-cols-2 gap-2",
									children: UPGRADES.map((u) => {
										const lvl = snap?.upgrades[u.id] ?? 0;
										const maxed = lvl >= u.max;
										const cost = u.costs[lvl] ?? 0;
										const afford = (snap?.wallet ?? 0) >= cost;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											disabled: !ready || maxed || !afford,
											onClick: () => gameRef.current?.buy(u.id),
											className: "rounded-xl bg-panel-2 px-3 py-2 text-right disabled:opacity-45",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center justify-between gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-sm font-extrabold",
														children: u.name
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-xs font-bold text-amber",
														children: maxed ? "كامل" : `${cost} ج`
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-0.5 block text-xs text-muted",
													children: u.blurb
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-2 flex gap-1",
													children: Array.from({ length: u.max }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: i < lvl ? "h-1.5 flex-1 rounded-full bg-amber" : "h-1.5 flex-1 rounded-full bg-line" }, i))
												})
											]
										}, u.id);
									})
								}),
								snap && (snap.bestMoney > 0 || snap.bestKm > 0 || snap.bestTrial != null) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-xs leading-relaxed text-muted",
									children: [
										"أحسن وردية ",
										snap.bestMoney,
										" ج · أطول لفة ",
										snap.bestKm,
										" كم",
										snap.bestTrial != null ? ` · أسرع توصيلات ${formatTime(snap.bestTrial)}` : ""
									]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 text-center text-xs leading-relaxed text-muted",
									children: [
										"كمبيوتر: W بنزين · S فرامل · A شمال · D يمين · H كلاكس · C كاميرا",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"الإيجار ",
										160,
										" ج في ٣ دقايق · التانك ",
										22,
										" ج يمين الشارع"
									]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "border-t border-line p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: !ready,
								onClick: () => gameRef.current?.start(cfg),
								className: "w-full rounded-xl bg-amber py-3 text-lg font-extrabold text-amber-ink disabled:opacity-60",
								children: ready ? startLabel : "لحظة، بنجهّز التوكتوك"
							})
						})
					]
				})
			}) : null,
			phase !== "menu" && snap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayHud, {
				snap,
				hold,
				game: gameRef,
				onAgain: () => gameRef.current?.start(cfg)
			}) : null
		]
	});
}
function PlayHud({ snap, hold, game, onAgain }) {
	const shift = snap.mode === "shift";
	const rush = snap.mode === "rush";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-2 p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto w-32 rounded-2xl border border-line bg-panel/90 px-3 py-2 sm:w-40",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gauge, { className: "size-3.5 text-amber" }), "كم/س"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						dir: "ltr",
						className: "text-3xl font-extrabold leading-none tabular-nums",
						children: snap.speed
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-center gap-1 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Fuel, { className: snap.lowFuel ? "size-3.5 text-brick" : "size-3.5 text-amber" }), "بنزين"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 h-1.5 overflow-hidden rounded-full bg-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: snap.lowFuel ? "h-full bg-brick" : "h-full bg-nile",
							style: { width: `${Math.max(0, Math.min(100, snap.fuel))}%` }
						})
					}),
					shift ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-lg font-extrabold tabular-nums",
							dir: "ltr",
							children: [
								snap.money,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold text-muted",
									children: "ج"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-1 h-1.5 overflow-hidden rounded-full bg-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-amber",
								style: { width: `${Math.min(100, snap.money / snap.rent * 100)}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 flex items-center gap-1 text-xs text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-3.5 text-amber" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									dir: "ltr",
									children: formatTime(snap.shiftLeft)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["· إيجار ", snap.rent] })
							]
						})
					] }) : rush ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-lg font-extrabold tabular-nums",
						dir: "ltr",
						children: [
							snap.jobsDone,
							"/",
							snap.jobsNeed || 4
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 flex items-center gap-1 text-sm font-extrabold tabular-nums",
						dir: "ltr",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Timer, { className: "size-3.5 text-amber" }), formatTime(snap.time)]
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-lg font-extrabold tabular-nums",
						dir: "ltr",
						children: [
							snap.money,
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-bold text-muted",
								children: "ج"
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [snap.km, " كم"]
					})] }),
					snap.seats > 0 && !rush ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 truncate text-xs text-muted",
						children: [
							"ركاب ",
							snap.passengers.length,
							"/",
							snap.seats,
							snap.passengers[0] ? ` · ${snap.passengers[0].dest}` : ""
						]
					}) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-auto w-32 rounded-2xl border border-line bg-panel/90 px-3 py-2 sm:w-40",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1 text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-nile" }), rush ? "التوصيلة" : "النزلة"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-base font-extrabold leading-snug",
						children: rush ? snap.jobName : snap.stopName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						dir: "ltr",
						className: "text-sm font-bold text-amber tabular-nums",
						children: [snap.stopDist, " m"]
					}),
					snap.hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs font-bold text-amber",
						children: snap.hint
					}) : null
				]
			})]
		}),
		snap.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "pointer-events-none absolute bottom-52 left-1/2 z-20 w-max max-w-[90%] -translate-x-1/2 rounded-full bg-asphalt/80 px-4 py-2 text-center text-sm font-bold md:bottom-24",
			children: snap.message
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute bottom-36 left-1/2 z-30 flex -translate-x-1/2 gap-2 md:bottom-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded-full bg-panel/90 p-3",
					"aria-label": "إيقاف",
					onClick: () => snap.phase === "pause" ? game.current?.resume() : game.current?.pause(),
					children: snap.phase === "pause" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded-full bg-panel/90 p-3",
					"aria-label": "كلاكس",
					onClick: () => game.current?.horn(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Megaphone, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "rounded-full bg-panel/90 px-3 py-2 text-xs font-bold",
					onClick: () => game.current?.cycleCam(),
					children: "كاميرا"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			dir: "ltr",
			className: "absolute inset-x-0 bottom-4 z-30 flex items-end justify-between px-3 md:hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-16 w-16 touch-none rounded-2xl bg-panel/90 text-ink",
					"aria-label": "يسار",
					...hold("l"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "mx-auto size-8" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-16 w-16 touch-none rounded-2xl bg-panel/90 text-ink",
					"aria-label": "يمين",
					...hold("r"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "mx-auto size-8" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-16 w-20 touch-none rounded-2xl bg-panel-2 text-sm font-extrabold",
					...hold("b"),
					children: "فرامل"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-16 w-20 touch-none rounded-2xl bg-amber text-sm font-extrabold text-amber-ink",
					...hold("g"),
					children: "بنزين"
				})]
			})]
		}),
		snap.phase === "pause" || snap.phase === "summary" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute inset-0 z-40 flex items-center justify-center bg-asphalt/75 p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "w-full max-w-sm rounded-2xl border border-line bg-panel p-5 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-2xl font-extrabold text-amber",
						children: snap.phase === "pause" ? "وقفة" : rush ? "التوصيلات" : shift ? "خلصت الوردية" : "خلصت اللفة"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-4 space-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: rush ? "المشاوير" : "المكسب"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-extrabold",
									children: rush ? `${snap.jobsDone}/${snap.jobsNeed}` : `${snap.money} ج`
								})]
							}),
							shift ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "الإيجار"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-extrabold",
									children: [snap.rent, " ج"]
								})]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "المحفظة"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-extrabold",
									children: [snap.wallet, " ج"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "المسافة"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-extrabold",
									children: [snap.km, " كم"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "الوقت"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-extrabold",
									dir: "ltr",
									children: formatTime(snap.time)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "الخبطات"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-extrabold",
									children: snap.crashes
								})]
							})
						]
					}),
					snap.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm font-bold text-amber",
						children: snap.message
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 flex gap-2",
						children: [
							snap.phase === "pause" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex flex-1 items-center justify-center gap-2 rounded-xl bg-amber py-3 font-extrabold text-amber-ink",
								onClick: () => game.current?.resume(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), "كمّل"]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex flex-1 items-center justify-center gap-2 rounded-xl bg-amber py-3 font-extrabold text-amber-ink",
								onClick: onAgain,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "تاني"]
							}),
							snap.phase === "pause" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "flex flex-1 items-center justify-center gap-2 rounded-xl bg-panel-2 py-3 font-bold",
								onClick: () => game.current?.finish(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "size-4" }), "خلّص"]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "flex-1 rounded-xl bg-panel-2 py-3 font-bold",
								onClick: () => game.current?.quit(),
								children: "القائمة"
							})
						]
					})
				]
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "absolute bottom-6 left-4 z-20 hidden rounded-full bg-panel/80 px-4 py-2 text-xs font-bold text-muted md:block",
			onClick: () => game.current?.finish(),
			children: "خلّص المشوار"
		})
	] });
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => SplitComponent });
var SplitComponent = DarSalam;
//#endregion
export { vehicleById as i, STOP_NAMES as n, UPGRADES as r, routes_exports as t };
