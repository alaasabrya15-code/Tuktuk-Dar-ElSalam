import { i as vehicleById, n as STOP_NAMES, r as UPGRADES } from "./routes-CMvvhMbB.mjs";
import { A as Scene, C as Object3D, D as PointsMaterial, E as Points, M as SpotLight, N as Vector3, O as RepeatWrapping, S as MeshStandardMaterial, T as PlaneGeometry, _ as InstancedMesh, a as BufferGeometry, b as Mesh, c as CircleGeometry, d as CylinderGeometry, f as DirectionalLight, g as HemisphereLight, h as Group, i as BufferAttribute, j as SphereGeometry, k as SRGBColorSpace, l as Color, m as Fog, n as WebGLRenderer, o as CanvasTexture, p as Float32BufferAttribute, r as BoxGeometry, s as CapsuleGeometry, t as mergeGeometries, u as ConeGeometry, v as LineBasicMaterial, w as PerspectiveCamera, x as MeshBasicMaterial, y as LineSegments } from "../_libs/three.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/engine-y1-E5DBT.js
var LANE_W = 3.45;
var ROAD_HALF = 8.15;
function laneLat(lane) {
	return (lane - 1.5) * LANE_W;
}
function wrapDelta(a, b, total) {
	let d = a - b;
	const h = total * .5;
	while (d > h) d -= total;
	while (d < -h) d += total;
	return d;
}
function wrapAngle(d) {
	while (d > Math.PI) d -= Math.PI * 2;
	while (d < -Math.PI) d += Math.PI * 2;
	return d;
}
function buildTrack() {
	const straight = 680;
	const radius = 34;
	const segStraight = 190;
	const segArc = 32;
	const raw = [];
	for (let i = 0; i <= segStraight; i++) {
		const u = i / segStraight;
		const wob = Math.sin(u * Math.PI) * (Math.sin(u * Math.PI * 4) * 2.1 + Math.sin(u * Math.PI * 9) * .55);
		raw.push({
			x: -34 + wob,
			z: -340 + u * straight
		});
	}
	for (let i = 1; i <= segArc; i++) {
		const ang = Math.PI - i / segArc * Math.PI;
		raw.push({
			x: Math.cos(ang) * radius,
			z: straight / 2 + Math.sin(ang) * radius
		});
	}
	for (let i = 1; i <= segStraight; i++) {
		const u = i / segStraight;
		const wob = Math.sin(u * Math.PI) * (Math.sin(u * Math.PI * 3.5 + .6) * 1.8);
		raw.push({
			x: radius + wob,
			z: straight / 2 - u * straight
		});
	}
	for (let i = 1; i < segArc; i++) {
		const ang = -(i / segArc) * Math.PI;
		raw.push({
			x: Math.cos(ang) * radius,
			z: -340 + Math.sin(ang) * radius
		});
	}
	const pts = [];
	let s = 0;
	const N = raw.length;
	for (let i = 0; i < N; i++) {
		const a = raw[i];
		const b = raw[(i + 1) % N];
		const dx = b.x - a.x;
		const dz = b.z - a.z;
		const len = Math.hypot(dx, dz) || .001;
		const yaw = Math.atan2(-dx / len, -dz / len);
		pts.push({
			x: a.x,
			z: a.z,
			s,
			yaw,
			len
		});
		s += len;
	}
	const total = s;
	const stops = STOP_NAMES.map((name, i) => ({
		name,
		s: (i + .06) / STOP_NAMES.length * total
	}));
	const tollS = stops[0].s + 6;
	const radarS = [
		.16,
		.41,
		.73
	].map((t) => t * total);
	const gasS = total * .58;
	const bumps = [
		.11,
		.28,
		.47,
		.66,
		.84
	].map((t) => t * total);
	function sample(dist) {
		let sDist = dist % total;
		if (sDist < 0) sDist += total;
		let lo = 0;
		let hi = pts.length - 1;
		while (lo < hi) {
			const mid = lo + hi + 1 >> 1;
			if (pts[mid].s <= sDist) lo = mid;
			else hi = mid - 1;
		}
		const p = pts[lo];
		const n = pts[(lo + 1) % pts.length];
		const u = Math.min(1, Math.max(0, (sDist - p.s) / p.len));
		return {
			x: p.x + (n.x - p.x) * u,
			z: p.z + (n.z - p.z) * u,
			yaw: p.yaw,
			s: sDist
		};
	}
	function project(x, z, hint) {
		const scan = (from, count) => {
			let best = null;
			for (let k = 0; k < count; k++) {
				const i = (from + k + pts.length * 8) % pts.length;
				const p = pts[i];
				const n = pts[(i + 1) % pts.length];
				const dx = n.x - p.x;
				const dz = n.z - p.z;
				const l2 = dx * dx + dz * dz || 1;
				let t = ((x - p.x) * dx + (z - p.z) * dz) / l2;
				if (t < 0) t = 0;
				else if (t > 1) t = 1;
				const px = p.x + dx * t;
				const pz = p.z + dz * t;
				const dist = Math.hypot(x - px, z - pz);
				if (!best || dist < best.dist) {
					const rx = Math.cos(p.yaw);
					const rz = -Math.sin(p.yaw);
					best = {
						i,
						s: p.s + p.len * t,
						x: px,
						z: pz,
						yaw: p.yaw,
						lat: (x - px) * rx + (z - pz) * rz,
						dist
					};
				}
			}
			return best;
		};
		if (hint < 0) return scan(0, pts.length);
		const near = scan(hint - 30, 70);
		if (near.dist > 24) return scan(0, pts.length);
		return near;
	}
	return {
		pts,
		total,
		stops,
		tollS,
		radarS,
		gasS,
		bumps,
		sample,
		project
	};
}
var plasters = [
	"#d9c7a6",
	"#cbb496",
	"#e6d5b8",
	"#b9ad9a",
	"#c9a48c"
];
var signBands = [
	"#c0392b",
	"#1a5276",
	"#1e8449",
	"#b7950b",
	"#6c3483"
];
function texOf$1(c) {
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	tex.anisotropy = 8;
	return tex;
}
function pair(seed) {
	const face = document.createElement("canvas");
	face.width = 512;
	face.height = 1024;
	const glow = document.createElement("canvas");
	glow.width = 512;
	glow.height = 1024;
	const g = face.getContext("2d");
	const e = glow.getContext("2d");
	if (!g || !e) return null;
	g.fillStyle = plasters[seed % plasters.length];
	g.fillRect(0, 0, 512, 1024);
	e.fillStyle = "#000";
	e.fillRect(0, 0, 512, 1024);
	for (let i = 0; i < 220; i++) {
		g.fillStyle = `rgba(55,40,25,${.02 + i % 7 * .01})`;
		g.fillRect(i * 53 % 512, i * 97 % 820, 12 + i % 40, 6 + i % 22);
	}
	for (let i = 0; i < 18; i++) {
		const x = 20 + i * 97 % 470;
		g.fillStyle = `rgba(40,30,20,${.08 + i % 4 * .03})`;
		g.fillRect(x, 80 + i % 5 * 40, 3 + i % 3, 180 + i % 6 * 50);
	}
	g.fillStyle = "#9a4f3a";
	g.fillRect(0, 0, 512, 90);
	for (let y = 4; y < 86; y += 14) {
		g.fillStyle = y % 28 === 4 ? "#7e3e2e" : "#b05a45";
		g.fillRect(0, y, 512, 9);
		g.fillStyle = "#5e3024";
		g.fillRect(0, y + 9, 512, 3);
		for (let x = y % 28 === 4 ? 0 : 28; x < 512; x += 56) {
			g.fillStyle = "rgba(0,0,0,0.12)";
			g.fillRect(x, y, 2, 12);
		}
	}
	const floorH = 100;
	for (let f = 0; f < 8; f++) {
		const y = 100 + f * floorH;
		g.fillStyle = "rgba(55,48,40,0.55)";
		g.fillRect(8, y + 68, 496, 10);
		g.fillStyle = "#4a535a";
		g.fillRect(10, y + 42, 492, 3);
		for (let x = 16; x < 500; x += 10) g.fillRect(x, y + 42, 3, 26);
		for (let w = 0; w < 4; w++) {
			const x = 28 + w * 120;
			const wave = Math.sin(seed * 2.1 + f * 1.7 + w * 2.4);
			const lit = wave > .2;
			const open = wave < -.5;
			g.fillStyle = "#e8e0d2";
			g.fillRect(x - 4, y + 4, 72, 58);
			g.fillStyle = open ? "#4a6a78" : lit ? "#f5d9a8" : "#7a93a0";
			g.fillRect(x, y + 8, 64, 50);
			if (!open) {
				g.strokeStyle = "rgba(255,255,255,0.35)";
				g.lineWidth = 1.5;
				g.beginPath();
				g.moveTo(x + 32, y + 8);
				g.lineTo(x + 32, y + 58);
				g.moveTo(x, y + 33);
				g.lineTo(x + 64, y + 33);
				g.stroke();
			}
			if (lit && !open) {
				e.fillStyle = "#ffcc77";
				e.fillRect(x, y + 8, 64, 50);
			}
			if ((f + w + seed) % 3 === 0) {
				g.fillStyle = "#f0ebe3";
				g.fillRect(x + 68, y + 14, 28, 22);
				g.fillStyle = "#a8b0b8";
				g.fillRect(x + 70, y + 22, 24, 4);
				g.fillStyle = "rgba(0,0,0,0.25)";
				g.fillRect(x + 72, y + 16, 20, 3);
			}
			if ((f * 3 + w + seed) % 4 === 0) {
				const cloth = [
					"#c45c3e",
					"#1d4e89",
					"#f4f1ea",
					"#2f6b3a",
					"#222",
					"#d4a017"
				];
				g.fillStyle = cloth[(f + w) % cloth.length];
				g.fillRect(x + 4, y + 62, 16, 28);
				g.fillStyle = cloth[(f + w + 2) % cloth.length];
				g.fillRect(x + 24, y + 64, 14, 24);
				g.fillStyle = cloth[(f + w + 1) % cloth.length];
				g.fillRect(x + 42, y + 60, 12, 30);
			}
			g.fillStyle = `rgba(20,15,10,${.04 + (seed + f + w) % 3 * .02})`;
			g.fillRect(x + 4, y + 12, 56, 18);
		}
	}
	g.fillStyle = "#8a7a68";
	g.fillRect(0, 0, 512, 18);
	for (let i = 0; i < 4; i++) {
		const tx = 40 + i * 120 + seed % 30;
		g.fillStyle = "#c8c2b8";
		g.fillRect(tx, 8, 36, 28);
		g.fillStyle = "#9a948a";
		g.fillRect(tx + 4, 12, 28, 8);
		g.fillStyle = "#6a655c";
		g.fillRect(tx + 8, 28, 20, 6);
	}
	g.fillStyle = signBands[seed % signBands.length];
	g.fillRect(0, 820, 512, 48);
	g.fillStyle = "#f5f0e6";
	g.font = "bold 22px Tajawal, Arial";
	g.textAlign = "center";
	const shopNames = [
		"ميني ماركت",
		"مخبز",
		"صيدلية",
		"كوافير",
		"لحوم",
		"خضروات",
		"أدوات منزلية",
		"كافيه"
	];
	g.fillText(shopNames[seed % shopNames.length], 256, 852);
	g.fillStyle = "#161412";
	g.fillRect(0, 868, 512, 156);
	g.fillStyle = seed % 2 === 0 ? "#1a5c42" : "#3a4650";
	g.fillRect(24, 880, 210, 120);
	for (let y = 880; y < 1e3; y += 8) {
		g.fillStyle = "rgba(0,0,0,0.3)";
		g.fillRect(24, y, 210, 2);
	}
	g.fillStyle = "#0a0a0a";
	g.fillRect(90, 910, 70, 90);
	e.fillStyle = "#ffb15a";
	e.globalAlpha = .8;
	e.fillRect(100, 922, 50, 60);
	e.globalAlpha = 1;
	[
		"#e07a2f",
		"#f2c14e",
		"#d35400",
		"#8d6e63",
		"#27ae60",
		"#c0392b"
	].forEach((hex, i) => {
		g.fillStyle = hex;
		g.fillRect(260 + i * 38, 900 + i % 2 * 16, 32, 48 - i % 2 * 10);
	});
	for (let i = 0; i < 5; i++) {
		const ax = 30 + (i * 97 + seed * 13) % 420;
		const ay = 200 + i * 53 % 500;
		g.fillStyle = "#e8e4dc";
		g.fillRect(ax, ay, 32, 24);
		g.fillStyle = "#a0a8b0";
		g.fillRect(ax + 3, ay + 10, 26, 5);
		g.fillStyle = "rgba(0,0,0,0.2)";
		g.fillRect(ax + 5, ay + 4, 22, 3);
	}
	for (let i = 0; i < 55; i++) {
		g.fillStyle = `rgba(30,22,15,${.05 + i % 5 * .02})`;
		g.fillRect(i * 41 % 500, 860 + i % 8 * 12, 18 + i % 15, 7);
	}
	for (let i = 0; i < 6; i++) {
		g.fillStyle = `rgba(${40 + i % 3 * 30},${30 + i * 10},20,0.35)`;
		g.fillRect(20 + i * 83 % 460, 750 + i % 4 * 20, 40 + i % 3 * 15, 8 + i % 2 * 4);
	}
	const map = texOf$1(face);
	map.anisotropy = 16;
	return {
		map,
		emissiveMap: texOf$1(glow)
	};
}
var kit = null;
function buildingKit() {
	if (kit) return kit;
	const box = new BoxGeometry(1, 1, 1);
	const roof = new MeshStandardMaterial({
		color: "#7a6e5e",
		roughness: .92,
		metalness: .05
	});
	const facadeMats = [];
	const sets = [];
	for (let i = 0; i < 5; i++) {
		const maps = pair(i + 1);
		const facade = new MeshStandardMaterial({
			color: "#ffffff",
			map: maps?.map,
			emissive: "#ffcc77",
			emissiveMap: maps?.emissiveMap,
			emissiveIntensity: 0,
			roughness: .82,
			metalness: .04
		});
		facadeMats.push(facade);
		sets.push([
			facade,
			facade,
			roof,
			roof,
			facade,
			facade
		]);
	}
	kit = {
		box,
		facadeMats,
		sets
	};
	return kit;
}
function asphaltTexture() {
	const c = document.createElement("canvas");
	c.width = 512;
	c.height = 512;
	const g = c.getContext("2d");
	if (!g) return null;
	g.fillStyle = "#7a7570";
	g.fillRect(0, 0, 512, 512);
	for (let i = 0; i < 3200; i++) {
		const v = 70 + i * 17 % 55;
		g.fillStyle = `rgba(${v},${v - 3},${v - 6},0.32)`;
		g.fillRect(i * 13 % 512, i * 29 % 512, 2 + i % 2, 2);
	}
	for (let i = 0; i < 28; i++) {
		g.fillStyle = `rgba(45,40,35,${.22 + i % 5 * .06})`;
		g.beginPath();
		g.ellipse(30 + i * 97 % 450, 25 + i * 61 % 460, 35 + i % 6 * 14, 12 + i % 4 * 8, i * .4, 0, Math.PI * 2);
		g.fill();
	}
	g.strokeStyle = "rgba(200,190,160,0.18)";
	g.lineWidth = 3;
	for (let i = 0; i < 9; i++) {
		g.beginPath();
		g.moveTo(i * 55 % 512, 0);
		g.lineTo(i * 55 % 512 + 25, 512);
		g.stroke();
	}
	for (let i = 0; i < 12; i++) {
		const x = i * 137 % 420;
		const y = i * 89 % 430;
		g.fillStyle = i % 2 === 0 ? "rgba(95,90,82,0.55)" : "rgba(55,50,45,0.5)";
		g.fillRect(x, y, 55 + i % 4 * 20, 28 + i % 3 * 12);
	}
	for (let i = 0; i < 9; i++) {
		g.fillStyle = "rgba(30,28,25,0.65)";
		g.beginPath();
		g.ellipse(80 + i * 53 % 350, 60 + i * 71 % 380, 8 + i % 3 * 4, 5 + i % 2 * 3, 0, 0, Math.PI * 2);
		g.fill();
	}
	const map = texOf$1(c);
	map.wrapS = RepeatWrapping;
	map.wrapT = RepeatWrapping;
	return map;
}
function sidewalkTexture() {
	const c = document.createElement("canvas");
	c.width = 256;
	c.height = 256;
	const g = c.getContext("2d");
	if (!g) return null;
	g.fillStyle = "#b8aa96";
	g.fillRect(0, 0, 256, 256);
	g.strokeStyle = "rgba(70,58,45,0.45)";
	g.lineWidth = 2;
	for (let y = 0; y < 256; y += 64) for (let x = 0; x < 256; x += 64) {
		g.strokeRect(x + 1, y + 1, 62, 62);
		if ((x + y) % 128 === 0) {
			g.fillStyle = "rgba(80,65,48,0.22)";
			g.fillRect(x + 6, y + 6, 52, 52);
		}
		if (x * y % 3 === 0) {
			g.strokeStyle = "rgba(50,40,30,0.35)";
			g.beginPath();
			g.moveTo(x + 10, y + 15);
			g.lineTo(x + 45, y + 50);
			g.stroke();
		}
	}
	for (let i = 0; i < 18; i++) {
		g.fillStyle = `rgba(90,75,55,${.15 + i % 4 * .05})`;
		g.beginPath();
		g.ellipse(i * 47 % 240, i * 73 % 240, 12 + i % 4 * 6, 8 + i % 3 * 4, 0, 0, Math.PI * 2);
		g.fill();
	}
	const map = texOf$1(c);
	map.wrapS = RepeatWrapping;
	map.wrapT = RepeatWrapping;
	return map;
}
function bumpTexture() {
	const c = document.createElement("canvas");
	c.width = 128;
	c.height = 32;
	const g = c.getContext("2d");
	if (!g) return null;
	for (let x = 0; x < 128; x += 16) {
		g.fillStyle = x / 16 % 2 === 0 ? "#f0b429" : "#161616";
		g.fillRect(x, 0, 16, 32);
	}
	const map = texOf$1(c);
	map.wrapS = RepeatWrapping;
	map.repeat.set(8, 1);
	return map;
}
function stamp$1(list, o) {
	o.updateMatrix();
	list.push(o.matrix.clone());
}
function addInstances$1(scene, geo, mat, mats, colors) {
	if (!mats.length) return;
	const mesh = new InstancedMesh(geo, mat, mats.length);
	mesh.frustumCulled = false;
	mesh.castShadow = true;
	mesh.receiveShadow = true;
	mats.forEach((m, i) => mesh.setMatrixAt(i, m));
	if (colors) colors.forEach((c, i) => mesh.setColorAt(i, c));
	scene.add(mesh);
}
function sideOf(p, lat, y) {
	const rx = Math.cos(p.yaw);
	const rz = -Math.sin(p.yaw);
	return {
		x: p.x + rx * lat,
		y,
		z: p.z + rz * lat
	};
}
function dressFayoum(scene, track) {
	const kit = buildingKit();
	const dummy = new Object3D();
	const pts = track.pts;
	const scatter = (lateral, cap) => {
		return {
			meshes: kit.sets.map((mats) => {
				const mesh = new InstancedMesh(kit.box, mats, cap);
				mesh.count = 0;
				mesh.frustumCulled = false;
				mesh.castShadow = true;
				mesh.receiveShadow = true;
				scene.add(mesh);
				return mesh;
			}),
			counts: kit.sets.map(() => 0)
		};
	};
	const outer = scatter(0, 110);
	const median = scatter(0, 90);
	const awnings = [];
	const awningCols = [];
	const crates = [];
	const crateCols = [];
	const bikes = [];
	const dishes = [];
	const acs = [];
	const laundry = [];
	const laundryCols = [];
	const holes = [];
	const wires = [];
	const cloth = [
		"#c45c3e",
		"#1aa6a6",
		"#f0b429",
		"#1f6b4a",
		"#24527e",
		"#f4f1ea"
	].map((h) => new Color(h));
	const woods = [
		"#c9842a",
		"#a86b32",
		"#d35400",
		"#e6c27a"
	].map((h) => new Color(h));
	const o = new Object3D();
	for (let i = 0; i < pts.length; i += 4) {
		const p = pts[i];
		const nxt = pts[(i + 8) % pts.length];
		if (Math.abs((nxt.yaw - p.yaw + Math.PI * 3) % (Math.PI * 2) - Math.PI) > .22) continue;
		const hsh = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1;
		const rx = Math.cos(p.yaw);
		const rz = -Math.sin(p.yaw);
		const outward = Math.sign(p.x * rx + p.z * rz) || 1;
		for (const side of [-1, 1]) {
			const idx = (i + (side > 0 ? 1 : 0)) % 5;
			if (outer.counts[idx] < 95 && i % 5 === 0 && side === outward) {
				const height = (3 + Math.floor(hsh * 5)) * 2.75 + (hsh > .7 ? 1.2 : 0);
				const depth = 8.5 + hsh * 3.5;
				const width = 5.4 + (1 - hsh) * 2.2;
				dummy.position.set(p.x + rx * side * (22.5 + hsh * 3), height / 2, p.z + rz * side * (22.5 + hsh * 3));
				dummy.rotation.set(0, p.yaw + (hsh - .5) * .08, 0);
				dummy.scale.set(width, height, depth);
				dummy.updateMatrix();
				outer.meshes[idx].setMatrixAt(outer.counts[idx]++, dummy.matrix);
			}
			if (i % 12 === 0) {
				const at = sideOf(p, side * (ROAD_HALF + 2.3), 2.85);
				o.position.set(at.x, at.y, at.z);
				o.rotation.set(0, p.yaw, 0);
				o.scale.set(3.6, .08, 2.4);
				stamp$1(awnings, o);
				awningCols.push(cloth[i + side & 5]);
			}
			if (i % 5 === 0) {
				const at = sideOf(p, side * (ROAD_HALF + 1.55), .28);
				o.position.set(at.x, .28, at.z);
				o.rotation.set(0, p.yaw + (hsh - .5) * .4, 0);
				o.scale.set(.65 + hsh * .45, .5 + hsh * .2, .5 + hsh * .25);
				stamp$1(crates, o);
				crateCols.push(woods[i + side & 3]);
				if (hsh > .6) {
					o.position.y = .7;
					o.scale.set(.55, .45, .5);
					stamp$1(crates, o);
					crateCols.push(woods[i + 1 & 3]);
				}
			}
			if (i % 16 === 4) {
				const at = sideOf(p, side * (ROAD_HALF + .85), .42);
				o.position.set(at.x, .42, at.z);
				o.rotation.set(0, p.yaw + .4, 0);
				o.scale.set(1, 1, 1);
				stamp$1(bikes, o);
			}
			if (hsh > .55 && i % 8 === 0) {
				const at = sideOf(p, side * 16.5, 8 + hsh * 6);
				o.position.set(at.x, at.y, at.z);
				o.rotation.set(.9, p.yaw, 0);
				o.scale.set(1, 1, 1);
				stamp$1(dishes, o);
			}
			if (i % 6 === 2 || i % 6 === 5) {
				const at = sideOf(p, side * 12.4, 3.8 + i % 4 * .9);
				o.position.set(at.x, at.y, at.z);
				o.rotation.set(0, p.yaw, 0);
				o.scale.set(.42, .32, .28);
				stamp$1(acs, o);
				const line = sideOf(p, side * 12.15, at.y - .55);
				o.position.set(line.x, line.y, line.z);
				o.scale.set(.07, .65 + hsh * .3, .4);
				stamp$1(laundry, o);
				laundryCols.push(cloth[(i + 2) % cloth.length]);
				if (hsh > .45) {
					o.position.y -= .35;
					o.scale.set(.06, .5, .32);
					stamp$1(laundry, o);
					laundryCols.push(cloth[(i + 4) % cloth.length]);
				}
			}
		}
		if (Math.abs(p.x) > 30 && Math.abs(p.z) < 280 && i % 8 === 0) {
			const idx = i % 5;
			if (median.counts[idx] < 70) {
				const toward = Math.sign(p.x) || 1;
				const height = (5 + Math.floor(hsh * 3)) * 2.9;
				dummy.position.set(p.x - toward * 20, height / 2, p.z);
				dummy.rotation.set(0, p.yaw, 0);
				dummy.scale.set(7.2, height, 11);
				dummy.updateMatrix();
				median.meshes[idx].setMatrixAt(median.counts[idx]++, dummy.matrix);
			}
		}
		if (i % 18 === 0) {
			o.position.set(p.x, .03, p.z);
			o.rotation.set(0, p.yaw, 0);
			o.scale.set(1, 1, 1);
			stamp$1(holes, o);
		}
	}
	outer.meshes.forEach((m, i) => {
		m.count = outer.counts[i];
		m.instanceMatrix.needsUpdate = true;
	});
	median.meshes.forEach((m, i) => {
		m.count = median.counts[i];
		m.instanceMatrix.needsUpdate = true;
	});
	const awningMat = new MeshStandardMaterial({
		color: "#ffffff",
		roughness: .7
	});
	addInstances$1(scene, new BoxGeometry(1, 1, 1), awningMat, awnings, awningCols);
	const crateMat = new MeshStandardMaterial({
		color: "#ffffff",
		roughness: .86
	});
	addInstances$1(scene, new BoxGeometry(1, 1, 1), crateMat, crates, crateCols);
	const bikeGeo = new BoxGeometry(.35, .7, 1.5);
	bikeGeo.translate(0, .45, 0);
	addInstances$1(scene, bikeGeo, new MeshStandardMaterial({
		color: "#1b1e24",
		roughness: .6,
		metalness: .2
	}), bikes);
	const dishGeo = new SphereGeometry(.55, 8, 6);
	dishGeo.scale(1, .28, 1);
	addInstances$1(scene, dishGeo, new MeshStandardMaterial({
		color: "#d5d8dc",
		roughness: .4,
		metalness: .45
	}), dishes);
	addInstances$1(scene, new BoxGeometry(1, 1, 1), new MeshStandardMaterial({
		color: "#f4f1ea",
		roughness: .5
	}), acs);
	const clothMat = new MeshStandardMaterial({
		color: "#ffffff",
		roughness: .8
	});
	addInstances$1(scene, new BoxGeometry(1, 1, 1), clothMat, laundry, laundryCols);
	const holeGeo = new CircleGeometry(.42, 8);
	holeGeo.rotateX(-Math.PI / 2);
	addInstances$1(scene, holeGeo, new MeshStandardMaterial({
		color: "#2a2928",
		roughness: .7,
		metalness: .25
	}), holes);
	for (let i = 0; i < pts.length; i += 8) {
		const a = pts[i];
		const b = pts[(i + 8) % pts.length];
		if (Math.abs(a.x) < 20 || Math.abs(b.x) < 20) continue;
		const ra = Math.cos(a.yaw);
		const rza = -Math.sin(a.yaw);
		const rb = Math.cos(b.yaw);
		const rzb = -Math.sin(b.yaw);
		const ax = a.x + ra * 11.2;
		const az = a.z + rza * 11.2;
		const bx = b.x + rb * 11.2;
		const bz = b.z + rzb * 11.2;
		wires.push(ax, 6.15, az, (ax + bx) / 2, 5.6000000000000005, (az + bz) / 2);
		wires.push((ax + bx) / 2, 5.6000000000000005, (az + bz) / 2, bx, 6.15, bz);
	}
	if (wires.length) {
		const g = new BufferGeometry();
		g.setAttribute("position", new Float32BufferAttribute(wires, 3));
		scene.add(new LineSegments(g, new LineBasicMaterial({ color: "#2c3036" })));
	}
}
var SHOPS = [
	{
		name: "سوبر ماركت",
		sub: "دار السلام",
		bg: "#0e6b3c",
		fg: "#ffffff"
	},
	{
		name: "صيدلية الشفاء",
		sub: "٢٤ ساعة",
		bg: "#c0392b",
		fg: "#ffffff"
	},
	{
		name: "موبايلات",
		sub: "صيانة وشحن",
		bg: "#1a365d",
		fg: "#f0b429"
	},
	{
		name: "خضار وفاكهة",
		sub: "شارع الفيوم",
		bg: "#1e8449",
		fg: "#ffffff"
	},
	{
		name: "ملابس",
		sub: "جملة وقطاعي",
		bg: "#6c3483",
		fg: "#ffffff"
	},
	{
		name: "سنتر دروس",
		sub: "كل المراحل",
		bg: "#1a5276",
		fg: "#f6f1e7"
	},
	{
		name: "مخبز بلدي",
		sub: "عيش سخن",
		bg: "#b9770e",
		fg: "#1c1406"
	},
	{
		name: "قهوة الحج",
		sub: "شاي · قهوة",
		bg: "#6e2c00",
		fg: "#f6f1e7"
	},
	{
		name: "مكتب بريد",
		sub: "دار السلام",
		bg: "#0b5ea8",
		fg: "#ffffff"
	},
	{
		name: "مكتبة",
		sub: "كتب وملازم",
		bg: "#5d4e37",
		fg: "#f6f1e7"
	},
	{
		name: "كوافير",
		sub: "حلاقة وتجميل",
		bg: "#8e44ad",
		fg: "#ffffff"
	},
	{
		name: "أدوات منزلية",
		sub: "جملة",
		bg: "#16a085",
		fg: "#ffffff"
	},
	{
		name: "لحوم ودواجن",
		sub: "طازج يومياً",
		bg: "#922b21",
		fg: "#f6f1e7"
	},
	{
		name: "محل حلويات",
		sub: "شرقي وغربي",
		bg: "#b9770e",
		fg: "#1c1406"
	},
	{
		name: "كهرباء وسباكة",
		sub: "صيانة",
		bg: "#1c2833",
		fg: "#f0b429"
	}
];
function shopTex(name, sub, bg, fg) {
	const c = document.createElement("canvas");
	c.width = 512;
	c.height = 160;
	const g = c.getContext("2d");
	if (!g) return null;
	g.fillStyle = bg;
	g.fillRect(0, 0, 512, 160);
	g.fillStyle = fg;
	g.fillRect(0, 0, 512, 8);
	g.direction = "rtl";
	g.textAlign = "center";
	g.fillStyle = fg;
	g.font = "800 64px Tajawal, 'DejaVu Sans', sans-serif";
	g.fillText(name, 256, 78);
	g.font = "500 32px Tajawal, 'DejaVu Sans', sans-serif";
	g.globalAlpha = .85;
	g.fillText(sub, 256, 128);
	return texOf$1(c);
}
function placeShopSigns(scene, track) {
	const buckets = SHOPS.map(() => []);
	const o = new Object3D();
	const pts = track.pts;
	for (let i = 6; i < pts.length; i += 5) {
		const p = pts[i];
		const nxt = pts[(i + 6) % pts.length];
		if (Math.abs((nxt.yaw - p.yaw + Math.PI * 3) % (Math.PI * 2) - Math.PI) > .2) continue;
		const at = sideOf(p, (i % 10 < 5 ? 1 : -1) * 11.6, 3.55);
		o.position.set(at.x, at.y, at.z);
		o.rotation.set(0, p.yaw, 0);
		o.scale.set(1, 1, 1);
		o.updateMatrix();
		buckets[i % SHOPS.length].push(o.matrix.clone());
	}
	SHOPS.forEach((shop, i) => {
		const map = shopTex(shop.name, shop.sub, shop.bg, shop.fg);
		if (!map || !buckets[i].length) return;
		const mat = new MeshStandardMaterial({
			map,
			roughness: .65,
			side: 2
		});
		addInstances$1(scene, new PlaneGeometry(4.4, 1.35), mat, buckets[i]);
	});
}
function flagTex() {
	const c = document.createElement("canvas");
	c.width = 96;
	c.height = 64;
	const g = c.getContext("2d");
	if (!g) return null;
	g.fillStyle = "#ce1126";
	g.fillRect(0, 0, 96, 21);
	g.fillStyle = "#ffffff";
	g.fillRect(0, 21, 96, 22);
	g.fillStyle = "#111111";
	g.fillRect(0, 43, 96, 21);
	g.fillStyle = "#c5a15a";
	g.beginPath();
	g.arc(48, 32, 8, 0, Math.PI * 2);
	g.fill();
	return texOf$1(c);
}
function buildLandmarks(scene, track) {
	const stone = new MeshStandardMaterial({
		color: "#e7dcc8",
		roughness: .9
	});
	const concrete = new MeshStandardMaterial({
		color: "#b7b1a8",
		roughness: .84
	});
	const yellow = new MeshStandardMaterial({
		color: "#e6c56a",
		roughness: .62
	});
	const white = new MeshStandardMaterial({
		color: "#f4f0e6",
		roughness: .7
	});
	const green = new MeshStandardMaterial({
		color: "#1f6b4a",
		roughness: .55
	});
	const red = new MeshStandardMaterial({
		color: "#b3392b",
		roughness: .6
	});
	const teal = new MeshStandardMaterial({
		color: "#1a7a78",
		roughness: .55
	});
	const dark = new MeshStandardMaterial({
		color: "#2a3138",
		roughness: .5,
		metalness: .2
	});
	const flagMat = new MeshStandardMaterial({
		map: flagTex() ?? void 0,
		roughness: .6,
		side: 2
	});
	const spot = (dist, lat) => {
		const sm = track.sample(dist);
		const rx = Math.cos(sm.yaw);
		const rz = -Math.sin(sm.yaw);
		return {
			x: sm.x + rx * lat,
			z: sm.z + rz * lat,
			yaw: sm.yaw
		};
	};
	const put = (index, lat, build) => {
		const p = spot(track.stops[index].s, lat);
		const g = new Group();
		g.position.set(p.x, 0, p.z);
		g.rotation.y = p.yaw;
		build(g);
		scene.add(g);
	};
	put(0, 0, (g) => {
		const deck = new Mesh(new BoxGeometry(30, .5, 9), concrete);
		deck.position.y = 6.3;
		const railL = new Mesh(new BoxGeometry(30, .85, .16), dark);
		railL.position.set(0, 6.9, 4.2);
		const railR = railL.clone();
		railR.position.z = -4.2;
		for (const x of [-13, 13]) for (const z of [-3.2, 3.2]) {
			const col = new Mesh(new BoxGeometry(.85, 6.3, .85), concrete);
			col.position.set(x, 3.15, z);
			g.add(col);
		}
		[
			"#f4f1ea",
			"#c0392b",
			"#1a365d",
			"#f0b429",
			"#2c3e50",
			"#95a5a6",
			"#e6c27a"
		].forEach((hex, i) => {
			const car = new Mesh(new BoxGeometry(1.65, 1.2, 3.6), new MeshStandardMaterial({
				color: hex,
				roughness: .5
			}));
			car.position.set(-9.2 + i * 3.05, 7.15, i % 2 === 0 ? 1.6 : -1.6);
			g.add(car);
		});
		g.add(deck, railL, railR);
	});
	put(1, 10.6, (g) => {
		[
			"#f7f7f4",
			"#e7e4dc",
			"#d5dde2",
			"#f4f1ea"
		].forEach((hex, i) => {
			const bus = new Mesh(new BoxGeometry(2.05, 2.15, 4.8), new MeshStandardMaterial({
				color: hex,
				roughness: .55
			}));
			bus.position.set(i % 2 * 2.4, 1.15, (i - 1.5) * 5.6);
			const glass = new Mesh(new BoxGeometry(1.9, .45, 1.3), new MeshStandardMaterial({
				color: "#9fd0d8",
				roughness: .15,
				metalness: .2
			}));
			glass.position.set(i % 2 * 2.4, 1.85, (i - 1.5) * 5.6 - 1.4);
			g.add(bus, glass);
		});
	});
	put(2, 13.4, (g) => {
		const block = new Mesh(new BoxGeometry(8, 18, 7), concrete);
		block.position.y = 9;
		const mast = new Mesh(new CylinderGeometry(.08, .1, 6, 6), dark);
		mast.position.set(0, 21, 0);
		const dish = new Mesh(new SphereGeometry(1.2, 10, 8), new MeshStandardMaterial({
			color: "#dfe3e6",
			metalness: .45,
			roughness: .35
		}));
		dish.scale.set(1, .22, 1);
		dish.position.set(2.4, 14.5, 2.8);
		dish.rotation.x = .9;
		g.add(block, mast, dish);
	});
	put(3, 13.2, (g) => {
		const block = new Mesh(new BoxGeometry(16, 8, 9), stone);
		block.position.y = 4;
		const band = new Mesh(new BoxGeometry(16.2, .4, 9.2), teal);
		band.position.y = 6.4;
		const pole = new Mesh(new CylinderGeometry(.08, .08, 6, 6), dark);
		pole.position.set(-6.5, 7.2, 4.2);
		const flag = new Mesh(new PlaneGeometry(1.8, 1.15), flagMat);
		flag.position.set(-5.4, 9.4, 4.2);
		g.add(block, band, pole, flag);
	});
	put(4, 13.4, (g) => {
		const wall = new Mesh(new BoxGeometry(22, 3.2, .4), yellow);
		wall.position.set(0, 1.6, -2);
		const school = new Mesh(new BoxGeometry(16, 7, 8), yellow);
		school.position.set(0, 3.5, -6);
		const gate = new Mesh(new BoxGeometry(3.2, 2.6, .3), dark);
		gate.position.set(0, 1.3, -1.8);
		const pole = new Mesh(new CylinderGeometry(.07, .07, 5, 6), dark);
		pole.position.set(6, 5.2, -1.5);
		const flag = new Mesh(new PlaneGeometry(1.7, 1.1), flagMat);
		flag.position.set(7.1, 7.1, -1.5);
		g.add(wall, school, gate, pole, flag);
	});
	put(5, 13.6, (g) => {
		const school = new Mesh(new BoxGeometry(14, 6.5, 7), yellow);
		school.position.y = 3.25;
		const band = new Mesh(new BoxGeometry(14.2, .35, 7.2), green);
		band.position.y = 5.4;
		const gate = new Mesh(new BoxGeometry(2.4, 2.4, .25), dark);
		gate.position.set(0, 1.2, 3.6);
		g.add(school, band, gate);
	});
	put(6, 12.2, (g) => {
		const stair = new Mesh(new BoxGeometry(6.5, .4, 4.2), concrete);
		stair.position.set(0, .5, -1.2);
		stair.rotation.x = .18;
		const head = new Mesh(new BoxGeometry(7.2, 2.4, 1.2), red);
		head.position.set(0, 3.2, -3.2);
		const m = new Mesh(new BoxGeometry(1.6, 1.5, .12), new MeshStandardMaterial({
			color: "#f6f1e7",
			roughness: .4
		}));
		m.position.set(0, 3.25, -2.5);
		g.add(stair, head, m);
	});
	put(7, 12.6, (g) => {
		const clinic = new Mesh(new BoxGeometry(9, 5.5, 6), white);
		clinic.position.y = 2.75;
		const cross = new Mesh(new BoxGeometry(.35, 1.5, .08), red);
		cross.position.set(0, 3.4, 3.05);
		const bar = new Mesh(new BoxGeometry(1.5, .35, .08), red);
		bar.position.set(0, 3.4, 3.08);
		g.add(clinic, cross, bar);
	});
	put(8, 12.4, (g) => {
		const post = new Mesh(new BoxGeometry(8, 4.2, 5), yellow);
		post.position.y = 2.1;
		const band = new Mesh(new BoxGeometry(8.1, .7, 5.1), teal);
		band.position.y = 3.5;
		g.add(post, band);
	});
	put(9, 11.8, (g) => {
		const shop = new Mesh(new BoxGeometry(6.4, 3.2, 4.4), stone);
		shop.position.y = 1.6;
		const oven = new Mesh(new CylinderGeometry(.55, .7, 2.4, 8), red);
		oven.position.set(2.1, 4.2, 0);
		const awn = new Mesh(new BoxGeometry(6.8, .1, 1.6), yellow);
		awn.position.set(0, 3.15, 2.4);
		g.add(shop, oven, awn);
	});
	put(10, 12.2, (g) => {
		const cafe = new Mesh(new BoxGeometry(7.2, 3.1, 4), stone);
		cafe.position.y = 1.55;
		const shade = new Mesh(new BoxGeometry(8, .1, 3.4), teal);
		shade.position.set(0, 3.2, 2.2);
		for (const x of [
			-2.2,
			0,
			2.2
		]) {
			const chair = new Mesh(new BoxGeometry(.55, .08, .55), white);
			chair.position.set(x, .48, 2.5);
			g.add(chair);
		}
		g.add(cafe, shade);
	});
	put(11, 11.6, (g) => {
		[
			red,
			teal,
			yellow,
			green,
			dark
		].forEach((mat, i) => {
			const boardM = new Mesh(new BoxGeometry(.16, 1.6, 2.4), mat);
			boardM.position.set(0, 3.1, (i - 2) * 2.8);
			const post = new Mesh(new BoxGeometry(.12, 2.6, .12), dark);
			post.position.set(0, 1.3, (i - 2) * 2.8);
			g.add(boardM, post);
		});
	});
	{
		const p = spot(track.gasS, 11.2);
		const g = new Group();
		g.position.set(p.x, 0, p.z);
		g.rotation.y = p.yaw;
		const canopy = new Mesh(new BoxGeometry(7.2, .22, 5.4), red);
		canopy.position.y = 3.6;
		const stripe = new Mesh(new BoxGeometry(7.2, .12, 1.1), white);
		stripe.position.y = 3.48;
		[-3, 3].forEach((x) => {
			const col = new Mesh(new BoxGeometry(.28, 3.5, .28), white);
			col.position.set(x, 1.75, -2);
			g.add(col);
		});
		const pump = new Mesh(new BoxGeometry(.5, 1.45, .35), dark);
		pump.position.set(0, .75, .2);
		g.add(canopy, stripe, pump);
		scene.add(g);
	}
	{
		const sm = track.sample(track.total * .22);
		const rx = Math.cos(sm.yaw);
		const rz = -Math.sin(sm.yaw);
		const outward = Math.sign(sm.x * rx + sm.z * rz) || 1;
		const g = new Group();
		g.position.set(sm.x - rx * outward * 28, 0, sm.z - rz * outward * 28);
		const base = new Mesh(new BoxGeometry(11, 6, 10), stone);
		base.position.y = 3;
		const dome = new Mesh(new SphereGeometry(3.6, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), new MeshStandardMaterial({
			color: "#d9c7a4",
			roughness: .7
		}));
		dome.position.y = 6;
		const minaret = new Mesh(new CylinderGeometry(.7, .95, 16, 8), stone);
		minaret.position.set(5.2, 8, 1.5);
		const cap = new Mesh(new ConeGeometry(1.1, 2.2, 8), green);
		cap.position.set(5.2, 16.8, 1.5);
		g.add(base, dome, minaret, cap);
		scene.add(g);
	}
	const bumpMat = new MeshStandardMaterial({
		map: bumpTexture() ?? void 0,
		roughness: .55
	});
	for (const b of track.bumps) {
		const sm = track.sample(b);
		const mesh = new Mesh(new BoxGeometry(13.5, .16, .9), bumpMat);
		mesh.position.set(sm.x, .09, sm.z);
		mesh.rotation.y = sm.yaw;
		scene.add(mesh);
	}
	const trunkMat = new MeshStandardMaterial({
		color: "#6b4a2b",
		roughness: .9
	});
	const leafMat = new MeshStandardMaterial({
		color: "#2f5a38",
		roughness: .75
	});
	const leafMat2 = new MeshStandardMaterial({
		color: "#3d7a48",
		roughness: .8
	});
	for (let t = .01; t < .99; t += .045) {
		const side = Math.floor(t * 100) % 2 === 0 ? 1 : -1;
		const lat = 18 + t * 37 % 6;
		const p = spot(track.total * t, side * lat);
		const h = 2.8 + t * 50 % 1.6;
		const trunk = new Mesh(new CylinderGeometry(.14, .22, h, 7), trunkMat);
		trunk.position.set(p.x, h / 2, p.z);
		const crown1 = new Mesh(new SphereGeometry(1.05 + t % .3, 7, 5), leafMat);
		crown1.position.set(p.x, h + .3, p.z);
		crown1.scale.set(1.15, .7, 1.15);
		const crown2 = new Mesh(new SphereGeometry(.85, 6, 5), leafMat2);
		crown2.position.set(p.x + .25, h + .55, p.z - .15);
		crown2.scale.set(1.1, .55, 1.1);
		scene.add(trunk, crown1, crown2);
	}
}
function buildPosts(scene, track) {
	const metal = new MeshStandardMaterial({
		color: "#c5ccd3",
		roughness: .45,
		metalness: .25
	});
	const cam = new MeshStandardMaterial({
		color: "#f0b429",
		emissive: "#f0b429",
		emissiveIntensity: .35
	});
	const boothMat = new MeshStandardMaterial({
		color: "#1d4e89",
		roughness: .6
	});
	const addCam = (s) => {
		const sm = track.sample(s);
		const rx = Math.cos(sm.yaw);
		const rz = -Math.sin(sm.yaw);
		const g = new Group();
		g.position.set(sm.x + rx * 10.6, 0, sm.z + rz * 10.6);
		g.rotation.y = sm.yaw;
		const pole = new Mesh(new CylinderGeometry(.08, .1, 4.4, 6), metal);
		pole.position.y = 2.2;
		const eye = new Mesh(new BoxGeometry(.28, .22, .45), cam);
		eye.position.set(-.2, 4.2, 0);
		g.add(pole, eye);
		scene.add(g);
	};
	for (const s of track.radarS) addCam(s);
	const sm = track.sample(track.tollS);
	const rx = Math.cos(sm.yaw);
	const rz = -Math.sin(sm.yaw);
	const booth = new Mesh(new BoxGeometry(1.6, 2.2, 1.6), boothMat);
	booth.position.set(sm.x + rx * 9.4, 1.1, sm.z + rz * 9.4);
	booth.rotation.y = sm.yaw;
	scene.add(booth);
}
/** More realistic low-poly Egyptian pedestrians with arms, variety & density */
function placePeople(scene, track) {
	const skins = [
		"#c49a78",
		"#a87b5c",
		"#d4b48c",
		"#8d6e4a",
		"#b08968",
		"#e0b896"
	].map((c) => new MeshStandardMaterial({
		color: c,
		roughness: .68
	}));
	const shirts = [
		"#1e3a5f",
		"#2d5a3d",
		"#8b3a2a",
		"#3a3a4a",
		"#c45c3e",
		"#1aa6a6",
		"#f0b429",
		"#ffffff",
		"#e8e0d2",
		"#4a6741",
		"#6b2d5c",
		"#2c3e50"
	].map((c) => new MeshStandardMaterial({
		color: c,
		roughness: .72
	}));
	const pants = [
		"#2a2e35",
		"#3d4450",
		"#1a1e24",
		"#4a3f35",
		"#5c4033",
		"#1c2833"
	].map((c) => new MeshStandardMaterial({
		color: c,
		roughness: .8
	}));
	const bodyGeo = new CapsuleGeometry(.17, .42, 4, 6);
	const headGeo = new SphereGeometry(.125, 8, 6);
	const legGeo = new CapsuleGeometry(.065, .38, 3, 5);
	const armGeo = new CapsuleGeometry(.045, .28, 3, 5);
	for (let i = 0; i < track.pts.length; i += 4) {
		const p = track.pts[i];
		const hsh = Math.abs(Math.sin(i * 7.13 + 1.7) * 43758.5453) % 1;
		if (hsh < .22) continue;
		const side = hsh > .55 ? 1 : -1;
		const rx = Math.cos(p.yaw);
		const rz = -Math.sin(p.yaw);
		const lateral = ROAD_HALF + 2.55 + hsh % .55 * 1.4;
		const g = new Group();
		g.position.set(p.x + rx * side * lateral, 0, p.z + rz * side * lateral);
		g.rotation.y = p.yaw + (hsh - .5) * .9 + (side > 0 ? Math.PI : 0) + (hsh > .75 ? Math.PI * .5 : 0);
		const scale = .88 + hsh % .25;
		g.scale.set(scale, scale, scale);
		const skin = skins[i % skins.length];
		const shirt = shirts[i % shirts.length];
		const pant = pants[i % pants.length];
		const torso = new Mesh(bodyGeo, shirt);
		torso.position.y = 1.02;
		const head = new Mesh(headGeo, skin);
		head.position.y = 1.48;
		const legL = new Mesh(legGeo, pant);
		legL.position.set(-.09, .38, hsh > .5 ? .06 : -.04);
		legL.rotation.x = hsh > .5 ? .15 : -.12;
		const legR = new Mesh(legGeo, pant);
		legR.position.set(.09, .38, hsh > .5 ? -.05 : .05);
		legR.rotation.x = hsh > .5 ? -.12 : .15;
		const armL = new Mesh(armGeo, shirt);
		armL.position.set(-.26, 1.05, 0);
		armL.rotation.z = .35 + hsh % .3;
		armL.rotation.x = (hsh - .5) * .4;
		const armR = new Mesh(armGeo, shirt);
		armR.position.set(.26, 1.05, 0);
		armR.rotation.z = -.35 - hsh % .25;
		armR.rotation.x = (.5 - hsh) * .4;
		g.add(torso, head, legL, legR, armL, armR);
		scene.add(g);
		if (hsh > .82 && i % 3 === 0) {
			const g2 = g.clone();
			g2.position.x += rx * side * .7 + rz * .55;
			g2.position.z += rz * side * .7 - rx * .55;
			g2.rotation.y += .6;
			g2.scale.setScalar(.92 + hsh % .15);
			scene.add(g2);
		}
	}
}
/** Sidewalk spill into the right lane — checked by the sim. */
var OCCUPATIONS = [];
function texOf(c) {
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	tex.anisotropy = 4;
	return tex;
}
function board(lines, bg, fg, h = 320) {
	const c = document.createElement("canvas");
	c.width = 512;
	c.height = h;
	const g = c.getContext("2d");
	if (!g) return null;
	g.fillStyle = bg;
	g.fillRect(0, 0, 512, h);
	g.fillStyle = "#f0b429";
	g.fillRect(0, 0, 512, 14);
	g.direction = "rtl";
	g.textAlign = "center";
	g.fillStyle = fg;
	const step = Math.min(64, (h - 40) / lines.length);
	lines.forEach((line, i) => {
		g.font = i === 0 ? "800 54px Tajawal, 'DejaVu Sans', sans-serif" : "700 36px Tajawal, 'DejaVu Sans', sans-serif";
		g.fillText(line, 256, 70 + i * step);
	});
	return texOf(c);
}
function stamp(list, o) {
	o.updateMatrix();
	list.push(o.matrix.clone());
}
function addInstances(scene, geo, mat, mats, colors) {
	if (!mats.length) return null;
	const mesh = new InstancedMesh(geo, mat, mats.length);
	mesh.frustumCulled = false;
	mesh.castShadow = false;
	mesh.receiveShadow = true;
	mats.forEach((m, i) => mesh.setMatrixAt(i, m));
	if (colors) colors.forEach((c, i) => mesh.setColorAt(i, c));
	scene.add(mesh);
	return mesh;
}
function side(p, lat, y) {
	const rx = Math.cos(p.yaw);
	const rz = -Math.sin(p.yaw);
	return {
		x: p.x + rx * lat,
		y,
		z: p.z + rz * lat
	};
}
/** Props that make Fayoum Street read as Dar El Salam: vendors, gallons, racks, crosswalks, footbridge, dust. */
function dressStreet(scene, track) {
	OCCUPATIONS.length = 0;
	const o = new Object3D();
	const racks = [];
	const cloth = [];
	const clothCols = [];
	const gallons = [];
	const chairs = [];
	const produce = [];
	const produceCols = [];
	const carts = [];
	const stripes = [];
	const cones = [];
	const colors = [
		"#c45c3e",
		"#1d4e89",
		"#f4f1ea",
		"#2f6b3a",
		"#111",
		"#e6c27a",
		"#6b3a5d"
	].map((h) => new Color(h));
	const veg = [
		"#2f6b3a",
		"#c0392b",
		"#e67e22",
		"#f4d03f",
		"#8e44ad"
	].map((h) => new Color(h));
	const pts = track.pts;
	for (let i = 8; i < pts.length; i += 7) {
		const p = pts[i];
		const nxt = pts[(i + 6) % pts.length];
		if (Math.abs((nxt.yaw - p.yaw + Math.PI * 3) % (Math.PI * 2) - Math.PI) > .18) continue;
		const hsh = Math.abs(Math.sin(i * 9.17) * 43758.5453) % 1;
		if (i % 14 === 8) {
			const lat = 5.55 + hsh * .7;
			const at = side(p, lat, .55);
			o.position.set(at.x, .55, at.z);
			o.rotation.set(0, p.yaw, 0);
			o.scale.set(1.1, .9, .7);
			stamp(carts, o);
			OCCUPATIONS.push({
				s: p.s,
				lat
			});
			for (let k = 0; k < 3; k++) {
				const vegAt = side(p, lat - .15, 1.05);
				o.position.set(vegAt.x, 1.05 + k * .02, vegAt.z);
				o.scale.set(.28, .22, .28);
				stamp(produce, o);
				produceCols.push(veg[(i + k) % veg.length]);
			}
		}
		if (i % 11 === 1) {
			const at = side(p, ROAD_HALF + 2.4, .7);
			o.position.set(at.x, .7, at.z);
			o.rotation.set(0, p.yaw, 0);
			o.scale.set(1.4, 1.15, .35);
			stamp(racks, o);
			for (let k = 0; k < 4; k++) {
				o.position.set(at.x, .85, at.z);
				o.scale.set(.22, .55, .08);
				o.position.x += Math.cos(p.yaw) * (k - 1.5) * .28;
				o.position.z += -Math.sin(p.yaw) * (k - 1.5) * .28;
				stamp(cloth, o);
				clothCols.push(colors[(i + k) % colors.length]);
			}
		}
		if (i % 9 === 4) {
			const at = side(p, ROAD_HALF + 1.7, .22);
			for (let k = 0; k < 3; k++) {
				o.position.set(at.x, .18 + k * .28, at.z);
				o.rotation.set(0, p.yaw + k, 0);
				o.scale.set(.32, .42, .32);
				stamp(gallons, o);
			}
		}
		if (i % 13 === 2) {
			const at = side(p, ROAD_HALF + 2.1, .42);
			o.position.set(at.x, .42, at.z);
			o.rotation.set(0, p.yaw + .4, 0);
			o.scale.set(.42, .08, .42);
			stamp(chairs, o);
		}
	}
	for (const stop of track.stops) for (let k = -3; k <= 3; k++) {
		const sm = track.sample(stop.s + k * 1.15);
		o.position.set(sm.x, .05, sm.z);
		o.rotation.set(0, sm.yaw, 0);
		o.scale.set(7.2, 1, .38);
		stamp(stripes, o);
	}
	const kamin = track.radarS[1] ?? track.total * .41;
	for (let k = 0; k < 6; k++) {
		const sm = track.sample(kamin - 6 + k * 2.2);
		const rx = Math.cos(sm.yaw);
		const rz = -Math.sin(sm.yaw);
		const lat = k % 2 === 0 ? 2.2 : 5.4;
		o.position.set(sm.x + rx * lat, .35, sm.z + rz * lat);
		o.rotation.set(0, sm.yaw, 0);
		o.scale.set(1, 1, 1);
		stamp(cones, o);
	}
	const metal = new MeshStandardMaterial({
		color: "#8d949c",
		roughness: .45,
		metalness: .35
	});
	addInstances(scene, new BoxGeometry(1, 1, 1), metal, racks);
	addInstances(scene, new BoxGeometry(1, 1, 1), new MeshStandardMaterial({
		color: "#ffffff",
		roughness: .8
	}), cloth, clothCols);
	addInstances(scene, new CylinderGeometry(.5, .5, 1, 8), new MeshStandardMaterial({
		color: "#d5ebe8",
		roughness: .4
	}), gallons);
	addInstances(scene, new BoxGeometry(1, 1, 1), new MeshStandardMaterial({
		color: "#f4f1ea",
		roughness: .7
	}), chairs);
	addInstances(scene, new SphereGeometry(.5, 6, 5), new MeshStandardMaterial({
		color: "#ffffff",
		roughness: .7
	}), produce, produceCols);
	addInstances(scene, new BoxGeometry(1, 1, 1), new MeshStandardMaterial({
		color: "#6b4a2b",
		roughness: .85
	}), carts);
	addInstances(scene, new BoxGeometry(1, .02, 1), new MeshStandardMaterial({
		color: "#f4f0e4",
		roughness: .6
	}), stripes);
	const coneGeo = new ConeGeometry(.22, .7, 7);
	coneGeo.translate(0, .35, 0);
	addInstances(scene, coneGeo, new MeshStandardMaterial({
		color: "#e23b2b",
		roughness: .55
	}), cones);
	footbridge(scene, track, track.total * .5);
	dust(scene, track);
}
function footbridge(scene, track, dist) {
	const sm = track.sample(dist);
	const g = new Group();
	g.position.set(sm.x, 0, sm.z);
	g.rotation.y = sm.yaw;
	const concrete = new MeshStandardMaterial({
		color: "#c8c2b6",
		roughness: .86
	});
	const rail = new MeshStandardMaterial({
		color: "#3d4650",
		roughness: .5,
		metalness: .2
	});
	const deck = new Mesh(new BoxGeometry(24, .16, 1.8), concrete);
	deck.position.y = 4.7;
	const r1 = new Mesh(new BoxGeometry(24, .9, .08), rail);
	r1.position.set(0, 5.2, .85);
	const r2 = r1.clone();
	r2.position.z = -.85;
	for (const sideX of [-11.2, 11.2]) {
		const stair = new Mesh(new BoxGeometry(1.5, .14, 5.2), concrete);
		stair.position.set(sideX, 2.4, 3.2);
		stair.rotation.x = -.72;
		const post = new Mesh(new BoxGeometry(.28, 4.7, .28), concrete);
		post.position.set(sideX, 2.35, 0);
		g.add(stair, post);
	}
	g.add(deck, r1, r2);
	scene.add(g);
}
function dust(scene, track) {
	const n = 280;
	const pos = new Float32Array(n * 3);
	for (let i = 0; i < n; i++) {
		const sm = track.sample(i / n * track.total);
		const rx = Math.cos(sm.yaw);
		const rz = -Math.sin(sm.yaw);
		const lat = (i % 2 === 0 ? 1 : -1) * (4 + i % 9);
		pos[i * 3] = sm.x + rx * lat;
		pos[i * 3 + 1] = 1.2 + i % 7 * .7;
		pos[i * 3 + 2] = sm.z + rz * lat;
	}
	const geo = new BufferGeometry();
	geo.setAttribute("position", new BufferAttribute(pos, 3));
	const pts = new Points(geo, new PointsMaterial({
		color: "#cbb89a",
		size: .22,
		transparent: true,
		opacity: .28,
		depthWrite: false,
		sizeAttenuation: true
	}));
	pts.frustumCulled = false;
	const base = pos.slice(0);
	pts.onBeforeRender = () => {
		const t = performance.now() * 15e-5;
		const arr = geo.attributes.position.array;
		for (let i = 0; i < n; i++) {
			arr[i * 3] = base[i * 3] + Math.sin(t + i) * .35;
			arr[i * 3 + 1] = base[i * 3 + 1] + Math.sin(t * 2 + i * .7) * .2;
		}
		geo.attributes.position.needsUpdate = true;
	};
	scene.add(pts);
}
function placeLocalSigns(scene, track) {
	const hang = (dist, lat, lines, bg, fg = "#f6f1e7", w = 4.2, h = 2.4) => {
		const map = board(lines, bg, fg, Math.round(256 * (h / 2.2)));
		if (!map) return;
		const sm = track.sample(dist);
		const rx = Math.cos(sm.yaw);
		const rz = -Math.sin(sm.yaw);
		const mesh = new Mesh(new PlaneGeometry(w, h), new MeshStandardMaterial({
			map,
			roughness: .6,
			side: 2
		}));
		mesh.position.set(sm.x + rx * lat, 3.4, sm.z + rz * lat);
		mesh.rotation.y = sm.yaw;
		scene.add(mesh);
	};
	hang(track.stops[1].s - 8, 10.2, [
		"موقف كوبري دار السلام",
		"السيدة زينب",
		"الجيزة",
		"الزهراء · المعادي",
		"الهرم · التحرير"
	], "#0b3a82");
	hang(track.stops[6].s - 4, 11.4, ["مترو دار السلام", "الخط الأول"], "#c0392b");
	hang(track.total * .5 - 10, -11, ["كوبري المشاة", "ناحية السوق"], "#3d4650");
	hang(track.stops[12].s, 11, ["شارع المحجر", "مدخل الحي"], "#1c2833", "#f0b429", 3.6, 1.8);
	hang(track.stops[13].s - 12, 10.6, ["شارع أحمد زكي", "آخر شارع الفيوم"], "#1c2833", "#f0b429", 4.4, 2);
	const pts = track.pts;
	for (let i = 20; i < pts.length; i += 46) {
		const p = pts[i];
		if (Math.abs((pts[(i + 8) % pts.length].yaw - p.yaw + Math.PI * 3) % (Math.PI * 2) - Math.PI) > .16) continue;
		hang(p.s, 12.2, ["شارع الفيوم", "حي دار السلام"], "#16324f", "#f6f1e7", 3.4, 1.5);
	}
}
var SAVE_KEY = "daralsalam-save-v2";
var RADAR_LIMIT = 46 / 3.6;
var TOLL_LIMIT = 10;
function blankUpgrades() {
	return {
		motor: 0,
		fuel: 0,
		seats: 0,
		tires: 0
	};
}
function clampLvl(n) {
	const v = Math.floor(Number(n) || 0);
	return Math.max(0, Math.min(3, v));
}
function loadSave() {
	const blank = {
		v: 2,
		bestMoney: 0,
		bestKm: 0,
		bestTrial: null,
		sound: true,
		wallet: 0,
		upgrades: blankUpgrades()
	};
	try {
		const raw = localStorage.getItem(SAVE_KEY);
		if (!raw) return blank;
		const p = JSON.parse(raw);
		if (p.v !== 2) return blank;
		const u = p.upgrades ?? {};
		return {
			v: 2,
			bestMoney: Number(p.bestMoney) || 0,
			bestKm: Number(p.bestKm) || 0,
			bestTrial: typeof p.bestTrial === "number" ? p.bestTrial : null,
			sound: p.sound !== false,
			wallet: Math.max(0, Math.floor(Number(p.wallet) || 0)),
			upgrades: {
				motor: clampLvl(u.motor),
				fuel: clampLvl(u.fuel),
				seats: clampLvl(u.seats),
				tires: clampLvl(u.tires)
			}
		};
	} catch {
		return blank;
	}
}
function writeSave(s) {
	try {
		localStorage.setItem(SAVE_KEY, JSON.stringify(s));
	} catch {}
}
function box(w, h, d, x, y, z) {
	const g = new BoxGeometry(w, h, d);
	g.translate(x, y, z);
	return g;
}
function merge(parts) {
	return mergeGeometries(parts, false) ?? parts[0];
}
var KINDS = [
	"malaky",
	"taxi",
	"micro",
	"tuktuk",
	"truck"
];
function trafficGeoms(kind) {
	const body = [];
	const glass = [];
	const wheels = [];
	const lights = [];
	const wheel = () => {
		const g = new CylinderGeometry(.34, .34, .22, 8);
		g.rotateZ(Math.PI / 2);
		return g;
	};
	const addW = (x, y, z, s = 1) => {
		const g = wheel();
		g.scale(s, s, s);
		g.translate(x, y, z);
		wheels.push(g);
	};
	if (kind === "micro") {
		body.push(box(2.05, 1.45, 4.9, 0, 1.2, .05));
		glass.push(box(1.85, .55, 1.3, 0, 1.85, -1.05));
		glass.push(box(1.7, .42, 2.2, 0, 1.78, .85));
		lights.push(box(.2, .22, .08, -.75, .95, 2.5));
		lights.push(box(.2, .22, .08, .75, .95, 2.5));
		addW(-1.05, .36, -1.6, 1.05);
		addW(1.05, .36, -1.6, 1.05);
		addW(-1.05, .36, 1.5, 1.05);
		addW(1.05, .36, 1.5, 1.05);
	} else if (kind === "tuktuk") {
		body.push(box(1.32, .55, 1.35, 0, .72, .28));
		body.push(box(1.42, .06, 1.58, 0, 1.48, .15));
		body.push(box(1.02, .22, .85, 0, .42, -.95));
		glass.push(box(1.15, .48, .05, 0, 1.12, -.42));
		glass.push(box(.04, .4, .9, -.66, 1.12, .1));
		glass.push(box(.04, .4, .9, .66, 1.12, .1));
		lights.push(box(.16, .16, .08, -.28, .55, -1.28));
		lights.push(box(.16, .16, .08, .28, .55, -1.28));
		addW(-.62, .26, .52, .85);
		addW(.62, .26, .52, .85);
		addW(0, .26, -1.05, .8);
	} else if (kind === "truck") {
		body.push(box(2.35, 1.55, 7.2, 0, 1.25, 1.35));
		body.push(box(2.2, 1.7, 2.3, 0, 1.45, -3.15));
		glass.push(box(1.9, .55, .9, 0, 1.9, -3.55));
		lights.push(box(.22, .18, .08, -.8, .85, 4.95));
		lights.push(box(.22, .18, .08, .8, .85, 4.95));
		addW(-1.15, .42, -3.3, 1.2);
		addW(1.15, .42, -3.3, 1.2);
		addW(-1.15, .42, 1.2, 1.2);
		addW(1.15, .42, 1.2, 1.2);
		addW(-1.15, .42, 3.5, 1.2);
		addW(1.15, .42, 3.5, 1.2);
	} else {
		body.push(box(1.72, .48, 4.25, 0, .62, 0));
		body.push(box(1.55, .42, 2.05, 0, 1.05, .28));
		if (kind === "taxi") body.push(box(.34, .16, .34, 0, 1.38, .15));
		glass.push(box(1.4, .36, 1.15, 0, 1.08, -.15));
		lights.push(box(.22, .14, .06, -.62, .72, 2.12));
		lights.push(box(.22, .14, .06, .62, .72, 2.12));
		addW(-.78, .32, -1.35);
		addW(.78, .32, -1.35);
		addW(-.78, .32, 1.28);
		addW(.78, .32, 1.28);
	}
	return {
		body: merge(body),
		glass: merge(glass),
		wheels: merge(wheels),
		lights: merge(lights)
	};
}
function buildPlayer(kind, hex) {
	const g = new Group();
	g.rotation.order = "YXZ";
	const paint = new MeshStandardMaterial({
		color: hex,
		roughness: .46,
		metalness: .12
	});
	const glass = new MeshStandardMaterial({
		color: "#b7dbe3",
		roughness: .08,
		metalness: .35,
		transparent: true,
		opacity: .78
	});
	const dark = new MeshStandardMaterial({
		color: "#17191d",
		roughness: .62
	});
	const tail = new MeshStandardMaterial({
		color: "#ff3b3b",
		emissive: "#ff2020",
		emissiveIntensity: .9
	});
	const head = new MeshStandardMaterial({
		color: "#fff6d8",
		emissive: "#ffe7a8",
		emissiveIntensity: .35
	});
	const wheels = [];
	const put = (geo, mat, x, y, z) => {
		const m = new Mesh(geo, mat);
		m.position.set(x, y, z);
		g.add(m);
		return m;
	};
	const addWheels = (x, z, r) => {
		const geo = new CylinderGeometry(r, r, r * .7, 12);
		geo.rotateZ(Math.PI / 2);
		for (const sx of [-1, 1]) {
			const m = new Mesh(geo, dark);
			m.position.set(sx * x, r, z);
			g.add(m);
			wheels.push(m);
		}
	};
	if (kind === "micro") {
		put(new BoxGeometry(2.05, 1.15, 4.9), paint, 0, 1.05, .05);
		put(new BoxGeometry(1.9, .48, 1.35), glass, 0, 1.78, -.95);
		put(new BoxGeometry(1.75, .4, 2.1), glass, 0, 1.72, .9);
		put(new BoxGeometry(.22, .26, .08), tail, -.72, .95, 2.52);
		put(new BoxGeometry(.22, .26, .08), tail, .72, .95, 2.52);
		put(new BoxGeometry(.42, .22, .08), head, -.65, .95, -2.42);
		put(new BoxGeometry(.42, .22, .08), head, .65, .95, -2.42);
		addWheels(1.02, -1.55, .38);
		addWheels(1.02, 1.5, .38);
	} else if (kind === "tuktuk") {
		const black = dark;
		const chrome = new MeshStandardMaterial({
			color: "#b8c0c8",
			roughness: .22,
			metalness: .88
		});
		const canopyMat = new MeshStandardMaterial({
			color: hex,
			roughness: .55,
			metalness: .06
		});
		const seatMat = new MeshStandardMaterial({
			color: "#2a2e35",
			roughness: .78
		});
		put(new BoxGeometry(1.02, .2, .88), black, 0, .4, -.98);
		put(new BoxGeometry(.95, .12, .55), black, 0, .78, -1.05);
		put(new BoxGeometry(1.34, .52, 1.38), paint, 0, .7, .28);
		put(new BoxGeometry(.07, .38, 1.32), black, -.68, .52, .25);
		put(new BoxGeometry(.07, .38, 1.32), black, .68, .52, .25);
		put(new BoxGeometry(1.24, .16, .48), seatMat, 0, .82, .78);
		put(new BoxGeometry(1.2, .36, .1), seatMat, 0, 1.02, .95);
		put(new BoxGeometry(1.44, .055, 1.62), canopyMat, 0, 1.46, .15);
		put(new BoxGeometry(1.5, .035, 1.68), black, 0, 1.52, .15);
		put(new BoxGeometry(.05, .55, .05), black, -.66, 1.18, -.55);
		put(new BoxGeometry(.05, .55, .05), black, .66, 1.18, -.55);
		put(new BoxGeometry(.05, .55, .05), black, -.66, 1.18, .85);
		put(new BoxGeometry(.05, .55, .05), black, .66, 1.18, .85);
		put(new BoxGeometry(1.18, .5, .04), glass, 0, 1.12, -.45);
		put(new BoxGeometry(.06, .52, .06), black, -.59, 1.12, -.45);
		put(new BoxGeometry(.06, .52, .06), black, .59, 1.12, -.45);
		put(new BoxGeometry(1.22, .05, .05), black, 0, 1.38, -.45);
		put(new BoxGeometry(.04, .45, .95), black, -.69, 1.15, .12);
		put(new BoxGeometry(.04, .45, .95), black, .69, 1.15, .12);
		put(new BoxGeometry(.07, .07, .58), chrome, 0, .92, -.78);
		put(new BoxGeometry(.58, .05, .05), chrome, 0, 1.02, -1.05);
		const lampGeo = new SphereGeometry(.095, 12, 10);
		const lampL = new Mesh(lampGeo, head);
		lampL.position.set(-.28, .55, -1.32);
		const lampR = new Mesh(lampGeo, head);
		lampR.position.set(.28, .55, -1.32);
		g.add(lampL, lampR);
		put(new BoxGeometry(.15, .1, .06), tail, -.48, .62, .98);
		put(new BoxGeometry(.15, .1, .06), tail, .48, .62, .98);
		put(new BoxGeometry(.12, .07, .05), chrome, -.78, 1.12, -.38);
		put(new BoxGeometry(.12, .07, .05), chrome, .78, 1.12, -.38);
		addWheels(.62, .52, .26);
		const geo = new CylinderGeometry(.26, .26, .14, 14);
		geo.rotateZ(Math.PI / 2);
		const m = new Mesh(geo, dark);
		m.position.set(0, .26, -1.08);
		g.add(m);
		wheels.push(m);
		put(new BoxGeometry(.06, .06, .45), chrome, -.55, .35, -.55);
		put(new BoxGeometry(.08, .08, .12), black, -.55, .35, -.8);
		const plate = new MeshStandardMaterial({
			color: "#f5f5f0",
			roughness: .4
		});
		put(new BoxGeometry(.32, .12, .02), plate, 0, .55, .98);
		put(new BoxGeometry(.18, .12, .01), new MeshStandardMaterial({
			color: "#c0392b",
			roughness: .5
		}), -.68, .85, .1);
		put(new BoxGeometry(.14, .1, .01), new MeshStandardMaterial({
			color: "#1a5276",
			roughness: .5
		}), .68, .85, .15);
		const skin = new MeshStandardMaterial({
			color: "#c49a78",
			roughness: .62
		});
		const shirt = new MeshStandardMaterial({
			color: "#1e3a5f",
			roughness: .75
		});
		const driver = new Mesh(new CapsuleGeometry(.115, .2, 3, 6), shirt);
		driver.position.set(.04, .92, -.18);
		const hd = new Mesh(new SphereGeometry(.09, 8, 8), skin);
		hd.position.set(.04, 1.18, -.22);
		g.add(driver, hd);
	} else if (kind === "truck") {
		put(new BoxGeometry(2.4, 1.45, 7.1), paint, 0, 1.2, 1.4);
		put(new BoxGeometry(2.15, 1.55, 2.35), paint, 0, 1.4, -3.1);
		put(new BoxGeometry(1.85, .5, .85), glass, 0, 1.9, -3.5);
		put(new BoxGeometry(.24, .18, .08), tail, -.85, .8, 4.95);
		put(new BoxGeometry(.24, .18, .08), tail, .85, .8, 4.95);
		put(new BoxGeometry(.3, .18, .08), head, -.7, .85, -4.25);
		put(new BoxGeometry(.3, .18, .08), head, .7, .85, -4.25);
		addWheels(1.15, -3.25, .42);
		addWheels(1.15, 1.15, .42);
		addWheels(1.15, 3.45, .42);
	} else {
		put(new BoxGeometry(1.72, .46, 4.3), paint, 0, .62, 0);
		put(new BoxGeometry(1.52, .4, 1.9), paint, 0, 1.02, .32);
		put(new BoxGeometry(1.35, .34, 1.05), glass, 0, 1.05, -.2);
		if (kind === "taxi") {
			const lamp = new MeshStandardMaterial({
				color: "#f0b429",
				emissive: "#f0b429",
				emissiveIntensity: .8
			});
			put(new BoxGeometry(.28, .14, .28), lamp, 0, 1.32, .15);
		}
		put(new BoxGeometry(.24, .14, .06), tail, -.6, .7, 2.16);
		put(new BoxGeometry(.24, .14, .06), tail, .6, .7, 2.16);
		put(new BoxGeometry(.32, .14, .06), head, -.55, .62, -2.16);
		put(new BoxGeometry(.32, .14, .06), head, .55, .62, -2.16);
		addWheels(.78, -1.32, .32);
		addWheels(.78, 1.28, .32);
	}
	const spotL = new SpotLight("#fff1cc", 0, 46, Math.PI / 8, .45, 1);
	spotL.position.set(-.45, .9, -1.6);
	const spotR = new SpotLight("#fff1cc", 0, 46, Math.PI / 8, .45, 1);
	spotR.position.set(.45, .9, -1.6);
	const target = new Object3D();
	target.position.set(0, .4, -18);
	g.add(spotL, spotR, target);
	spotL.target = target;
	spotR.target = target;
	const rider = new Mesh(new CapsuleGeometry(.2, .38, 3, 8), new MeshStandardMaterial({
		color: "#1d3557",
		roughness: .7
	}));
	rider.position.set(.02, 1.22, .28);
	rider.visible = false;
	g.add(rider);
	return {
		group: g,
		wheels,
		paint,
		spots: [spotL, spotR],
		rider
	};
}
function signTexture(title, sub) {
	const c = document.createElement("canvas");
	c.width = 512;
	c.height = 256;
	const g = c.getContext("2d");
	if (!g) return null;
	g.fillStyle = "#163e86";
	g.fillRect(0, 0, 512, 256);
	g.fillStyle = "#f0b429";
	g.fillRect(0, 0, 512, 10);
	g.fillStyle = "#f6f1e7";
	g.direction = "rtl";
	g.textAlign = "center";
	g.font = "800 72px Tajawal, sans-serif";
	g.fillText(title, 256, 120);
	g.font = "500 36px Tajawal, sans-serif";
	g.fillStyle = "#d6e4ff";
	g.fillText(sub, 256, 185);
	const tex = new CanvasTexture(c);
	tex.colorSpace = SRGBColorSpace;
	return tex;
}
var Sfx = class {
	ctx = null;
	gain = null;
	osc = null;
	filter = null;
	on = true;
	unlock() {
		if (!this.ctx) {
			const ctx = new AudioContext();
			const gain = ctx.createGain();
			gain.gain.value = 1e-4;
			const filter = ctx.createBiquadFilter();
			filter.type = "lowpass";
			filter.frequency.value = 240;
			const osc = ctx.createOscillator();
			osc.type = "sawtooth";
			osc.frequency.value = 46;
			osc.connect(filter);
			filter.connect(gain);
			gain.connect(ctx.destination);
			osc.start();
			this.ctx = ctx;
			this.gain = gain;
			this.osc = osc;
			this.filter = filter;
		}
		if (this.ctx.state === "suspended") this.ctx.resume();
	}
	engine(speed, throttle) {
		if (!this.ctx || !this.osc || !this.gain || !this.filter || !this.on) {
			if (this.gain) this.gain.gain.value = 1e-4;
			return;
		}
		const k = Math.abs(speed);
		this.osc.frequency.value = 42 + k * 3.1 + throttle * 18;
		this.filter.frequency.value = 180 + k * 18;
		this.gain.gain.value = .018 + Math.min(.04, k * .0015);
	}
	blip(freq, dur, type, vol) {
		if (!this.ctx || !this.on) return;
		const o = this.ctx.createOscillator();
		const g = this.ctx.createGain();
		o.type = type;
		o.frequency.value = freq;
		g.gain.value = vol;
		o.connect(g);
		g.connect(this.ctx.destination);
		o.start();
		g.gain.exponentialRampToValueAtTime(1e-4, this.ctx.currentTime + dur);
		o.stop(this.ctx.currentTime + dur + .02);
	}
	horn() {
		this.blip(340, .18, "square", .05);
		setTimeout(() => this.blip(280, .16, "square", .04), 90);
	}
	cash() {
		this.blip(660, .08, "sine", .05);
		setTimeout(() => this.blip(880, .1, "sine", .04), 70);
	}
	crash() {
		this.blip(90, .22, "sawtooth", .07);
	}
	radar() {
		this.blip(980, .12, "square", .05);
	}
	stop() {
		if (this.gain) this.gain.gain.value = 1e-4;
		this.ctx?.close();
		this.ctx = null;
	}
};
var defaultCfg = {
	mode: "shift",
	vehicle: "tuktuk",
	night: false,
	density: 1,
	paint: "#f0b429",
	sound: true
};
function mountGame(canvas, map, onHud) {
	const track = buildTrack();
	const save = loadSave();
	const sfx = new Sfx();
	sfx.on = save.sound;
	const renderer = new WebGLRenderer({
		canvas,
		antialias: true,
		alpha: false,
		powerPreference: "high-performance"
	});
	renderer.outputColorSpace = SRGBColorSpace;
	renderer.toneMapping = 4;
	renderer.toneMappingExposure = 1.18;
	renderer.shadowMap.enabled = true;
	renderer.shadowMap.type = 2;
	renderer.setClearColor("#cfd9db");
	const scene = new Scene();
	scene.fog = new Fog("#d8cbb8", 48, 260);
	const camera = new PerspectiveCamera(68, 1, .12, 900);
	const hemi = new HemisphereLight("#f7f0e6", "#9a8468", .95);
	const sun = new DirectionalLight("#ffe8c4", 1.85);
	sun.position.set(-110, 140, 55);
	sun.castShadow = true;
	sun.shadow.mapSize.set(2048, 2048);
	sun.shadow.camera.near = 10;
	sun.shadow.camera.far = 420;
	sun.shadow.camera.left = -180;
	sun.shadow.camera.right = 180;
	sun.shadow.camera.top = 180;
	sun.shadow.camera.bottom = -180;
	sun.shadow.bias = -25e-5;
	scene.add(hemi, sun);
	const ground = new Mesh(new CircleGeometry(980, 64), new MeshStandardMaterial({
		color: "#a89a80",
		roughness: .95,
		metalness: .02
	}));
	ground.rotation.x = -Math.PI / 2;
	ground.position.y = -.08;
	ground.receiveShadow = true;
	scene.add(ground);
	buildRoad(scene, track);
	const buildings = buildCity(scene, track);
	const lamps = buildLamps(scene, track);
	buildPosts(scene, track);
	buildLandmarks(scene, track);
	dressFayoum(scene, track);
	dressStreet(scene, track);
	placePeople(scene, track);
	const signs = [];
	const pools = /* @__PURE__ */ new Map();
	const POOL = 56;
	const glassMat = new MeshStandardMaterial({
		color: "#1c3c48",
		roughness: .18,
		metalness: .2
	});
	const wheelMat = new MeshStandardMaterial({
		color: "#16181c",
		roughness: .7
	});
	const lightMat = new MeshStandardMaterial({
		color: "#ff3030",
		emissive: "#ff2020",
		emissiveIntensity: .85
	});
	for (const kind of KINDS) {
		const ge = trafficGeoms(kind);
		const bodyMat = new MeshStandardMaterial({
			color: "#ffffff",
			roughness: .55,
			metalness: .08
		});
		const mk = (geo, mat) => {
			const m = new InstancedMesh(geo, mat, POOL);
			m.frustumCulled = false;
			m.count = POOL;
			scene.add(m);
			return m;
		};
		pools.set(kind, {
			body: mk(ge.body, bodyMat),
			glass: mk(ge.glass, glassMat),
			wheels: mk(ge.wheels, wheelMat),
			lights: mk(ge.lights, lightMat)
		});
	}
	const dummy = new Object3D();
	const tukColor = new Color("#d4654a");
	const PEOPLE = 64;
	const people = new InstancedMesh(new CapsuleGeometry(.22, .48, 3, 6), new MeshStandardMaterial({
		color: "#ffffff",
		roughness: .78
	}), PEOPLE);
	people.frustumCulled = false;
	scene.add(people);
	const cloth = [
		"#1d3557",
		"#c45c3e",
		"#e6c27a",
		"#2f6f4a",
		"#f6f1e7",
		"#6b3a5d"
	].map((hex) => new Color(hex));
	const hideAll = () => {
		dummy.position.set(0, -20, 0);
		dummy.scale.set(0, 0, 0);
		dummy.updateMatrix();
		for (const p of pools.values()) for (let i = 0; i < POOL; i++) {
			p.body.setMatrixAt(i, dummy.matrix);
			p.glass.setMatrixAt(i, dummy.matrix);
			p.wheels.setMatrixAt(i, dummy.matrix);
			p.lights.setMatrixAt(i, dummy.matrix);
		}
	};
	hideAll();
	let playerMesh = buildPlayer("tuktuk", "#f0b429");
	scene.add(playerMesh.group);
	const sparkGeo = new BoxGeometry(.12, .12, .12);
	const sparkMat = new MeshBasicMaterial({ color: "#f0b429" });
	const sparks = [];
	for (let i = 0; i < 18; i++) {
		const m = new Mesh(sparkGeo, sparkMat);
		m.visible = false;
		scene.add(m);
		sparks.push({
			m,
			v: new Vector3(),
			life: 0
		});
	}
	const keys = /* @__PURE__ */ new Set();
	let probeKeys = null;
	let probeSteer = null;
	const touch = {
		steer: 0,
		throttle: 0,
		brake: 0
	};
	const player = {
		x: 0,
		z: 0,
		yaw: 0,
		speed: 0,
		hint: 0,
		spin: 0
	};
	let cfg = {
		...defaultCfg,
		sound: save.sound
	};
	let phase = "menu";
	let money = 0;
	let km = 0;
	let time = 0;
	let crashes = 0;
	let pax = [];
	let waiting = track.stops.map(() => 2 + Math.floor(Math.random() * 4));
	let serviced = -1;
	let message = "";
	let messageT = 0;
	let alert = null;
	let alertT = 0;
	let hitCd = 0;
	let hornCd = 0;
	let radarCd = 0;
	let tollLatch = false;
	let camMode = 1;
	let shake = 0;
	let steerVis = 0;
	let wheelSpin = 0;
	let saveTick = 0;
	const npcs = [];
	const wrongs = [
		{
			s: 80,
			speed: 7.2,
			lat: 6.4
		},
		{
			s: 260,
			speed: 6.4,
			lat: -6.2
		},
		{
			s: 480,
			speed: 7.6,
			lat: 6.6
		},
		{
			s: 720,
			speed: 6.2,
			lat: -5.8
		},
		{
			s: 940,
			speed: 7,
			lat: 6.1
		}
	];
	const crossers = Array.from({ length: 8 }, (_, i) => ({
		s: track.total * (i + .37) / 8,
		lat: (i % 2 ? 1 : -1) * (ROAD_HALF + .35),
		dir: i % 2 ? -1 : 1,
		wait: i * .4
	}));
	let fuel = 100;
	let gasLatch = false;
	let fuelWarned = false;
	let halfWarned = false;
	let bumpCd = 0;
	let fuelBeep = 0;
	let hitstop = 0;
	let jobs = [];
	let jobIndex = 0;
	const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	const camPos = new Vector3(0, 8, 20);
	const look = new Vector3();
	const desired = new Vector3();
	let last = performance.now();
	let acc = 0;
	let hudAcc = 0;
	let raf = 0;
	let running = true;
	const placeOn = (s, lane) => {
		const sm = track.sample(s);
		const rx = Math.cos(sm.yaw);
		const rz = -Math.sin(sm.yaw);
		const lat = laneLat(lane);
		player.x = sm.x + rx * lat;
		player.z = sm.z + rz * lat;
		player.yaw = sm.yaw;
		player.hint = 0;
		player.speed = 0;
	};
	const bootCinematic = () => {
		placeOn(track.stops[0].s, 1);
		player.speed = 16;
	};
	bootCinematic();
	function densityCount() {
		return cfg.density === 0 ? 16 : cfg.density === 2 ? 40 : 28;
	}
	function spawnTraffic(around) {
		npcs.length = 0;
		const n = densityCount();
		const weights = [
			"tuktuk",
			"tuktuk",
			"tuktuk",
			"micro",
			"micro",
			"taxi",
			"malaky",
			"tuktuk",
			"truck"
		];
		for (let i = 0; i < n; i++) {
			const kind = weights[i % weights.length];
			const spec = vehicleById(kind);
			const col = new Color([
				"#f4f1ea",
				"#cfd3d8",
				"#24527e",
				"#c45c3e",
				"#e6c27a",
				"#3d6b62",
				"#8d939c"
			][i % 7]);
			if (kind === "taxi") col.set("#f0d56a");
			if (kind === "tuktuk") col.set([
				"#f0b429",
				"#17191d",
				"#e23b2b",
				"#f4f1ea"
			][i % 4]);
			if (kind === "micro") col.set([
				"#f4f4f1",
				"#e4e2da",
				"#d5dde3"
			][i % 3]);
			npcs.push({
				alive: true,
				kind,
				s: around + 18 + i * 260 / n + i % 5 * 6,
				lane: i % 4,
				laneTarget: i % 4,
				speed: spec.max * (.45 + i % 5 * .08),
				cruise: spec.max * (.42 + i % 4 * .1),
				brake: 0,
				color: col,
				nextLane: 4 + i % 6
			});
		}
		for (const pool of pools.values()) if (pool.body.instanceColor) pool.body.instanceColor.needsUpdate = true;
	}
	spawnTraffic(track.stops[0].s);
	function burst(x, z) {
		for (const s of sparks) {
			if (s.life > 0) continue;
			s.life = .45;
			s.m.visible = true;
			s.m.position.set(x, .6, z);
			s.v.set((Math.random() - .5) * 8, 2 + Math.random() * 4, (Math.random() - .5) * 8);
		}
	}
	function say(text) {
		message = text;
		messageT = 2.4;
	}
	function flash(kind) {
		alert = kind;
		alertT = .45;
	}
	function swapPlayer(kind, hex) {
		scene.remove(playerMesh.group);
		playerMesh.group.traverse((obj) => {
			const mesh = obj;
			if (mesh.geometry) mesh.geometry.dispose();
		});
		playerMesh = buildPlayer(kind, hex);
		scene.add(playerMesh.group);
		applyDusk(duskNow());
	}
	const skyDay = new Color("#cfd8da");
	const skyNight = new Color("#060a12");
	const sky = new Color();
	const fogDay = new Color("#d4c7b0");
	const fogNight = new Color("#060a12");
	const fogC = new Color();
	const hemiDay = new Color("#f5efe4");
	const hemiNight = new Color("#2a3a50");
	const groundDay = new Color("#a89270");
	const groundNight = new Color("#15100c");
	function applyDusk(t) {
		const n = Math.max(0, Math.min(1, t));
		sky.copy(skyDay).lerp(skyNight, n);
		fogC.copy(fogDay).lerp(fogNight, n);
		renderer.setClearColor(sky);
		const fog = scene.fog;
		fog.color.copy(fogC);
		fog.near = 42 - n * 12;
		fog.far = 240 - n * 80;
		hemi.color.copy(hemiDay).lerp(hemiNight, n);
		hemi.groundColor.copy(groundDay).lerp(groundNight, n);
		hemi.intensity = .92 - n * .72;
		sun.intensity = 1.75 - n * 1.55;
		for (const mat of buildings) mat.emissiveIntensity = n * 1.05;
		lamps.emissiveIntensity = .06 + n * 1.5;
		const spot = .15 + n * 8.5;
		for (const spotL of playerMesh.spots) spotL.intensity = spot;
	}
	function duskNow() {
		if (phase !== "play" && phase !== "pause" && phase !== "summary") return cfg.night ? .92 : .02;
		if (cfg.night) return Math.min(1, .78 + time / 500);
		if (cfg.mode === "shift") return Math.min(1, time / 165.6);
		return .22;
	}
	applyDusk(cfg.night ? .92 : .18);
	function drawSigns() {
		for (const s of signs) {
			scene.remove(s);
			s.geometry.dispose();
			s.material.dispose();
		}
		signs.length = 0;
		for (const stop of track.stops) {
			const tex = signTexture(stop.name, "شارع الفيوم");
			if (!tex) continue;
			const mat = new MeshStandardMaterial({
				map: tex,
				roughness: .6
			});
			const sm = track.sample(stop.s - 70);
			const rx = Math.cos(sm.yaw);
			const rz = -Math.sin(sm.yaw);
			const mesh = new Mesh(new PlaneGeometry(7.2, 3.6), mat);
			mesh.position.set(sm.x + rx * 11.2, 3.3, sm.z + rz * 11.2);
			mesh.rotation.y = sm.yaw;
			scene.add(mesh);
			signs.push(mesh);
		}
		const gasTex = signTexture("بنزينة", "اهدى يمين");
		if (gasTex) {
			const mat = new MeshStandardMaterial({
				map: gasTex,
				roughness: .55
			});
			const sm = track.sample(track.gasS - 36);
			const rx = Math.cos(sm.yaw);
			const rz = -Math.sin(sm.yaw);
			const mesh = new Mesh(new PlaneGeometry(6.4, 3.2), mat);
			mesh.position.set(sm.x + rx * 10.4, 3.1, sm.z + rz * 10.4);
			mesh.rotation.y = sm.yaw;
			scene.add(mesh);
			signs.push(mesh);
		}
	}
	document.fonts?.ready.then(() => {
		drawSigns();
		placeShopSigns(scene, track);
		placeLocalSigns(scene, track);
	});
	function persist() {
		if (money > save.bestMoney) save.bestMoney = money;
		if (km > save.bestKm) save.bestKm = km;
		save.sound = sfx.on;
		writeSave(save);
	}
	function specNow() {
		const base = vehicleById("tuktuk");
		const u = save.upgrades;
		return {
			...base,
			max: base.max + u.motor * 1.65,
			accel: base.accel + u.motor * 1.1,
			turn: base.turn + u.tires * .18,
			fare: base.fare * (1 + u.seats * .22),
			name: "توكتوك"
		};
	}
	function pay(cost) {
		if (money >= cost) {
			money -= cost;
			return true;
		}
		if (money + save.wallet >= cost) {
			save.wallet -= cost - money;
			money = 0;
			return true;
		}
		return false;
	}
	function rollJobs(fromStop) {
		jobs = [];
		let i = fromStop;
		for (let k = 0; k < 4; k++) {
			const hop = 2 + Math.floor(Math.random() * 3);
			i = (i + hop) % track.stops.length;
			jobs.push(i);
		}
		jobIndex = 0;
	}
	function resetRun(startS) {
		money = 0;
		km = 0;
		time = 0;
		crashes = 0;
		fuel = 100;
		gasLatch = false;
		fuelWarned = false;
		halfWarned = false;
		bumpCd = 0;
		pax = [];
		waiting = track.stops.map(() => 1 + Math.floor(Math.random() * 4));
		serviced = -1;
		hitCd = 0;
		radarCd = 0;
		tollLatch = false;
		message = "";
		alert = null;
		placeOn(startS, 2);
		spawnTraffic(startS);
		const here = track.stops.reduce((best, stop, i) => {
			const d = Math.abs(stop.s - startS);
			return d < best.d ? {
				d,
				i
			} : best;
		}, {
			d: Infinity,
			i: 0
		}).i;
		rollJobs(here);
		if (cfg.mode === "shift") say("سدّد الإيجار قبل ما الشمس تغيب — شارع الفيوم");
		else if (cfg.mode === "rush") say(`أول توصيلة: ${track.stops[jobs[0]].name}`);
		else say("لف في شارع الفيوم براحتك، خلي بالك من البنزين والمطبات");
	}
	function settle() {
		if (money > save.bestMoney) save.bestMoney = money;
		if (km > save.bestKm) save.bestKm = km;
		if (cfg.mode === "shift") {
			if (money >= 160) {
				save.wallet += money - 160;
				say("الإيجار اتسدد");
				sfx.cash();
			} else if (save.wallet >= 160 - money) {
				save.wallet -= 160 - money;
				say("كمّلت الإيجار من المحفظة");
			} else say(`فاضل ${160 - money - save.wallet} ج على الإيجار`);
		} else if (cfg.mode === "rush") {
			save.wallet += money;
			if (jobIndex >= 4) {
				if (save.bestTrial == null || time < save.bestTrial) {
					save.bestTrial = time;
					say("رقم جديد في التوصيلات");
				} else say("خلّصت الأربع توصيلات");
				sfx.cash();
			} else say("وقفت التوصيلات");
		} else {
			save.wallet += Math.max(0, money);
			say("خلّصت اللفة");
		}
		persist();
	}
	function start(next) {
		cfg = {
			...next,
			vehicle: "tuktuk"
		};
		sfx.on = cfg.sound;
		swapPlayer("tuktuk", cfg.paint);
		phase = "play";
		resetRun(track.stops[0].s + 18);
		sfx.unlock();
		publish();
	}
	function forwardDist(targetS, fromS) {
		let d = targetS - fromS;
		while (d < 0) d += track.total;
		while (d >= track.total) d -= track.total;
		return d;
	}
	function hud() {
		const spec = specNow();
		const proj = track.project(player.x, player.z, player.hint);
		let bestI = 0;
		let bestD = Infinity;
		for (let i = 0; i < track.stops.length; i++) {
			const d = forwardDist(track.stops[i].s, proj.s);
			if (d < bestD) {
				bestD = d;
				bestI = i;
			}
		}
		let targetI = bestI;
		let targetD = bestD;
		if (cfg.mode === "rush" && jobs[jobIndex] != null) {
			targetI = jobs[jobIndex];
			targetD = forwardDist(track.stops[targetI].s, proj.s);
		}
		const stop = track.stops[targetI];
		let hint = "";
		if (phase === "play") {
			const gasD = Math.abs(wrapDelta(track.gasS, proj.s, track.total));
			const speeding = Math.abs(player.speed) > RADAR_LIMIT;
			const nearRadar = track.radarS.some((rs) => Math.abs(wrapDelta(rs, proj.s, track.total)) < 42);
			const crossing = crossers.some((c) => c.wait <= 0 && Math.abs(c.lat) < 8.15 && Math.abs(wrapDelta(c.s, proj.s, track.total)) < 18 && Math.abs(c.lat - proj.lat) < 4);
			const bridgeD = Math.abs(wrapDelta(track.stops[0].s, proj.s, track.total));
			if (crossing) hint = "حد بيعدّي قدامك";
			else if (fuel < 22 && gasD < 90) hint = "البنزينة على اليمين";
			else if (speeding && nearRadar) hint = "هدّي، فيه رادار قدام";
			else if (cfg.mode === "rush") {
				if (targetD < 80 && proj.lat < 3.2) hint = "اهدى يمين عند المحطة";
				else if (targetD < 35) hint = "المحطة قدامك — هدّي";
			} else {
				const relevant = waiting[targetI] > 0 || pax.some((person) => person.dest === targetI);
				if (relevant && targetD < 90 && proj.lat < 3.2) hint = "خش يمين وهدّي";
				else if (relevant && targetD < 40 && player.speed > 4.5) hint = "هدّي عند المحطة";
				else if (Math.abs(player.speed) > 12 && proj.lat > 2.8) hint = "الرصيف مليان إشغالات";
			}
			if (!hint && bridgeD < 55) hint = "زحمة تحت الكوبري";
		}
		return {
			phase,
			speed: Math.round(Math.abs(player.speed) * 3.6),
			money: Math.round(money),
			km: Math.round(km * 10) / 10,
			time,
			crashes,
			passengers: pax.map((person) => ({ dest: track.stops[person.dest].name })),
			seats: spec.seats,
			stopName: stop?.name ?? "",
			stopDist: Math.max(0, Math.round(targetD)),
			hint,
			mode: cfg.mode,
			vehicleName: spec.name,
			message: messageT > 0 ? message : "",
			alert: alertT > 0 ? alert : null,
			fuel: Math.max(0, Math.min(100, fuel)),
			rent: 160,
			shiftLeft: Math.max(0, 180 - time),
			wallet: save.wallet,
			upgrades: save.upgrades,
			lowFuel: fuel <= 18,
			jobsDone: jobIndex,
			jobsNeed: 4,
			jobName: jobs[jobIndex] != null ? track.stops[jobs[jobIndex]].name : "خلّصت",
			bestMoney: Math.round(save.bestMoney),
			bestKm: Math.round(save.bestKm * 10) / 10,
			bestTrial: save.bestTrial,
			night: cfg.night,
			sound: sfx.on,
			progress: proj.s / track.total
		};
	}
	function publish() {
		onHud(hud());
	}
	function step(dt) {
		const spec = specNow();
		const down = (code) => probeKeys ? probeKeys.has(code) : keys.has(code);
		let steer = 0;
		let throttle = 0;
		let brake = 0;
		if (phase === "play") {
			if (probeSteer != null) steer = probeSteer;
			else {
				if (down("KeyA") || down("ArrowLeft")) steer += 1;
				if (down("KeyD") || down("ArrowRight")) steer -= 1;
				steer += touch.steer;
			}
			if (down("KeyW") || down("ArrowUp")) throttle = 1;
			if (down("KeyS") || down("ArrowDown")) brake = 1;
			throttle = Math.max(throttle, touch.throttle);
			brake = Math.max(brake, touch.brake);
			steer = Math.max(-1, Math.min(1, steer));
		} else if (phase === "menu") {
			throttle = .62;
			const proj0 = track.project(player.x, player.z, player.hint);
			const err = laneLat(1) - proj0.lat;
			const dy = wrapAngle(proj0.yaw - player.yaw);
			steer = Math.max(-1, Math.min(1, err * .18 + dy * 1.4));
		}
		steerVis = steer;
		if (phase === "play" || phase === "menu") {
			if (throttle > 0 && brake === 0) player.speed += spec.accel * throttle * dt;
			else if (brake > 0) {
				if (player.speed > .5) player.speed -= spec.brake * dt;
				else player.speed -= spec.accel * .45 * dt;
			} else {
				const sign = Math.sign(player.speed);
				const mag = Math.max(0, Math.abs(player.speed) - 3.2 * dt);
				player.speed = sign * mag;
			}
			const cap = phase === "play" && fuel <= 0 ? 3.3 : spec.max;
			player.speed = Math.max(-6, Math.min(cap, player.speed));
			const sp = Math.min(1, Math.abs(player.speed) / 7);
			const reverse = player.speed < -.5 ? -1 : 1;
			const turnMul = .35 + .65 * sp;
			player.yaw += steer * spec.turn * turnMul * reverse * dt;
			const fx = -Math.sin(player.yaw);
			const fz = -Math.cos(player.yaw);
			player.x += fx * player.speed * dt;
			player.z += fz * player.speed * dt;
			const proj = track.project(player.x, player.z, player.hint);
			player.hint = proj.i;
			const limit = ROAD_HALF - spec.width * .5;
			if (Math.abs(proj.lat) > limit) {
				const clamped = Math.sign(proj.lat) * limit;
				const rx = Math.cos(proj.yaw);
				const rz = -Math.sin(proj.yaw);
				player.x = proj.x + rx * clamped;
				player.z = proj.z + rz * clamped;
				if (Math.abs(proj.lat) - limit > .08) {
					player.speed *= .9;
					shake = Math.max(shake, .12);
				}
			}
			const along = (() => {
				const tx = -Math.sin(proj.yaw);
				const tz = -Math.cos(proj.yaw);
				return (fx * tx + fz * tz) * player.speed;
			})();
			if (phase === "play") {
				if (along > 0) km += along * dt / 1e3;
				time += dt;
				const eff = 1 - save.upgrades.fuel * .18;
				const moving = Math.abs(player.speed) > .35 ? 1 : .15;
				fuel -= (.38 * moving + throttle * .72) * eff * dt;
				if (fuel < 0) fuel = 0;
				if (Math.abs(wrapDelta(track.stops[0].s, proj.s, track.total)) < 78 && player.speed > 9) player.speed += (9 - player.speed) * Math.min(1, dt * 2.4);
				if (hitCd <= 0) {
					for (const occ of OCCUPATIONS) if (Math.abs(wrapDelta(occ.s, proj.s, track.total)) < 2.1 && Math.abs(proj.lat - occ.lat) < 1.2) {
						player.speed *= .42;
						shake = Math.max(shake, .22);
						hitCd = .75;
						if (messageT <= 0) say("إشغال في الحارة — خد جنبك");
						sfx.blip(90, .05, "square", .03);
						break;
					}
				}
				fuelBeep = Math.max(0, fuelBeep - dt);
				if (fuel < 12 && fuelBeep <= 0) {
					fuelBeep = 3.2;
					sfx.blip(540, .05, "square", .028);
				}
			}
		}
		hitCd = Math.max(0, hitCd - dt);
		hornCd = Math.max(0, hornCd - dt);
		radarCd = Math.max(0, radarCd - dt);
		bumpCd = Math.max(0, bumpCd - dt);
		messageT = Math.max(0, messageT - dt);
		alertT = Math.max(0, alertT - dt);
		shake = Math.max(0, shake - dt);
		updateNpcs(dt, spec.length);
		updateCrossers(dt);
		if (phase === "play") gameplay(dt);
		sfx.engine(player.speed, throttle);
		saveTick += dt;
		if (saveTick > 1.2) {
			saveTick = 0;
			if (money > save.bestMoney) save.bestMoney = money;
			if (km > save.bestKm) save.bestKm = km;
			writeSave(save);
		}
	}
	function updateNpcs(dt, _len) {
		const proj = track.project(player.x, player.z, player.hint);
		for (const n of npcs) {
			if (!n.alive) continue;
			const spec = vehicleById(n.kind);
			let target = n.cruise;
			if (Math.abs(wrapDelta(n.s, track.stops[0].s, track.total)) < 95) target = Math.min(target, 4.2);
			const ahead = wrapDelta(n.s, proj.s, track.total);
			if (n.kind === "micro") {
				for (const stop of track.stops) {
					const d = wrapDelta(stop.s, n.s, track.total);
					if (d > 0 && d < 36 && n.lane > 1.5) target = Math.min(target, 3.5);
				}
				n.brake -= dt;
				if (n.brake <= 0 && Math.random() < dt * .15) n.brake = 1.3;
				if (n.brake > 0) target = Math.min(target, 2.2);
			}
			for (const o of npcs) {
				if (o === n || !o.alive) continue;
				if (Math.abs(o.lane - n.lane) > .75) continue;
				const gap = wrapDelta(o.s, n.s, track.total);
				if (gap > 0 && gap < 14) target = Math.min(target, o.speed * .92);
			}
			n.speed += (target - n.speed) * Math.min(1, dt * 1.4);
			n.speed = Math.max(2, n.speed);
			n.s += n.speed * dt;
			n.nextLane -= dt;
			if (n.nextLane <= 0) {
				n.nextLane = 3 + Math.random() * 5;
				const dir = Math.random() < .5 ? -1 : 1;
				n.laneTarget = Math.max(0, Math.min(3, Math.round(n.lane + dir)));
				if (n.kind === "tuktuk" && Math.random() < .4) n.laneTarget = Math.random() < .5 ? 0 : 3;
			}
			if (!npcs.some((o) => {
				if (o === n) return false;
				return Math.abs(o.lane - n.laneTarget) < .4 && Math.abs(wrapDelta(o.s, n.s, track.total)) < 8;
			})) {
				const diff = n.laneTarget - n.lane;
				const stepL = Math.max(-1, Math.min(1, diff)) * dt * .85;
				n.lane += stepL;
			}
			if (ahead < -30 || ahead > 340) {
				n.s = proj.s + 180 + Math.random() * 150;
				n.lane = Math.floor(Math.random() * 4);
				n.laneTarget = n.lane;
				n.cruise = spec.max * (.4 + Math.random() * .35);
			}
		}
		for (const w of wrongs) {
			w.s -= w.speed * dt;
			if (wrapDelta(w.s, proj.s, track.total) < -40) w.s = proj.s + 160 + Math.random() * 80;
			if (phase !== "play" || hitCd > 0) continue;
			const sm = track.sample(w.s);
			const rx = Math.cos(sm.yaw);
			const rz = -Math.sin(sm.yaw);
			const x = sm.x + rx * w.lat;
			const z = sm.z + rz * w.lat;
			const d = Math.hypot(player.x - x, player.z - z);
			if (d < specNow().length * .42 + 1.3) collide(d, player.x - x, player.z - z, 10);
		}
	}
	function updateCrossers(dt) {
		const proj = track.project(player.x, player.z, player.hint);
		for (const c of crossers) {
			if (c.wait > 0) {
				c.wait -= dt;
				continue;
			}
			c.lat += c.dir * 1.55 * dt;
			if (Math.abs(c.lat) > 9) {
				c.dir *= -1;
				c.lat = Math.sign(c.lat) * (ROAD_HALF + .75);
				c.wait = 2.4 + Math.random() * 3.2;
			}
			if (phase !== "play" || hitCd > 0) continue;
			if (Math.abs(player.speed) < 2.4) continue;
			if (Math.abs(wrapDelta(c.s, proj.s, track.total)) > 1.7) continue;
			if (Math.abs(c.lat - proj.lat) > 1.05) continue;
			player.speed *= .38;
			shake = Math.max(shake, .28);
			hitCd = .9;
			crashes += 1;
			if (cfg.mode === "rush") {
				time += 1;
				say("حد بيعدّي +١ ث");
			} else if (cfg.mode === "shift") {
				money = Math.max(0, money - 20);
				say("خد بالك، فيه ناس بتعدّي — ٢٠ ج");
			} else say("حد بيعدّي — هدّي");
			flash("crash");
			sfx.blip(170, .08, "square", .045);
		}
	}
	function collide(dist, dx, dz, otherSpeed) {
		specNow();
		const d = Math.max(.001, dist);
		const push = .8;
		player.x += dx / d * push;
		player.z += dz / d * push;
		const rel = Math.abs(player.speed - otherSpeed);
		player.speed *= .62;
		hitCd = .65;
		shake = .35;
		if (rel > 5 && phase === "play") {
			crashes += 1;
			player.yaw += (Math.random() - .5) * .35;
			if (cfg.mode === "shift") {
				money = Math.max(0, money - 40);
				if (pax.length) {
					pax.pop();
					say("راكب نزل غصب — غرامة");
				} else say("خبطة! غرامة ٤٠ ج");
			} else if (cfg.mode === "rush") {
				time += 2;
				say("خبطة +٢ ث");
			} else say("خبطة! خد بالك");
			flash("crash");
			hitstop = reduceMotion ? 0 : .06;
			sfx.crash();
			burst(player.x, player.z);
		}
	}
	function gameplay(dt) {
		const spec = specNow();
		const proj = track.project(player.x, player.z, player.hint);
		for (const n of npcs) {
			if (!n.alive || hitCd > 0) continue;
			const sm = track.sample(n.s);
			const rx = Math.cos(sm.yaw);
			const rz = -Math.sin(sm.yaw);
			const lat = laneLat(n.lane);
			const x = sm.x + rx * lat;
			const z = sm.z + rz * lat;
			const reach = spec.length * .42 + vehicleById(n.kind).length * .4;
			const d = Math.hypot(player.x - x, player.z - z);
			if (d < reach) {
				n.speed *= .75;
				collide(d, player.x - x, player.z - z, n.speed);
				break;
			}
		}
		if (hornCd > .15) for (const n of npcs) {
			const gap = wrapDelta(n.s, proj.s, track.total);
			if (gap > 0 && gap < 22 && Math.abs(laneLat(n.lane) - proj.lat) < 4) n.laneTarget = proj.lat > laneLat(n.lane) ? Math.max(0, n.lane - 1) : Math.min(3, n.lane + 1);
		}
		const nearStop = (index) => {
			return Math.abs(wrapDelta(track.stops[index].s, proj.s, track.total)) < 20 && proj.lat > 3.05 && Math.abs(player.speed) < 4.6;
		};
		if (serviced >= 0) {
			if (Math.abs(wrapDelta(track.stops[serviced].s, proj.s, track.total)) > 36) {
				if (waiting[serviced] <= 0) waiting[serviced] = 1 + Math.floor(Math.random() * 5);
				serviced = -1;
			}
		}
		if (cfg.mode !== "rush" && spec.seats > 0) for (let i = 0; i < track.stops.length; i++) {
			if (!nearStop(i) || serviced === i) continue;
			const dropping = pax.filter((person) => person.dest === i);
			if (dropping.length) {
				const earned = Math.round(dropping.length * 36 * spec.fare);
				money += earned;
				pax = pax.filter((person) => person.dest !== i);
				say(`نزلوا — +${earned} ج`);
				flash("cash");
				sfx.cash();
			}
			const free = spec.seats - pax.length;
			if (free > 0 && waiting[i] > 0) {
				const n = Math.min(free, waiting[i]);
				let lastDest = i;
				for (let k = 0; k < n; k++) {
					const hop = 2 + Math.floor(Math.random() * 3);
					lastDest = (i + hop) % track.stops.length;
					pax.push({ dest: lastDest });
				}
				waiting[i] -= n;
				say(`ركّبت ${n} · ${track.stops[lastDest].name}`);
				sfx.cash();
			}
			serviced = i;
		}
		if (cfg.mode === "rush" && phase === "play" && jobs[jobIndex] != null && nearStop(jobs[jobIndex])) {
			jobIndex += 1;
			money += 45;
			flash("cash");
			sfx.cash();
			if (jobIndex >= 4) {
				phase = "summary";
				settle();
				publish();
				return;
			}
			say(`وصلت — الجاية ${track.stops[jobs[jobIndex]].name}`);
		}
		if (radarCd <= 0) {
			for (const rs of track.radarS) if (Math.abs(wrapDelta(rs, proj.s, track.total)) < 16 && Math.abs(player.speed) > RADAR_LIMIT) {
				radarCd = 8;
				flash("radar");
				sfx.radar();
				const which = track.radarS.indexOf(rs);
				if (cfg.mode === "rush") {
					time += 1.5;
					say(which === 1 ? "كمين +١.٥ ث" : "رادار +١.٥ ث");
				} else {
					money = Math.max(0, money - 70);
					say(which === 1 ? "كمين! غرامة ٧٠ ج" : "رادار! غرامة ٧٠ ج");
				}
				break;
			}
		}
		const tollD = wrapDelta(track.tollS, proj.s, track.total);
		if (tollD > -8 && tollD < 16) {
			if (!tollLatch && player.speed > TOLL_LIMIT) {
				tollLatch = true;
				player.speed = Math.min(player.speed, TOLL_LIMIT);
				if (cfg.mode === "rush") {
					time += 1;
					say("الكوبري عايز تهدية");
				} else {
					money = Math.max(0, money - 15);
					say("نقطة مرور الكوبري — ١٥ ج");
				}
			}
		} else if (Math.abs(tollD) > 40) tollLatch = false;
		const gasD = Math.abs(wrapDelta(track.gasS, proj.s, track.total));
		if (gasD < 16 && proj.lat > 2.5 && Math.abs(player.speed) < 3.8 && fuel < 96) {
			if (!gasLatch) {
				if (pay(22)) {
					fuel = 100;
					fuelWarned = false;
					gasLatch = true;
					say(`تملى التانك — 22 ج`);
					flash("cash");
					sfx.cash();
				} else {
					gasLatch = true;
					say("الفلوس مش مكفية البنزين");
				}
			}
		} else if (gasD > 30) gasLatch = false;
		if (bumpCd <= 0) {
			for (const b of track.bumps) if (Math.abs(wrapDelta(b, proj.s, track.total)) < 2.5 && Math.abs(player.speed) > 8) {
				bumpCd = 1.15;
				player.speed *= .55;
				shake = Math.max(shake, reduceMotion ? 0 : .3);
				if (messageT <= 0) say("مطب!");
				sfx.blip(120, .07, "triangle", .04);
				burst(player.x, player.z);
				break;
			}
		}
		if (phase === "play" && fuel <= 0 && !fuelWarned) {
			fuelWarned = true;
			say("البنزين خلّص — دور على البنزينة");
			flash("fuel");
		}
		if (phase === "play" && cfg.mode === "shift" && !halfWarned && time >= 150) {
			halfWarned = true;
			say("فاضل نص دقيقة");
		}
		if (phase === "play" && cfg.mode === "shift" && time >= 180) {
			phase = "summary";
			settle();
			publish();
			return;
		}
		if (alongWrong(proj) && messageT <= 0) say("إنت عكس الاتجاه");
	}
	function alongWrong(proj) {
		const fx = -Math.sin(player.yaw);
		const fz = -Math.cos(player.yaw);
		const tx = -Math.sin(proj.yaw);
		const tz = -Math.cos(proj.yaw);
		return fx * tx + fz * tz < -.45 && Math.abs(player.speed) > 3;
	}
	function drawPeople() {
		let i = 0;
		const bobT = performance.now() / 1e3;
		for (let sIdx = 0; sIdx < track.stops.length; sIdx++) {
			const n = Math.min(3, waiting[sIdx] ?? 0);
			const sm = track.sample(track.stops[sIdx].s);
			const rx = Math.cos(sm.yaw);
			const rz = -Math.sin(sm.yaw);
			for (let k = 0; k < n; k++) {
				const bob = Math.sin(bobT * 2.2 + sIdx + k) * .04;
				dummy.position.set(sm.x + rx * (7.15 + k * .72), .64 + bob, sm.z + rz * (7.15 + k * .72));
				dummy.rotation.set(0, sm.yaw + k, 0);
				dummy.scale.set(1, 1, 1);
				dummy.updateMatrix();
				people.setMatrixAt(i, dummy.matrix);
				people.setColorAt(i, cloth[(sIdx + k) % cloth.length]);
				i += 1;
			}
		}
		for (const c of crossers) {
			if (i >= PEOPLE) break;
			const sm = track.sample(c.s);
			const rx = Math.cos(sm.yaw);
			const rz = -Math.sin(sm.yaw);
			const bob = Math.sin(bobT * 4.2 + c.s) * .05;
			dummy.position.set(sm.x + rx * c.lat, .72 + bob, sm.z + rz * c.lat);
			dummy.rotation.set(0, sm.yaw + (c.dir > 0 ? Math.PI / 2 : -Math.PI / 2), 0);
			dummy.scale.set(.82, 1.2, .82);
			dummy.updateMatrix();
			people.setMatrixAt(i, dummy.matrix);
			people.setColorAt(i, cloth[i % cloth.length]);
			i += 1;
		}
		for (let k = 0; k < 8 && i < PEOPLE; k++) {
			const dir = k % 2 === 0 ? 1 : -1;
			const sm = track.sample(bobT * 1.6 * dir + k * 97);
			const rx = Math.cos(sm.yaw);
			const rz = -Math.sin(sm.yaw);
			const lat = (k % 2 === 0 ? 1 : -1) * (6.15 + k % 3 * .28);
			const bob = Math.sin(bobT * 3.1 + k) * .05;
			dummy.position.set(sm.x + rx * lat, .64 + bob, sm.z + rz * lat);
			dummy.rotation.set(0, sm.yaw, 0);
			dummy.scale.set(.92, 1, .92);
			dummy.updateMatrix();
			people.setMatrixAt(i, dummy.matrix);
			people.setColorAt(i, cloth[k % cloth.length]);
			i += 1;
		}
		dummy.scale.set(0, 0, 0);
		dummy.position.set(0, -24, 0);
		dummy.updateMatrix();
		for (; i < PEOPLE; i++) people.setMatrixAt(i, dummy.matrix);
		people.instanceMatrix.needsUpdate = true;
		if (people.instanceColor) people.instanceColor.needsUpdate = true;
	}
	function render(dt) {
		applyDusk(duskNow());
		const fwX = -Math.sin(player.yaw);
		const fwZ = -Math.cos(player.yaw);
		const dist = camMode === 0 ? 6.5 : camMode === 2 ? 16 : camMode === 3 ? .2 : 11;
		const height = camMode === 3 ? 1.35 : 3.1 + camMode * .45;
		const back = camMode === 3 ? -1.15 : dist;
		desired.set(player.x - fwX * back, height, player.z - fwZ * back);
		if (shake > 0 && !reduceMotion) {
			desired.x += (Math.random() - .5) * shake * 1.4;
			desired.y += (Math.random() - .5) * shake;
		}
		const k = 1 - Math.exp(-5 * dt);
		camPos.lerp(desired, phase === "menu" ? Math.min(1, k * 1.2) : k);
		camera.position.copy(camPos);
		const lookAhead = camMode === 3 ? 14 : 7;
		look.set(player.x + fwX * lookAhead, camMode === 3 ? 1.1 : 1.2, player.z + fwZ * lookAhead);
		camera.lookAt(look);
		camera.fov = (camMode === 3 ? 78 : 68) + Math.min(1, Math.abs(player.speed) / 30) * 8;
		camera.updateProjectionMatrix();
		playerMesh.group.position.set(player.x, 0, player.z);
		playerMesh.group.rotation.y = player.yaw;
		playerMesh.group.rotation.z = steerVis * -.045;
		playerMesh.group.rotation.x = (player.speed > 1 ? -.02 : .03) * Math.min(1, Math.abs(player.speed) / 20);
		wheelSpin += player.speed * dt * 2.2;
		for (const w of playerMesh.wheels) w.rotation.x = wheelSpin;
		playerMesh.rider.visible = pax.length > 0 && phase !== "menu";
		const cursors = {
			malaky: 0,
			taxi: 0,
			micro: 0,
			tuktuk: 0,
			truck: 0
		};
		const paintNpc = (kind, s, yaw, lat, color) => {
			const pool = pools.get(kind);
			const i = cursors[kind]++;
			if (i >= POOL) return;
			const sm = track.sample(s);
			const rx = Math.cos(sm.yaw);
			const rz = -Math.sin(sm.yaw);
			dummy.position.set(sm.x + rx * lat, 0, sm.z + rz * lat);
			dummy.rotation.set(0, yaw, 0);
			dummy.scale.set(1, 1, 1);
			dummy.updateMatrix();
			pool.body.setMatrixAt(i, dummy.matrix);
			pool.glass.setMatrixAt(i, dummy.matrix);
			pool.wheels.setMatrixAt(i, dummy.matrix);
			pool.lights.setMatrixAt(i, dummy.matrix);
			if (color) pool.body.setColorAt(i, color);
		};
		for (const n of npcs) {
			if (!n.alive) continue;
			const sm = track.sample(n.s);
			paintNpc(n.kind, n.s, sm.yaw, laneLat(n.lane), n.color);
		}
		for (const w of wrongs) {
			const sm = track.sample(w.s);
			paintNpc("tuktuk", w.s, sm.yaw + Math.PI, w.lat, tukColor);
		}
		dummy.scale.set(0, 0, 0);
		dummy.position.set(0, -30, 0);
		dummy.updateMatrix();
		for (const kind of KINDS) {
			const pool = pools.get(kind);
			for (let i = cursors[kind]; i < POOL; i++) {
				pool.body.setMatrixAt(i, dummy.matrix);
				pool.glass.setMatrixAt(i, dummy.matrix);
				pool.wheels.setMatrixAt(i, dummy.matrix);
				pool.lights.setMatrixAt(i, dummy.matrix);
			}
			pool.body.instanceMatrix.needsUpdate = true;
			pool.glass.instanceMatrix.needsUpdate = true;
			pool.wheels.instanceMatrix.needsUpdate = true;
			pool.lights.instanceMatrix.needsUpdate = true;
			if (pool.body.instanceColor) pool.body.instanceColor.needsUpdate = true;
		}
		drawPeople();
		for (const spark of sparks) {
			if (spark.life <= 0) continue;
			spark.life -= dt;
			spark.v.y -= 9 * dt;
			spark.m.position.addScaledVector(spark.v, dt);
			if (spark.life <= 0) spark.m.visible = false;
		}
		drawMap();
		renderer.render(scene, camera);
	}
	const mapPts = track.pts.filter((_, i) => i % 2 === 0);
	let minX = Infinity;
	let maxX = -Infinity;
	let minZ = Infinity;
	let maxZ = -Infinity;
	for (const p of mapPts) {
		minX = Math.min(minX, p.x);
		maxX = Math.max(maxX, p.x);
		minZ = Math.min(minZ, p.z);
		maxZ = Math.max(maxZ, p.z);
	}
	function drawMap() {
		const ctx = map.getContext("2d");
		if (!ctx) return;
		const w = map.width;
		const h = map.height;
		ctx.clearRect(0, 0, w, h);
		ctx.fillStyle = "rgba(20,24,30,0.72)";
		ctx.beginPath();
		ctx.arc(w / 2, h / 2, w / 2 - 2, 0, Math.PI * 2);
		ctx.fill();
		const sx = (w - 32) / (maxX - minX || 1);
		const sy = (h - 32) / (maxZ - minZ || 1);
		const sc = Math.min(sx, sy);
		const ox = w / 2 - (minX + maxX) / 2 * sc;
		const oy = h / 2 - (minZ + maxZ) / 2 * sc;
		const px = (x, z) => [ox + x * sc, oy + z * sc];
		ctx.beginPath();
		mapPts.forEach((p, i) => {
			const [x, y] = px(p.x, p.z);
			if (i === 0) ctx.moveTo(x, y);
			else ctx.lineTo(x, y);
		});
		ctx.closePath();
		ctx.strokeStyle = "#f0b429";
		ctx.lineWidth = 3;
		ctx.stroke();
		ctx.fillStyle = "#1aa6a6";
		track.stops.forEach((stop, i) => {
			const sm = track.sample(stop.s);
			const [x, y] = px(sm.x, sm.z);
			const hot = cfg.mode === "rush" ? jobs[jobIndex] === i : false;
			ctx.fillStyle = hot ? "#f0b429" : "#1aa6a6";
			ctx.fillRect(x - (hot ? 3 : 1.6), y - (hot ? 3 : 1.6), hot ? 6 : 3.2, hot ? 6 : 3.2);
		});
		const gas = track.sample(track.gasS);
		const [gx, gy] = px(gas.x, gas.z);
		ctx.fillStyle = "#f0b429";
		ctx.beginPath();
		ctx.arc(gx, gy, 3.2, 0, Math.PI * 2);
		ctx.fill();
		const [x, y] = px(player.x, player.z);
		ctx.fillStyle = "#f6f1e7";
		ctx.beginPath();
		ctx.arc(x, y, 3.5, 0, Math.PI * 2);
		ctx.fill();
		const fx = -Math.sin(player.yaw);
		const fz = -Math.cos(player.yaw);
		const [hx, hy] = px(player.x + fx * 22, player.z + fz * 22);
		ctx.strokeStyle = "#f6f1e7";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.moveTo(x, y);
		ctx.lineTo(hx, hy);
		ctx.stroke();
	}
	function frame(now) {
		if (!running) return;
		const dt = Math.min(.05, (now - last) / 1e3);
		last = now;
		acc += dt;
		let steps = 0;
		while (acc >= 1 / 60 && steps < 5) {
			if (hitstop > 0) hitstop = Math.max(0, hitstop - 1 / 60);
			else if (phase !== "pause" && phase !== "summary") step(1 / 60);
			acc -= 1 / 60;
			steps++;
		}
		render(dt);
		hudAcc += dt;
		if (hudAcc > .12) {
			hudAcc = 0;
			if (phase === "play" || phase === "summary" || phase === "pause") publish();
		}
		raf = requestAnimationFrame(frame);
	}
	function resize() {
		const w = canvas.clientWidth || 1;
		const h = canvas.clientHeight || 1;
		const dpr = Math.min(window.devicePixelRatio || 1, 1.6);
		renderer.setPixelRatio(dpr);
		renderer.setSize(w, h, false);
		camera.aspect = w / h;
		camera.updateProjectionMatrix();
	}
	resize();
	const ro = new ResizeObserver(() => resize());
	ro.observe(canvas);
	const onDown = (e) => {
		if ([
			"Space",
			"ArrowUp",
			"ArrowDown",
			"ArrowLeft",
			"ArrowRight"
		].includes(e.code)) e.preventDefault();
		keys.add(e.code);
		if (e.repeat) return;
		if (e.code === "Space" || e.code === "KeyH") honk();
		if (e.code === "KeyC") cycleCam();
		if (e.code === "Escape") {
			if (phase === "play") phase = "pause";
			else if (phase === "pause") phase = "play";
			publish();
		}
	};
	const onUp = (e) => keys.delete(e.code);
	const onBlur = () => keys.clear();
	window.addEventListener("keydown", onDown);
	window.addEventListener("keyup", onUp);
	window.addEventListener("blur", onBlur);
	function honk() {
		if (hornCd > 0) return;
		hornCd = .85;
		sfx.unlock();
		sfx.horn();
	}
	function cycleCam() {
		camMode = (camMode + 1) % 4;
	}
	window.__controlsTest = {
		getYaw: () => player.yaw,
		getSpeed: () => player.speed,
		setKeys: (codes) => {
			probeKeys = codes.length ? new Set(codes) : null;
			if (probeKeys && phase !== "play") start(cfg);
		},
		setSteer: (v) => {
			probeSteer = v;
		}
	};
	publish();
	raf = requestAnimationFrame(frame);
	return {
		getHud: hud,
		setPreview: (next) => {
			const paintChanged = next.paint !== cfg.paint;
			const nightChanged = next.night !== cfg.night;
			cfg = {
				...next,
				vehicle: "tuktuk"
			};
			sfx.on = cfg.sound;
			save.sound = cfg.sound;
			writeSave(save);
			if (paintChanged && phase === "menu") swapPlayer("tuktuk", cfg.paint);
			if (nightChanged) applyDusk(duskNow());
			if (phase === "menu") publish();
		},
		start,
		pause: () => {
			if (phase === "play") {
				phase = "pause";
				publish();
			}
		},
		resume: () => {
			if (phase === "pause") {
				phase = "play";
				publish();
			}
		},
		quit: () => {
			persist();
			phase = "menu";
			probeKeys = null;
			bootCinematic();
			spawnTraffic(track.stops[0].s);
			publish();
		},
		finish: () => {
			if (phase !== "play") return;
			phase = "summary";
			settle();
			publish();
		},
		buy: (id) => {
			const def = UPGRADES.find((u) => u.id === id);
			if (!def) return;
			const lvl = save.upgrades[id];
			if (lvl >= def.max) return;
			const cost = def.costs[lvl];
			if (save.wallet < cost) return;
			save.wallet -= cost;
			save.upgrades[id] = lvl + 1;
			writeSave(save);
			sfx.unlock();
			sfx.cash();
			publish();
		},
		setTouch: (t) => {
			touch.steer = t.steer;
			touch.throttle = t.throttle;
			touch.brake = t.brake;
		},
		horn: honk,
		cycleCam,
		toggleSound: () => {
			sfx.on = !sfx.on;
			cfg.sound = sfx.on;
			save.sound = sfx.on;
			writeSave(save);
			if (sfx.on) sfx.unlock();
			publish();
		},
		dispose: () => {
			running = false;
			cancelAnimationFrame(raf);
			ro.disconnect();
			window.removeEventListener("keydown", onDown);
			window.removeEventListener("keyup", onUp);
			window.removeEventListener("blur", onBlur);
			if (window.__controlsTest?.getYaw === (() => player.yaw) || window.__controlsTest) delete window.__controlsTest;
			sfx.stop();
			renderer.dispose();
		}
	};
}
function buildRoad(scene, track) {
	const pts = track.pts;
	const half = ROAD_HALF;
	const positions = [];
	const uvs = [];
	const n = pts.length;
	const edge = (i, lat) => {
		const p = pts[i];
		const rx = Math.cos(p.yaw);
		const rz = -Math.sin(p.yaw);
		return [
			p.x + rx * lat,
			.02,
			p.z + rz * lat
		];
	};
	let distAcc = 0;
	for (let i = 0; i < n; i++) {
		const a = edge(i, -half);
		const b = edge(i, half);
		const c = edge((i + 1) % n, -half);
		const d = edge((i + 1) % n, half);
		positions.push(...a, ...b, ...d, ...a, ...d, ...c);
		const v0 = distAcc / 8;
		const v1 = (distAcc + pts[i].len) / 8;
		uvs.push(0, v0, 1, v0, 1, v1, 0, v0, 1, v1, 0, v1);
		distAcc += pts[i].len;
	}
	const geo = new BufferGeometry();
	geo.setAttribute("position", new Float32BufferAttribute(positions, 3));
	geo.setAttribute("uv", new Float32BufferAttribute(uvs, 2));
	geo.computeVertexNormals();
	const asphalt = asphaltTexture();
	const mat = new MeshStandardMaterial({
		color: "#ffffff",
		map: asphalt ?? void 0,
		roughness: .96,
		metalness: .02
	});
	scene.add(new Mesh(geo, mat));
	const dashes = [];
	const dash = new Object3D();
	for (let i = 0; i < n; i += 6) {
		const p = pts[i];
		const rx = Math.cos(p.yaw);
		const rz = -Math.sin(p.yaw);
		dash.position.set(p.x + rx * 0, .045, p.z + rz * 0);
		dash.rotation.set(0, p.yaw, 0);
		dash.scale.set(1, 1, 1);
		dash.updateMatrix();
		dashes.push(dash.matrix.clone());
	}
	const dashMesh = new InstancedMesh(new BoxGeometry(.12, .015, 1.6), new MeshStandardMaterial({
		color: "#d9d3c6",
		roughness: .7
	}), Math.max(1, dashes.length));
	dashes.forEach((m, i) => dashMesh.setMatrixAt(i, m));
	scene.add(dashMesh);
	const curbs = [];
	const walks = [];
	const curb = new Object3D();
	for (let i = 0; i < n; i += 2) {
		const p = pts[i];
		const rx = Math.cos(p.yaw);
		const rz = -Math.sin(p.yaw);
		for (const side of [-1, 1]) {
			curb.position.set(p.x + rx * side * (half + .35), .12, p.z + rz * side * (half + .35));
			curb.rotation.set(0, p.yaw, 0);
			curb.scale.set(1, 1, 1);
			curb.updateMatrix();
			curbs.push(curb.matrix.clone());
			curb.position.set(p.x + rx * side * (half + 2.15), .06, p.z + rz * side * (half + 2.15));
			curb.updateMatrix();
			walks.push(curb.matrix.clone());
		}
	}
	const curbMesh = new InstancedMesh(new BoxGeometry(.28, .18, 7.2), new MeshStandardMaterial({
		color: "#d7d0c4",
		roughness: .85
	}), curbs.length);
	curbs.forEach((m, i) => curbMesh.setMatrixAt(i, m));
	const walkTex = sidewalkTexture();
	const walkMesh = new InstancedMesh(new BoxGeometry(2.6, .08, 7.2), new MeshStandardMaterial({
		color: "#ffffff",
		map: walkTex ?? void 0,
		roughness: .94
	}), walks.length);
	walks.forEach((m, i) => walkMesh.setMatrixAt(i, m));
	scene.add(curbMesh, walkMesh);
}
function buildCity(scene, track) {
	const kit = buildingKit();
	const mats = kit.facadeMats;
	const meshes = [];
	kit.sets.forEach((set) => {
		const mesh = new InstancedMesh(kit.box, set, 90);
		mesh.count = 0;
		mesh.frustumCulled = false;
		scene.add(mesh);
		meshes.push(mesh);
	});
	const counts = kit.sets.map(() => 0);
	const dummy = new Object3D();
	const tanks = [];
	const tankO = new Object3D();
	const pts = track.pts;
	for (let i = 0; i < pts.length; i += 4) {
		const p = pts[i];
		const nxt = pts[(i + 8) % pts.length];
		const rx = Math.cos(p.yaw);
		const rz = -Math.sin(p.yaw);
		const hsh = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1;
		const bending = Math.abs(wrapAngle(nxt.yaw - p.yaw)) > .28;
		const nearS = (s, pad) => {
			let d = Math.abs(p.s - s);
			if (d > track.total * .5) d = track.total - d;
			return d < pad;
		};
		if (track.stops.some((stop) => nearS(stop.s, 18)) || nearS(track.gasS, 12)) continue;
		const outward = Math.sign(p.x * rx + p.z * rz) || 1;
		const sides = bending ? [outward] : [-1, 1];
		for (const side of sides) {
			const height = (5 + Math.floor(hsh * 4)) * 2.9;
			const width = 6.2 + hsh * 1.4;
			const along = 8.2 + (1 - hsh) * 3.2;
			const lateral = 13.2 + (hsh - .5) * .6;
			const idx = (i + (side > 0 ? 1 : 0)) % meshes.length;
			if (counts[idx] >= 90) continue;
			dummy.position.set(p.x + rx * side * lateral, height / 2, p.z + rz * side * lateral);
			dummy.rotation.set(0, p.yaw, 0);
			dummy.scale.set(width, height, along);
			dummy.updateMatrix();
			meshes[idx].setMatrixAt(counts[idx]++, dummy.matrix);
			if (hsh > .35) {
				tankO.position.set(p.x + rx * side * lateral, height + .75, p.z + rz * side * lateral);
				tankO.rotation.set(0, hsh, 0);
				tankO.scale.set(1, 1, 1);
				tankO.updateMatrix();
				tanks.push(tankO.matrix.clone());
			}
		}
	}
	meshes.forEach((m, i) => {
		m.count = counts[i];
		m.instanceMatrix.needsUpdate = true;
	});
	if (tanks.length) {
		const tankMesh = new InstancedMesh(new CylinderGeometry(.85, .85, 1.35, 8), new MeshStandardMaterial({
			color: "#b7bcc2",
			roughness: .45,
			metalness: .35
		}), tanks.length);
		tankMesh.frustumCulled = false;
		tanks.forEach((m, i) => tankMesh.setMatrixAt(i, m));
		scene.add(tankMesh);
	}
	return mats;
}
function buildLamps(scene, track) {
	const mats = [];
	const heads = [];
	const o = new Object3D();
	const pts = track.pts;
	for (let i = 0; i < pts.length; i += 8) {
		const p = pts[i];
		const rx = Math.cos(p.yaw);
		const rz = -Math.sin(p.yaw);
		o.position.set(p.x + rx * 11.4, 3.1, p.z + rz * 11.4);
		o.rotation.set(0, 0, 0);
		o.scale.set(1, 1, 1);
		o.updateMatrix();
		mats.push(o.matrix.clone());
		o.position.y = 6.3;
		o.updateMatrix();
		heads.push(o.matrix.clone());
	}
	const pole = new InstancedMesh(new CylinderGeometry(.12, .16, 6.2, 6), new MeshStandardMaterial({
		color: "#2c3138",
		roughness: .6
	}), mats.length);
	mats.forEach((m, i) => pole.setMatrixAt(i, m));
	scene.add(pole);
	const bulbMat = new MeshStandardMaterial({
		color: "#fff1cc",
		emissive: "#ffd78a",
		emissiveIntensity: .05
	});
	const bulbs = new InstancedMesh(new SphereGeometry(.28, 8, 8), bulbMat, heads.length);
	heads.forEach((m, i) => bulbs.setMatrixAt(i, m));
	scene.add(bulbs);
	return bulbMat;
}
//#endregion
export { mountGame };
