import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import {
  GAS_COST,
  JOBS_NEED,
  RENT,
  SHIFT_SECONDS,
  UPGRADES,
  type Hud,
  type Pax,
  type Phase,
  type PreviewCfg,
  type UpgradeId,
  type Upgrades,
  type VehicleId,
  vehicleById,
} from "./types";
import { ROAD_HALF, buildTrack, laneLat, wrapAngle, wrapDelta, type Track } from "./track";
import {
  asphaltTexture,
  buildLandmarks,
  buildPosts,
  buildingKit,
  dressFayoum,
  placePeople,
  placeShopSigns,
  sidewalkTexture,
} from "./fayoum";
import { OCCUPATIONS, dressStreet, placeLocalSigns } from "./street";

export type GameHandle = {
  getHud: () => Hud;
  setPreview: (cfg: PreviewCfg) => void;
  start: (cfg: PreviewCfg) => void;
  pause: () => void;
  resume: () => void;
  quit: () => void;
  finish: () => void;
  setTouch: (t: { steer: number; throttle: number; brake: number }) => void;
  horn: () => void;
  cycleCam: () => void;
  toggleSound: () => void;
  buy: (id: UpgradeId) => void;
  dispose: () => void;
};

type Npc = {
  alive: boolean;
  kind: VehicleId;
  s: number;
  lane: number;
  laneTarget: number;
  speed: number;
  cruise: number;
  brake: number;
  color: THREE.Color;
  nextLane: number;
};

type Wrong = { s: number; speed: number; lat: number };

const SAVE_KEY = "daralsalam-save-v2";
const RADAR_LIMIT = 46 / 3.6;
const TOLL_LIMIT = 36 / 3.6;

type Save = {
  v: 2;
  bestMoney: number;
  bestKm: number;
  bestTrial: number | null;
  sound: boolean;
  wallet: number;
  upgrades: Upgrades;
};

function blankUpgrades(): Upgrades {
  return { motor: 0, fuel: 0, seats: 0, tires: 0 };
}

function clampLvl(n: unknown) {
  const v = Math.floor(Number(n) || 0);
  return Math.max(0, Math.min(3, v));
}

function loadSave(): Save {
  const blank: Save = {
    v: 2,
    bestMoney: 0,
    bestKm: 0,
    bestTrial: null,
    sound: true,
    wallet: 0,
    upgrades: blankUpgrades(),
  };
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return blank;
    const p = JSON.parse(raw) as Partial<Save>;
    if (p.v !== 2) return blank;
    const u = (p.upgrades ?? {}) as Partial<Upgrades>;
    return {
      v: 2,
      bestMoney: Number(p.bestMoney) || 0,
      bestKm: Number(p.bestKm) || 0,
      bestTrial: typeof p.bestTrial === "number" ? p.bestTrial : null,
      sound: p.sound !== false,
      wallet: Math.max(0, Math.floor(Number(p.wallet) || 0)),
      upgrades: {
        motor: clampLvl(u.motor),
        fuel: clampLvl(u.fuel),
        seats: clampLvl(u.seats),
        tires: clampLvl(u.tires),
      },
    };
  } catch {
    return blank;
  }
}

function writeSave(s: Save) {
  try {
    localStorage.setItem(SAVE_KEY, JSON.stringify(s));
  } catch {
    /* ignore quota */
  }
}

function box(w: number, h: number, d: number, x: number, y: number, z: number) {
  const g = new THREE.BoxGeometry(w, h, d);
  g.translate(x, y, z);
  return g;
}

function merge(parts: THREE.BufferGeometry[]) {
  return mergeGeometries(parts, false) ?? parts[0];
}

const KINDS: VehicleId[] = ["malaky", "taxi", "micro", "tuktuk", "truck"];

function trafficGeoms(kind: VehicleId) {
  const body: THREE.BufferGeometry[] = [];
  const glass: THREE.BufferGeometry[] = [];
  const wheels: THREE.BufferGeometry[] = [];
  const lights: THREE.BufferGeometry[] = [];
  const wheel = () => {
    const g = new THREE.CylinderGeometry(0.34, 0.34, 0.22, 8);
    g.rotateZ(Math.PI / 2);
    return g;
  };
  const addW = (x: number, y: number, z: number, s = 1) => {
    const g = wheel();
    g.scale(s, s, s);
    g.translate(x, y, z);
    wheels.push(g);
  };

  if (kind === "micro") {
    body.push(box(2.05, 1.45, 4.9, 0, 1.2, 0.05));
    glass.push(box(1.85, 0.55, 1.3, 0, 1.85, -1.05));
    glass.push(box(1.7, 0.42, 2.2, 0, 1.78, 0.85));
    lights.push(box(0.2, 0.22, 0.08, -0.75, 0.95, 2.5));
    lights.push(box(0.2, 0.22, 0.08, 0.75, 0.95, 2.5));
    addW(-1.05, 0.36, -1.6, 1.05);
    addW(1.05, 0.36, -1.6, 1.05);
    addW(-1.05, 0.36, 1.5, 1.05);
    addW(1.05, 0.36, 1.5, 1.05);
  } else if (kind === "tuktuk") {
    // better matching shape for traffic tuk-tuks
    body.push(box(1.32, 0.55, 1.35, 0, 0.72, 0.28));
    body.push(box(1.42, 0.06, 1.58, 0, 1.48, 0.15));
    body.push(box(1.02, 0.22, 0.85, 0, 0.42, -0.95));
    glass.push(box(1.15, 0.48, 0.05, 0, 1.12, -0.42));
    glass.push(box(0.04, 0.4, 0.9, -0.66, 1.12, 0.1));
    glass.push(box(0.04, 0.4, 0.9, 0.66, 1.12, 0.1));
    lights.push(box(0.16, 0.16, 0.08, -0.28, 0.55, -1.28));
    lights.push(box(0.16, 0.16, 0.08, 0.28, 0.55, -1.28));
    addW(-0.62, 0.26, 0.52, 0.85);
    addW(0.62, 0.26, 0.52, 0.85);
    addW(0, 0.26, -1.05, 0.8);
  } else if (kind === "truck") {
    body.push(box(2.35, 1.55, 7.2, 0, 1.25, 1.35));
    body.push(box(2.2, 1.7, 2.3, 0, 1.45, -3.15));
    glass.push(box(1.9, 0.55, 0.9, 0, 1.9, -3.55));
    lights.push(box(0.22, 0.18, 0.08, -0.8, 0.85, 4.95));
    lights.push(box(0.22, 0.18, 0.08, 0.8, 0.85, 4.95));
    addW(-1.15, 0.42, -3.3, 1.2);
    addW(1.15, 0.42, -3.3, 1.2);
    addW(-1.15, 0.42, 1.2, 1.2);
    addW(1.15, 0.42, 1.2, 1.2);
    addW(-1.15, 0.42, 3.5, 1.2);
    addW(1.15, 0.42, 3.5, 1.2);
  } else {
    body.push(box(1.72, 0.48, 4.25, 0, 0.62, 0));
    body.push(box(1.55, 0.42, 2.05, 0, 1.05, 0.28));
    if (kind === "taxi") body.push(box(0.34, 0.16, 0.34, 0, 1.38, 0.15));
    glass.push(box(1.4, 0.36, 1.15, 0, 1.08, -0.15));
    lights.push(box(0.22, 0.14, 0.06, -0.62, 0.72, 2.12));
    lights.push(box(0.22, 0.14, 0.06, 0.62, 0.72, 2.12));
    addW(-0.78, 0.32, -1.35);
    addW(0.78, 0.32, -1.35);
    addW(-0.78, 0.32, 1.28);
    addW(0.78, 0.32, 1.28);
  }
  return {
    body: merge(body),
    glass: merge(glass),
    wheels: merge(wheels),
    lights: merge(lights),
  };
}

function buildPlayer(kind: VehicleId, hex: string) {
  const g = new THREE.Group();
  g.rotation.order = "YXZ";
  const paint = new THREE.MeshStandardMaterial({ color: hex, roughness: 0.46, metalness: 0.12 });
  const glass = new THREE.MeshStandardMaterial({
    color: "#b7dbe3",
    roughness: 0.08,
    metalness: 0.35,
    transparent: true,
    opacity: 0.78,
  });
  const dark = new THREE.MeshStandardMaterial({ color: "#17191d", roughness: 0.62 });
  const tail = new THREE.MeshStandardMaterial({
    color: "#ff3b3b",
    emissive: "#ff2020",
    emissiveIntensity: 0.9,
  });
  const head = new THREE.MeshStandardMaterial({
    color: "#fff6d8",
    emissive: "#ffe7a8",
    emissiveIntensity: 0.35,
  });
  const wheels: THREE.Mesh[] = [];
  const put = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(x, y, z);
    g.add(m);
    return m;
  };
  const addWheels = (x: number, z: number, r: number) => {
    const geo = new THREE.CylinderGeometry(r, r, r * 0.7, 12);
    geo.rotateZ(Math.PI / 2);
    for (const sx of [-1, 1]) {
      const m = new THREE.Mesh(geo, dark);
      m.position.set(sx * x, r, z);
      g.add(m);
      wheels.push(m);
    }
  };

  if (kind === "micro") {
    put(new THREE.BoxGeometry(2.05, 1.15, 4.9), paint, 0, 1.05, 0.05);
    put(new THREE.BoxGeometry(1.9, 0.48, 1.35), glass, 0, 1.78, -0.95);
    put(new THREE.BoxGeometry(1.75, 0.4, 2.1), glass, 0, 1.72, 0.9);
    put(new THREE.BoxGeometry(0.22, 0.26, 0.08), tail, -0.72, 0.95, 2.52);
    put(new THREE.BoxGeometry(0.22, 0.26, 0.08), tail, 0.72, 0.95, 2.52);
    put(new THREE.BoxGeometry(0.42, 0.22, 0.08), head, -0.65, 0.95, -2.42);
    put(new THREE.BoxGeometry(0.42, 0.22, 0.08), head, 0.65, 0.95, -2.42);
    addWheels(1.02, -1.55, 0.38);
    addWheels(1.02, 1.5, 0.38);
  } else if (kind === "tuktuk") {
    // Realistic Egyptian Bajaj-style tuk-tuk (open cabin, canopy, chrome details)
    const black = dark;
    const chrome = new THREE.MeshStandardMaterial({ color: "#b8c0c8", roughness: 0.22, metalness: 0.88 });
    const canopyMat = new THREE.MeshStandardMaterial({ color: hex, roughness: 0.55, metalness: 0.06 });
    const seatMat = new THREE.MeshStandardMaterial({ color: "#2a2e35", roughness: 0.78 });
    // front floor / engine cover
    put(new THREE.BoxGeometry(1.02, 0.2, 0.88), black, 0, 0.4, -0.98);
    put(new THREE.BoxGeometry(0.95, 0.12, 0.55), black, 0, 0.78, -1.05);
    // main body / passenger cabin
    put(new THREE.BoxGeometry(1.34, 0.52, 1.38), paint, 0, 0.7, 0.28);
    // side body panels (lower)
    put(new THREE.BoxGeometry(0.07, 0.38, 1.32), black, -0.68, 0.52, 0.25);
    put(new THREE.BoxGeometry(0.07, 0.38, 1.32), black, 0.68, 0.52, 0.25);
    // rear passenger bench + backrest
    put(new THREE.BoxGeometry(1.24, 0.16, 0.48), seatMat, 0, 0.82, 0.78);
    put(new THREE.BoxGeometry(1.2, 0.36, 0.1), seatMat, 0, 1.02, 0.95);
    // roof canopy (layered for thickness)
    put(new THREE.BoxGeometry(1.44, 0.055, 1.62), canopyMat, 0, 1.46, 0.15);
    put(new THREE.BoxGeometry(1.5, 0.035, 1.68), black, 0, 1.52, 0.15);
    // canopy support posts
    put(new THREE.BoxGeometry(0.05, 0.55, 0.05), black, -0.66, 1.18, -0.55);
    put(new THREE.BoxGeometry(0.05, 0.55, 0.05), black, 0.66, 1.18, -0.55);
    put(new THREE.BoxGeometry(0.05, 0.55, 0.05), black, -0.66, 1.18, 0.85);
    put(new THREE.BoxGeometry(0.05, 0.55, 0.05), black, 0.66, 1.18, 0.85);
    // front windshield + frame
    put(new THREE.BoxGeometry(1.18, 0.5, 0.04), glass, 0, 1.12, -0.45);
    put(new THREE.BoxGeometry(0.06, 0.52, 0.06), black, -0.59, 1.12, -0.45);
    put(new THREE.BoxGeometry(0.06, 0.52, 0.06), black, 0.59, 1.12, -0.45);
    put(new THREE.BoxGeometry(1.22, 0.05, 0.05), black, 0, 1.38, -0.45);
    // open side frames (characteristic of Egyptian tuk-tuks)
    put(new THREE.BoxGeometry(0.04, 0.45, 0.95), black, -0.69, 1.15, 0.12);
    put(new THREE.BoxGeometry(0.04, 0.45, 0.95), black, 0.69, 1.15, 0.12);
    // steering column + handlebar
    put(new THREE.BoxGeometry(0.07, 0.07, 0.58), chrome, 0, 0.92, -0.78);
    put(new THREE.BoxGeometry(0.58, 0.05, 0.05), chrome, 0, 1.02, -1.05);
    // front round headlights
    const lampGeo = new THREE.SphereGeometry(0.095, 12, 10);
    const lampL = new THREE.Mesh(lampGeo, head);
    lampL.position.set(-0.28, 0.55, -1.32);
    const lampR = new THREE.Mesh(lampGeo, head);
    lampR.position.set(0.28, 0.55, -1.32);
    g.add(lampL, lampR);
    // rear lights
    put(new THREE.BoxGeometry(0.15, 0.1, 0.06), tail, -0.48, 0.62, 0.98);
    put(new THREE.BoxGeometry(0.15, 0.1, 0.06), tail, 0.48, 0.62, 0.98);
    // side mirrors
    put(new THREE.BoxGeometry(0.12, 0.07, 0.05), chrome, -0.78, 1.12, -0.38);
    put(new THREE.BoxGeometry(0.12, 0.07, 0.05), chrome, 0.78, 1.12, -0.38);
    // rear dual wheels
    addWheels(0.62, 0.52, 0.26);
    // single front wheel
    const geo = new THREE.CylinderGeometry(0.26, 0.26, 0.14, 14);
    geo.rotateZ(Math.PI / 2);
    const m = new THREE.Mesh(geo, dark);
    m.position.set(0, 0.26, -1.08);
    g.add(m);
    wheels.push(m);
    // exhaust pipe (side)
    put(new THREE.BoxGeometry(0.06, 0.06, 0.45), chrome, -0.55, 0.35, -0.55);
    put(new THREE.BoxGeometry(0.08, 0.08, 0.12), black, -0.55, 0.35, -0.8);
    // rear license plate
    const plate = new THREE.MeshStandardMaterial({ color: "#f5f5f0", roughness: 0.4 });
    put(new THREE.BoxGeometry(0.32, 0.12, 0.02), plate, 0, 0.55, 0.98);
    // small stickers / decals on side
    put(new THREE.BoxGeometry(0.18, 0.12, 0.01), new THREE.MeshStandardMaterial({ color: "#c0392b", roughness: 0.5 }), -0.68, 0.85, 0.1);
    put(new THREE.BoxGeometry(0.14, 0.1, 0.01), new THREE.MeshStandardMaterial({ color: "#1a5276", roughness: 0.5 }), 0.68, 0.85, 0.15);
    // driver figure (seated)
    const skin = new THREE.MeshStandardMaterial({ color: "#c49a78", roughness: 0.62 });
    const shirt = new THREE.MeshStandardMaterial({ color: "#1e3a5f", roughness: 0.75 });
    const driver = new THREE.Mesh(new THREE.CapsuleGeometry(0.115, 0.2, 3, 6), shirt);
    driver.position.set(0.04, 0.92, -0.18);
    const hd = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), skin);
    hd.position.set(0.04, 1.18, -0.22);
    g.add(driver, hd);
  } else if (kind === "truck") {
    put(new THREE.BoxGeometry(2.4, 1.45, 7.1), paint, 0, 1.2, 1.4);
    put(new THREE.BoxGeometry(2.15, 1.55, 2.35), paint, 0, 1.4, -3.1);
    put(new THREE.BoxGeometry(1.85, 0.5, 0.85), glass, 0, 1.9, -3.5);
    put(new THREE.BoxGeometry(0.24, 0.18, 0.08), tail, -0.85, 0.8, 4.95);
    put(new THREE.BoxGeometry(0.24, 0.18, 0.08), tail, 0.85, 0.8, 4.95);
    put(new THREE.BoxGeometry(0.3, 0.18, 0.08), head, -0.7, 0.85, -4.25);
    put(new THREE.BoxGeometry(0.3, 0.18, 0.08), head, 0.7, 0.85, -4.25);
    addWheels(1.15, -3.25, 0.42);
    addWheels(1.15, 1.15, 0.42);
    addWheels(1.15, 3.45, 0.42);
  } else {
    put(new THREE.BoxGeometry(1.72, 0.46, 4.3), paint, 0, 0.62, 0);
    put(new THREE.BoxGeometry(1.52, 0.4, 1.9), paint, 0, 1.02, 0.32);
    put(new THREE.BoxGeometry(1.35, 0.34, 1.05), glass, 0, 1.05, -0.2);
    if (kind === "taxi") {
      const lamp = new THREE.MeshStandardMaterial({
        color: "#f0b429",
        emissive: "#f0b429",
        emissiveIntensity: 0.8,
      });
      put(new THREE.BoxGeometry(0.28, 0.14, 0.28), lamp, 0, 1.32, 0.15);
    }
    put(new THREE.BoxGeometry(0.24, 0.14, 0.06), tail, -0.6, 0.7, 2.16);
    put(new THREE.BoxGeometry(0.24, 0.14, 0.06), tail, 0.6, 0.7, 2.16);
    put(new THREE.BoxGeometry(0.32, 0.14, 0.06), head, -0.55, 0.62, -2.16);
    put(new THREE.BoxGeometry(0.32, 0.14, 0.06), head, 0.55, 0.62, -2.16);
    addWheels(0.78, -1.32, 0.32);
    addWheels(0.78, 1.28, 0.32);
  }

  const spotL = new THREE.SpotLight("#fff1cc", 0, 46, Math.PI / 8, 0.45, 1);
  spotL.position.set(-0.45, 0.9, -1.6);
  const spotR = new THREE.SpotLight("#fff1cc", 0, 46, Math.PI / 8, 0.45, 1);
  spotR.position.set(0.45, 0.9, -1.6);
  const target = new THREE.Object3D();
  target.position.set(0, 0.4, -18);
  g.add(spotL, spotR, target);
  spotL.target = target;
  spotR.target = target;

  const rider = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.2, 0.38, 3, 8),
    new THREE.MeshStandardMaterial({ color: "#1d3557", roughness: 0.7 }),
  );
  rider.position.set(0.02, 1.22, 0.28);
  rider.visible = false;
  g.add(rider);

  return { group: g, wheels, paint, spots: [spotL, spotR], rider };
}

function signTexture(title: string, sub: string) {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 256;
  const g = c.getContext("2d");
  if (!g) return null;
  g.fillStyle = "#163e86";
  g.fillRect(0, 0, 512, 256);
  g.fillStyle = "#f0b429";
  g.fillRect(0, 0, 512, 10);
  g.fillStyle = "#f6f1e7";
  g.direction = "rtl";
  g.textAlign = "center";
  g.font = "800 72px Tajawal, sans-serif";
  g.fillText(title, 256, 120);
  g.font = "500 36px Tajawal, sans-serif";
  g.fillStyle = "#d6e4ff";
  g.fillText(sub, 256, 185);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

class Sfx {
  ctx: AudioContext | null = null;
  gain: GainNode | null = null;
  osc: OscillatorNode | null = null;
  filter: BiquadFilterNode | null = null;
  on = true;

  unlock() {
    if (!this.ctx) {
      const ctx = new AudioContext();
      const gain = ctx.createGain();
      gain.gain.value = 0.0001;
      const filter = ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.value = 240;
      const osc = ctx.createOscillator();
      osc.type = "sawtooth";
      osc.frequency.value = 46;
      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      this.ctx = ctx;
      this.gain = gain;
      this.osc = osc;
      this.filter = filter;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
  }

  engine(speed: number, throttle: number) {
    if (!this.ctx || !this.osc || !this.gain || !this.filter || !this.on) {
      if (this.gain) this.gain.gain.value = 0.0001;
      return;
    }
    const k = Math.abs(speed);
    this.osc.frequency.value = 42 + k * 3.1 + throttle * 18;
    this.filter.frequency.value = 180 + k * 18;
    this.gain.gain.value = 0.018 + Math.min(0.04, k * 0.0015);
  }

  blip(freq: number, dur: number, type: OscillatorType, vol: number) {
    if (!this.ctx || !this.on) return;
    const o = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    o.type = type;
    o.frequency.value = freq;
    g.gain.value = vol;
    o.connect(g);
    g.connect(this.ctx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + dur);
    o.stop(this.ctx.currentTime + dur + 0.02);
  }

  horn() {
    this.blip(340, 0.18, "square", 0.05);
    setTimeout(() => this.blip(280, 0.16, "square", 0.04), 90);
  }

  cash() {
    this.blip(660, 0.08, "sine", 0.05);
    setTimeout(() => this.blip(880, 0.1, "sine", 0.04), 70);
  }

  crash() {
    this.blip(90, 0.22, "sawtooth", 0.07);
  }

  radar() {
    this.blip(980, 0.12, "square", 0.05);
  }

  stop() {
    if (this.gain) this.gain.gain.value = 0.0001;
    void this.ctx?.close();
    this.ctx = null;
  }
}

const defaultCfg: PreviewCfg = {
  mode: "shift",
  vehicle: "tuktuk",
  night: false,
  density: 1,
  paint: "#f0b429",
  sound: true,
};

export function mountGame(
  canvas: HTMLCanvasElement,
  map: HTMLCanvasElement,
  onHud: (h: Hud) => void,
): GameHandle {
  const track = buildTrack();
  const save = loadSave();
  const sfx = new Sfx();
  sfx.on = save.sound;

  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: "high-performance" });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.18;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setClearColor("#cfd9db");
  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog("#d8cbb8", 48, 260);
  const camera = new THREE.PerspectiveCamera(68, 1, 0.12, 900);

  const hemi = new THREE.HemisphereLight("#f7f0e6", "#9a8468", 0.95);
  const sun = new THREE.DirectionalLight("#ffe8c4", 1.85);
  sun.position.set(-110, 140, 55);
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.near = 10;
  sun.shadow.camera.far = 420;
  sun.shadow.camera.left = -180;
  sun.shadow.camera.right = 180;
  sun.shadow.camera.top = 180;
  sun.shadow.camera.bottom = -180;
  sun.shadow.bias = -0.00025;
  scene.add(hemi, sun);

  const ground = new THREE.Mesh(
    new THREE.CircleGeometry(980, 64),
    new THREE.MeshStandardMaterial({ color: "#a89a80", roughness: 0.95, metalness: 0.02 }),
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.08;
  ground.receiveShadow = true;
  scene.add(ground);

  buildRoad(scene, track);
  const buildings = buildCity(scene, track);
  const lamps = buildLamps(scene, track);
  buildPosts(scene, track);
  buildLandmarks(scene, track);
  dressFayoum(scene, track);
  dressStreet(scene, track);
  placePeople(scene, track);
  const signs: THREE.Mesh[] = [];

  const pools = new Map<VehicleId, { body: THREE.InstancedMesh; glass: THREE.InstancedMesh; wheels: THREE.InstancedMesh; lights: THREE.InstancedMesh }>();
  const POOL = 56;
  const glassMat = new THREE.MeshStandardMaterial({ color: "#1c3c48", roughness: 0.18, metalness: 0.2 });
  const wheelMat = new THREE.MeshStandardMaterial({ color: "#16181c", roughness: 0.7 });
  const lightMat = new THREE.MeshStandardMaterial({ color: "#ff3030", emissive: "#ff2020", emissiveIntensity: 0.85 });
  for (const kind of KINDS) {
    const ge = trafficGeoms(kind);
    const bodyMat = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.55, metalness: 0.08 });
    const mk = (geo: THREE.BufferGeometry, mat: THREE.Material) => {
      const m = new THREE.InstancedMesh(geo, mat, POOL);
      m.frustumCulled = false;
      m.count = POOL;
      scene.add(m);
      return m;
    };
    pools.set(kind, {
      body: mk(ge.body, bodyMat),
      glass: mk(ge.glass, glassMat),
      wheels: mk(ge.wheels, wheelMat),
      lights: mk(ge.lights, lightMat),
    });
  }

  const dummy = new THREE.Object3D();
  const tukColor = new THREE.Color("#d4654a");
  const PEOPLE = 64;
  const people = new THREE.InstancedMesh(
    new THREE.CapsuleGeometry(0.22, 0.48, 3, 6),
    new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.78 }),
    PEOPLE,
  );
  people.frustumCulled = false;
  scene.add(people);
  const cloth = ["#1d3557", "#c45c3e", "#e6c27a", "#2f6f4a", "#f6f1e7", "#6b3a5d"].map((hex) => new THREE.Color(hex));
  const hideAll = () => {
    dummy.position.set(0, -20, 0);
    dummy.scale.set(0, 0, 0);
    dummy.updateMatrix();
    for (const p of pools.values()) {
      for (let i = 0; i < POOL; i++) {
        p.body.setMatrixAt(i, dummy.matrix);
        p.glass.setMatrixAt(i, dummy.matrix);
        p.wheels.setMatrixAt(i, dummy.matrix);
        p.lights.setMatrixAt(i, dummy.matrix);
      }
    }
  };
  hideAll();

  let playerMesh = buildPlayer("tuktuk", "#f0b429");
  scene.add(playerMesh.group);

  const sparkGeo = new THREE.BoxGeometry(0.12, 0.12, 0.12);
  const sparkMat = new THREE.MeshBasicMaterial({ color: "#f0b429" });
  const sparks: { m: THREE.Mesh; v: THREE.Vector3; life: number }[] = [];
  for (let i = 0; i < 18; i++) {
    const m = new THREE.Mesh(sparkGeo, sparkMat);
    m.visible = false;
    scene.add(m);
    sparks.push({ m, v: new THREE.Vector3(), life: 0 });
  }

  const keys = new Set<string>();
  let probeKeys: Set<string> | null = null;
  let probeSteer: number | null = null;
  const touch = { steer: 0, throttle: 0, brake: 0 };

  const player = {
    x: 0,
    z: 0,
    yaw: 0,
    speed: 0,
    hint: 0,
    spin: 0,
  };

  let cfg: PreviewCfg = { ...defaultCfg, sound: save.sound };
  let phase: Phase = "menu";
  let money = 0;
  let km = 0;
  let time = 0;
  let crashes = 0;
  let pax: Pax[] = [];
  let waiting = track.stops.map(() => 2 + Math.floor(Math.random() * 4));
  let serviced = -1;
  let message = "";
  let messageT = 0;
  let alert: Hud["alert"] = null;
  let alertT = 0;
  let hitCd = 0;
  let hornCd = 0;
  let radarCd = 0;
  let tollLatch = false;
  let camMode = 1;
  let shake = 0;
  let steerVis = 0;
  let wheelSpin = 0;
  let saveTick = 0;
  const npcs: Npc[] = [];
  const wrongs: Wrong[] = [
    { s: 80, speed: 7.2, lat: 6.4 },
    { s: 260, speed: 6.4, lat: -6.2 },
    { s: 480, speed: 7.6, lat: 6.6 },
    { s: 720, speed: 6.2, lat: -5.8 },
    { s: 940, speed: 7, lat: 6.1 },
  ];
  const crossers = Array.from({ length: 8 }, (_, i) => ({
    s: (track.total * (i + 0.37)) / 8,
    lat: (i % 2 ? 1 : -1) * (ROAD_HALF + 0.35),
    dir: i % 2 ? -1 : 1,
    wait: i * 0.4,
  }));
  let fuel = 100;
  let gasLatch = false;
  let fuelWarned = false;
  let halfWarned = false;
  let bumpCd = 0;
  let fuelBeep = 0;
  let hitstop = 0;
  let jobs: number[] = [];
  let jobIndex = 0;
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const camPos = new THREE.Vector3(0, 8, 20);
  const look = new THREE.Vector3();
  const desired = new THREE.Vector3();
  let last = performance.now();
  let acc = 0;
  let hudAcc = 0;
  let raf = 0;
  let running = true;

  const placeOn = (s: number, lane: number) => {
    const sm = track.sample(s);
    const rx = Math.cos(sm.yaw);
    const rz = -Math.sin(sm.yaw);
    const lat = laneLat(lane);
    player.x = sm.x + rx * lat;
    player.z = sm.z + rz * lat;
    player.yaw = sm.yaw;
    player.hint = 0;
    player.speed = 0;
  };

  const bootCinematic = () => {
    placeOn(track.stops[0].s, 1);
    player.speed = 16;
  };
  bootCinematic();

  function densityCount() {
    return cfg.density === 0 ? 16 : cfg.density === 2 ? 40 : 28;
  }

  function spawnTraffic(around: number) {
    npcs.length = 0;
    const n = densityCount();
    const weights: VehicleId[] = [
      "tuktuk",
      "tuktuk",
      "tuktuk",
      "micro",
      "micro",
      "taxi",
      "malaky",
      "tuktuk",
      "truck",
    ];
    for (let i = 0; i < n; i++) {
      const kind = weights[i % weights.length];
      const spec = vehicleById(kind);
      const col = new THREE.Color(
        ["#f4f1ea", "#cfd3d8", "#24527e", "#c45c3e", "#e6c27a", "#3d6b62", "#8d939c"][i % 7],
      );
      if (kind === "taxi") col.set("#f0d56a");
      if (kind === "tuktuk") col.set(["#f0b429", "#17191d", "#e23b2b", "#f4f1ea"][i % 4]);
      if (kind === "micro") col.set(["#f4f4f1", "#e4e2da", "#d5dde3"][i % 3]);
      npcs.push({
        alive: true,
        kind,
        s: around + 18 + (i * 260) / n + (i % 5) * 6,
        lane: i % 4,
        laneTarget: i % 4,
        speed: spec.max * (0.45 + (i % 5) * 0.08),
        cruise: spec.max * (0.42 + (i % 4) * 0.1),
        brake: 0,
        color: col,
        nextLane: 4 + (i % 6),
      });
    }
    for (const pool of pools.values()) {
      if (pool.body.instanceColor) pool.body.instanceColor.needsUpdate = true;
    }
  }
  spawnTraffic(track.stops[0].s);

  function burst(x: number, z: number) {
    for (const s of sparks) {
      if (s.life > 0) continue;
      s.life = 0.45;
      s.m.visible = true;
      s.m.position.set(x, 0.6, z);
      s.v.set((Math.random() - 0.5) * 8, 2 + Math.random() * 4, (Math.random() - 0.5) * 8);
    }
  }

  function say(text: string) {
    message = text;
    messageT = 2.4;
  }

  function flash(kind: Hud["alert"]) {
    alert = kind;
    alertT = 0.45;
  }

  function swapPlayer(kind: VehicleId, hex: string) {
    scene.remove(playerMesh.group);
    playerMesh.group.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
    });
    playerMesh = buildPlayer(kind, hex);
    scene.add(playerMesh.group);
    applyDusk(duskNow());
  }

  const skyDay = new THREE.Color("#cfd8da");
  const skyNight = new THREE.Color("#060a12");
  const sky = new THREE.Color();
  const fogDay = new THREE.Color("#d4c7b0"); // dusty Cairo haze
  const fogNight = new THREE.Color("#060a12");
  const fogC = new THREE.Color();
  const hemiDay = new THREE.Color("#f5efe4");
  const hemiNight = new THREE.Color("#2a3a50");
  const groundDay = new THREE.Color("#a89270");
  const groundNight = new THREE.Color("#15100c");

  function applyDusk(t: number) {
    const n = Math.max(0, Math.min(1, t));
    sky.copy(skyDay).lerp(skyNight, n);
    fogC.copy(fogDay).lerp(fogNight, n);
    renderer.setClearColor(sky);
    const fog = scene.fog as THREE.Fog;
    fog.color.copy(fogC);
    fog.near = 42 - n * 12;
    fog.far = 240 - n * 80;
    hemi.color.copy(hemiDay).lerp(hemiNight, n);
    hemi.groundColor.copy(groundDay).lerp(groundNight, n);
    hemi.intensity = 0.92 - n * 0.72;
    sun.intensity = 1.75 - n * 1.55;
    for (const mat of buildings) mat.emissiveIntensity = n * 1.05;
    lamps.emissiveIntensity = 0.06 + n * 1.5;
    const spot = 0.15 + n * 8.5;
    for (const spotL of playerMesh.spots) spotL.intensity = spot;
  }

  function duskNow() {
    if (phase !== "play" && phase !== "pause" && phase !== "summary") return cfg.night ? 0.92 : 0.02;
    if (cfg.night) return Math.min(1, 0.78 + time / 500);
    if (cfg.mode === "shift") return Math.min(1, time / (SHIFT_SECONDS * 0.92));
    return 0.22;
  }
  applyDusk(cfg.night ? 0.92 : 0.18);

  function drawSigns() {
    for (const s of signs) {
      scene.remove(s);
      s.geometry.dispose();
      (s.material as THREE.Material).dispose();
    }
    signs.length = 0;
    for (const stop of track.stops) {
      const tex = signTexture(stop.name, "شارع الفيوم");
      if (!tex) continue;
      const mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.6 });
      const sm = track.sample(stop.s - 70);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(7.2, 3.6), mat);
      mesh.position.set(sm.x + rx * 11.2, 3.3, sm.z + rz * 11.2);
      mesh.rotation.y = sm.yaw;
      scene.add(mesh);
      signs.push(mesh);
    }
    const gasTex = signTexture("بنزينة", "اهدى يمين");
    if (gasTex) {
      const mat = new THREE.MeshStandardMaterial({ map: gasTex, roughness: 0.55 });
      const sm = track.sample(track.gasS - 36);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(6.4, 3.2), mat);
      mesh.position.set(sm.x + rx * 10.4, 3.1, sm.z + rz * 10.4);
      mesh.rotation.y = sm.yaw;
      scene.add(mesh);
      signs.push(mesh);
    }
  }
  void document.fonts?.ready.then(() => {
    drawSigns();
    placeShopSigns(scene, track);
    placeLocalSigns(scene, track);
  });

  function persist() {
    if (money > save.bestMoney) save.bestMoney = money;
    if (km > save.bestKm) save.bestKm = km;
    save.sound = sfx.on;
    writeSave(save);
  }

  function specNow() {
    const base = vehicleById("tuktuk");
    const u = save.upgrades;
    return {
      ...base,
      max: base.max + u.motor * 1.65,
      accel: base.accel + u.motor * 1.1,
      turn: base.turn + u.tires * 0.18,
      fare: base.fare * (1 + u.seats * 0.22),
      name: "توكتوك",
    };
  }

  function pay(cost: number) {
    if (money >= cost) {
      money -= cost;
      return true;
    }
    if (money + save.wallet >= cost) {
      save.wallet -= cost - money;
      money = 0;
      return true;
    }
    return false;
  }

  function rollJobs(fromStop: number) {
    jobs = [];
    let i = fromStop;
    for (let k = 0; k < JOBS_NEED; k++) {
      const hop = 2 + Math.floor(Math.random() * 3);
      i = (i + hop) % track.stops.length;
      jobs.push(i);
    }
    jobIndex = 0;
  }

  function resetRun(startS: number) {
    money = 0;
    km = 0;
    time = 0;
    crashes = 0;
    fuel = 100;
    gasLatch = false;
    fuelWarned = false;
    halfWarned = false;
    bumpCd = 0;
    pax = [];
    waiting = track.stops.map(() => 1 + Math.floor(Math.random() * 4));
    serviced = -1;
    hitCd = 0;
    radarCd = 0;
    tollLatch = false;
    message = "";
    alert = null;
    placeOn(startS, 2);
    spawnTraffic(startS);
    const here = track.stops.reduce((best, stop, i) => {
      const d = Math.abs(stop.s - startS);
      return d < best.d ? { d, i } : best;
    }, { d: Infinity, i: 0 }).i;
    rollJobs(here);
    if (cfg.mode === "shift") say("سدّد الإيجار قبل ما الشمس تغيب — شارع الفيوم");
    else if (cfg.mode === "rush") say(`أول توصيلة: ${track.stops[jobs[0]].name}`);
    else say("لف في شارع الفيوم براحتك، خلي بالك من البنزين والمطبات");
  }

  function settle() {
    if (money > save.bestMoney) save.bestMoney = money;
    if (km > save.bestKm) save.bestKm = km;
    if (cfg.mode === "shift") {
      if (money >= RENT) {
        save.wallet += money - RENT;
        say("الإيجار اتسدد");
        sfx.cash();
      } else if (save.wallet >= RENT - money) {
        save.wallet -= RENT - money;
        say("كمّلت الإيجار من المحفظة");
      } else {
        say(`فاضل ${RENT - money - save.wallet} ج على الإيجار`);
      }
    } else if (cfg.mode === "rush") {
      save.wallet += money;
      if (jobIndex >= JOBS_NEED) {
        if (save.bestTrial == null || time < save.bestTrial) {
          save.bestTrial = time;
          say("رقم جديد في التوصيلات");
        } else say("خلّصت الأربع توصيلات");
        sfx.cash();
      } else say("وقفت التوصيلات");
    } else {
      save.wallet += Math.max(0, money);
      say("خلّصت اللفة");
    }
    persist();
  }

  function start(next: PreviewCfg) {
    cfg = { ...next, vehicle: "tuktuk" };
    sfx.on = cfg.sound;
    swapPlayer("tuktuk", cfg.paint);
    phase = "play";
    const startS = track.stops[0].s + 18;
    resetRun(startS);
    sfx.unlock();
    publish();
  }

  function forwardDist(targetS: number, fromS: number) {
    let d = targetS - fromS;
    while (d < 0) d += track.total;
    while (d >= track.total) d -= track.total;
    return d;
  }

  function hud(): Hud {
    const spec = specNow();
    const proj = track.project(player.x, player.z, player.hint);
    let bestI = 0;
    let bestD = Infinity;
    for (let i = 0; i < track.stops.length; i++) {
      const d = forwardDist(track.stops[i].s, proj.s);
      if (d < bestD) {
        bestD = d;
        bestI = i;
      }
    }
    let targetI = bestI;
    let targetD = bestD;
    if (cfg.mode === "rush" && jobs[jobIndex] != null) {
      targetI = jobs[jobIndex];
      targetD = forwardDist(track.stops[targetI].s, proj.s);
    }
    const stop = track.stops[targetI];
    let hint = "";
    if (phase === "play") {
      const gasD = Math.abs(wrapDelta(track.gasS, proj.s, track.total));
      const speeding = Math.abs(player.speed) > RADAR_LIMIT;
      const nearRadar = track.radarS.some((rs) => Math.abs(wrapDelta(rs, proj.s, track.total)) < 42);
      const crossing = crossers.some(
        (c) =>
          c.wait <= 0 &&
          Math.abs(c.lat) < ROAD_HALF &&
          Math.abs(wrapDelta(c.s, proj.s, track.total)) < 18 &&
          Math.abs(c.lat - proj.lat) < 4,
      );
      const bridgeD = Math.abs(wrapDelta(track.stops[0].s, proj.s, track.total));
      if (crossing) hint = "حد بيعدّي قدامك";
      else if (fuel < 22 && gasD < 90) hint = "البنزينة على اليمين";
      else if (speeding && nearRadar) hint = "هدّي، فيه رادار قدام";
      else if (cfg.mode === "rush") {
        if (targetD < 80 && proj.lat < 3.2) hint = "اهدى يمين عند المحطة";
        else if (targetD < 35) hint = "المحطة قدامك — هدّي";
      } else {
        const relevant = waiting[targetI] > 0 || pax.some((person) => person.dest === targetI);
        if (relevant && targetD < 90 && proj.lat < 3.2) hint = "خش يمين وهدّي";
        else if (relevant && targetD < 40 && player.speed > 4.5) hint = "هدّي عند المحطة";
        else if (Math.abs(player.speed) > 12 && proj.lat > 2.8) hint = "الرصيف مليان إشغالات";
      }
      if (!hint && bridgeD < 55) hint = "زحمة تحت الكوبري";
    }
    return {
      phase,
      speed: Math.round(Math.abs(player.speed) * 3.6),
      money: Math.round(money),
      km: Math.round(km * 10) / 10,
      time,
      crashes,
      passengers: pax.map((person) => ({ dest: track.stops[person.dest].name })),
      seats: spec.seats,
      stopName: stop?.name ?? "",
      stopDist: Math.max(0, Math.round(targetD)),
      hint,
      mode: cfg.mode,
      vehicleName: spec.name,
      message: messageT > 0 ? message : "",
      alert: alertT > 0 ? alert : null,
      fuel: Math.max(0, Math.min(100, fuel)),
      rent: RENT,
      shiftLeft: Math.max(0, SHIFT_SECONDS - time),
      wallet: save.wallet,
      upgrades: save.upgrades,
      lowFuel: fuel <= 18,
      jobsDone: jobIndex,
      jobsNeed: JOBS_NEED,
      jobName: jobs[jobIndex] != null ? track.stops[jobs[jobIndex]].name : "خلّصت",
      bestMoney: Math.round(save.bestMoney),
      bestKm: Math.round(save.bestKm * 10) / 10,
      bestTrial: save.bestTrial,
      night: cfg.night,
      sound: sfx.on,
      progress: proj.s / track.total,
    };
  }

  function publish() {
    onHud(hud());
  }

  function step(dt: number) {
    const spec = specNow();
    const down = (code: string) => (probeKeys ? probeKeys.has(code) : keys.has(code));

    let steer = 0;
    let throttle = 0;
    let brake = 0;
    if (phase === "play") {
      if (probeSteer != null) steer = probeSteer;
      else {
        if (down("KeyA") || down("ArrowLeft")) steer += 1;
        if (down("KeyD") || down("ArrowRight")) steer -= 1;
        steer += touch.steer;
      }
      if (down("KeyW") || down("ArrowUp")) throttle = 1;
      if (down("KeyS") || down("ArrowDown")) brake = 1;
      throttle = Math.max(throttle, touch.throttle);
      brake = Math.max(brake, touch.brake);
      steer = Math.max(-1, Math.min(1, steer));
    } else if (phase === "menu") {
      throttle = 0.62;
      const proj0 = track.project(player.x, player.z, player.hint);
      const want = laneLat(1);
      const err = want - proj0.lat;
      const dy = wrapAngle(proj0.yaw - player.yaw);
      steer = Math.max(-1, Math.min(1, err * 0.18 + dy * 1.4));
    }

    steerVis = steer;

    if (phase === "play" || phase === "menu") {
      if (throttle > 0 && brake === 0) player.speed += spec.accel * throttle * dt;
      else if (brake > 0) {
        if (player.speed > 0.5) player.speed -= spec.brake * dt;
        else player.speed -= spec.accel * 0.45 * dt;
      } else {
        const sign = Math.sign(player.speed);
        const mag = Math.max(0, Math.abs(player.speed) - 3.2 * dt);
        player.speed = sign * mag;
      }
      const cap = phase === "play" && fuel <= 0 ? 3.3 : spec.max;
      player.speed = Math.max(-6, Math.min(cap, player.speed));

      const sp = Math.min(1, Math.abs(player.speed) / 7);
      const reverse = player.speed < -0.5 ? -1 : 1;
      const turnMul = 0.35 + 0.65 * sp;
      player.yaw += steer * spec.turn * turnMul * reverse * dt;

      const fx = -Math.sin(player.yaw);
      const fz = -Math.cos(player.yaw);
      player.x += fx * player.speed * dt;
      player.z += fz * player.speed * dt;

      const proj = track.project(player.x, player.z, player.hint);
      player.hint = proj.i;
      const limit = ROAD_HALF - spec.width * 0.5;
      if (Math.abs(proj.lat) > limit) {
        const clamped = Math.sign(proj.lat) * limit;
        const rx = Math.cos(proj.yaw);
        const rz = -Math.sin(proj.yaw);
        player.x = proj.x + rx * clamped;
        player.z = proj.z + rz * clamped;
        const impact = Math.abs(proj.lat) - limit;
        if (impact > 0.08) {
          player.speed *= 0.9;
          shake = Math.max(shake, 0.12);
        }
      }

      const along = (() => {
        const tx = -Math.sin(proj.yaw);
        const tz = -Math.cos(proj.yaw);
        return (fx * tx + fz * tz) * player.speed;
      })();

      if (phase === "play") {
        if (along > 0) km += (along * dt) / 1000;
        time += dt;
        const eff = 1 - save.upgrades.fuel * 0.18;
        const moving = Math.abs(player.speed) > 0.35 ? 1 : 0.15;
        fuel -= (0.38 * moving + throttle * 0.72) * eff * dt;
        if (fuel < 0) fuel = 0;
        const bridgeD = Math.abs(wrapDelta(track.stops[0].s, proj.s, track.total));
        if (bridgeD < 78 && player.speed > 9) {
          player.speed += (9 - player.speed) * Math.min(1, dt * 2.4);
        }
        if (hitCd <= 0) {
          for (const occ of OCCUPATIONS) {
            if (Math.abs(wrapDelta(occ.s, proj.s, track.total)) < 2.1 && Math.abs(proj.lat - occ.lat) < 1.2) {
              player.speed *= 0.42;
              shake = Math.max(shake, 0.22);
              hitCd = 0.75;
              if (messageT <= 0) say("إشغال في الحارة — خد جنبك");
              sfx.blip(90, 0.05, "square", 0.03);
              break;
            }
          }
        }
        fuelBeep = Math.max(0, fuelBeep - dt);
        if (fuel < 12 && fuelBeep <= 0) {
          fuelBeep = 3.2;
          sfx.blip(540, 0.05, "square", 0.028);
        }
      }
    }

    hitCd = Math.max(0, hitCd - dt);
    hornCd = Math.max(0, hornCd - dt);
    radarCd = Math.max(0, radarCd - dt);
    bumpCd = Math.max(0, bumpCd - dt);
    messageT = Math.max(0, messageT - dt);
    alertT = Math.max(0, alertT - dt);
    shake = Math.max(0, shake - dt);

    updateNpcs(dt, spec.length);
    updateCrossers(dt);
    if (phase === "play") gameplay(dt);

    sfx.engine(player.speed, throttle);
    saveTick += dt;
    if (saveTick > 1.2) {
      saveTick = 0;
      if (money > save.bestMoney) save.bestMoney = money;
      if (km > save.bestKm) save.bestKm = km;
      writeSave(save);
    }
  }

  function updateNpcs(dt: number, _len: number) {
    const proj = track.project(player.x, player.z, player.hint);
    for (const n of npcs) {
      if (!n.alive) continue;
      const spec = vehicleById(n.kind);
      let target = n.cruise;
      const nearBridge = Math.abs(wrapDelta(n.s, track.stops[0].s, track.total)) < 95;
      if (nearBridge) target = Math.min(target, 4.2);
      const ahead = wrapDelta(n.s, proj.s, track.total);
      if (n.kind === "micro") {
        for (const stop of track.stops) {
          const d = wrapDelta(stop.s, n.s, track.total);
          if (d > 0 && d < 36 && n.lane > 1.5) target = Math.min(target, 3.5);
        }
        n.brake -= dt;
        if (n.brake <= 0 && Math.random() < dt * 0.15) n.brake = 1.3;
        if (n.brake > 0) target = Math.min(target, 2.2);
      }
      for (const o of npcs) {
        if (o === n || !o.alive) continue;
        if (Math.abs(o.lane - n.lane) > 0.75) continue;
        const gap = wrapDelta(o.s, n.s, track.total);
        if (gap > 0 && gap < 14) target = Math.min(target, o.speed * 0.92);
      }
      n.speed += (target - n.speed) * Math.min(1, dt * 1.4);
      n.speed = Math.max(2, n.speed);
      n.s += n.speed * dt;
      n.nextLane -= dt;
      if (n.nextLane <= 0) {
        n.nextLane = 3 + Math.random() * 5;
        const dir = Math.random() < 0.5 ? -1 : 1;
        n.laneTarget = Math.max(0, Math.min(3, Math.round(n.lane + dir)));
        if (n.kind === "tuktuk" && Math.random() < 0.4) {
          n.laneTarget = Math.random() < 0.5 ? 0 : 3;
        }
      }
      const blocked = npcs.some((o) => {
        if (o === n) return false;
        return Math.abs(o.lane - n.laneTarget) < 0.4 && Math.abs(wrapDelta(o.s, n.s, track.total)) < 8;
      });
      if (!blocked) {
        const diff = n.laneTarget - n.lane;
        const stepL = Math.max(-1, Math.min(1, diff)) * dt * 0.85;
        n.lane += stepL;
      }
      if (ahead < -30 || ahead > 340) {
        n.s = proj.s + 180 + Math.random() * 150;
        n.lane = Math.floor(Math.random() * 4);
        n.laneTarget = n.lane;
        n.cruise = spec.max * (0.4 + Math.random() * 0.35);
      }
    }

    for (const w of wrongs) {
      w.s -= w.speed * dt;
      const rel = wrapDelta(w.s, proj.s, track.total);
      if (rel < -40) w.s = proj.s + 160 + Math.random() * 80;
      if (phase !== "play" || hitCd > 0) continue;
      const sm = track.sample(w.s);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      const x = sm.x + rx * w.lat;
      const z = sm.z + rz * w.lat;
      const d = Math.hypot(player.x - x, player.z - z);
      if (d < specNow().length * 0.42 + 1.3) collide(d, player.x - x, player.z - z, 10);
    }
  }

  function updateCrossers(dt: number) {
    const proj = track.project(player.x, player.z, player.hint);
    for (const c of crossers) {
      if (c.wait > 0) {
        c.wait -= dt;
        continue;
      }
      c.lat += c.dir * 1.55 * dt;
      if (Math.abs(c.lat) > ROAD_HALF + 0.85) {
        c.dir *= -1;
        c.lat = Math.sign(c.lat) * (ROAD_HALF + 0.75);
        c.wait = 2.4 + Math.random() * 3.2;
      }
      if (phase !== "play" || hitCd > 0) continue;
      if (Math.abs(player.speed) < 2.4) continue;
      if (Math.abs(wrapDelta(c.s, proj.s, track.total)) > 1.7) continue;
      if (Math.abs(c.lat - proj.lat) > 1.05) continue;
      player.speed *= 0.38;
      shake = Math.max(shake, 0.28);
      hitCd = 0.9;
      crashes += 1;
      if (cfg.mode === "rush") {
        time += 1;
        say("حد بيعدّي +١ ث");
      } else if (cfg.mode === "shift") {
        money = Math.max(0, money - 20);
        say("خد بالك، فيه ناس بتعدّي — ٢٠ ج");
      } else say("حد بيعدّي — هدّي");
      flash("crash");
      sfx.blip(170, 0.08, "square", 0.045);
    }
  }

  function collide(dist: number, dx: number, dz: number, otherSpeed: number) {
    const spec = specNow();
    const d = Math.max(0.001, dist);
    const push = 0.8;
    player.x += (dx / d) * push;
    player.z += (dz / d) * push;
    const rel = Math.abs(player.speed - otherSpeed);
    player.speed *= 0.62;
    hitCd = 0.65;
    shake = 0.35;
    if (rel > 5 && phase === "play") {
      crashes += 1;
      player.yaw += (Math.random() - 0.5) * 0.35;
      if (cfg.mode === "shift") {
        money = Math.max(0, money - 40);
        if (pax.length) {
          pax.pop();
          say("راكب نزل غصب — غرامة");
        } else say("خبطة! غرامة ٤٠ ج");
      } else if (cfg.mode === "rush") {
        time += 2;
        say("خبطة +٢ ث");
      } else say("خبطة! خد بالك");
      flash("crash");
      hitstop = reduceMotion ? 0 : 0.06;
      sfx.crash();
      burst(player.x, player.z);
    }
  }

  function gameplay(dt: number) {
    const spec = specNow();
    const proj = track.project(player.x, player.z, player.hint);
    for (const n of npcs) {
      if (!n.alive || hitCd > 0) continue;
      const sm = track.sample(n.s);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      const lat = laneLat(n.lane);
      const x = sm.x + rx * lat;
      const z = sm.z + rz * lat;
      const reach = spec.length * 0.42 + vehicleById(n.kind).length * 0.4;
      const d = Math.hypot(player.x - x, player.z - z);
      if (d < reach) {
        n.speed *= 0.75;
        collide(d, player.x - x, player.z - z, n.speed);
        break;
      }
    }

    if (hornCd > 0.15) {
      for (const n of npcs) {
        const gap = wrapDelta(n.s, proj.s, track.total);
        if (gap > 0 && gap < 22 && Math.abs(laneLat(n.lane) - proj.lat) < 4) {
          n.laneTarget = proj.lat > laneLat(n.lane) ? Math.max(0, n.lane - 1) : Math.min(3, n.lane + 1);
        }
      }
    }

    const nearStop = (index: number) => {
      const d = Math.abs(wrapDelta(track.stops[index].s, proj.s, track.total));
      return d < 20 && proj.lat > 3.05 && Math.abs(player.speed) < 4.6;
    };

    if (serviced >= 0) {
      const away = Math.abs(wrapDelta(track.stops[serviced].s, proj.s, track.total));
      if (away > 36) {
        if (waiting[serviced] <= 0) waiting[serviced] = 1 + Math.floor(Math.random() * 5);
        serviced = -1;
      }
    }

    if (cfg.mode !== "rush" && spec.seats > 0) {
      for (let i = 0; i < track.stops.length; i++) {
        if (!nearStop(i) || serviced === i) continue;
        const dropping = pax.filter((person) => person.dest === i);
        if (dropping.length) {
          const earned = Math.round(dropping.length * 36 * spec.fare);
          money += earned;
          pax = pax.filter((person) => person.dest !== i);
          say(`نزلوا — +${earned} ج`);
          flash("cash");
          sfx.cash();
        }
        const free = spec.seats - pax.length;
        if (free > 0 && waiting[i] > 0) {
          const n = Math.min(free, waiting[i]);
          let lastDest = i;
          for (let k = 0; k < n; k++) {
            const hop = 2 + Math.floor(Math.random() * 3);
            lastDest = (i + hop) % track.stops.length;
            pax.push({ dest: lastDest });
          }
          waiting[i] -= n;
          say(`ركّبت ${n} · ${track.stops[lastDest].name}`);
          sfx.cash();
        }
        serviced = i;
      }
    }

    if (cfg.mode === "rush" && phase === "play" && jobs[jobIndex] != null && nearStop(jobs[jobIndex])) {
      jobIndex += 1;
      money += 45;
      flash("cash");
      sfx.cash();
      if (jobIndex >= JOBS_NEED) {
        phase = "summary";
        settle();
        publish();
        return;
      }
      say(`وصلت — الجاية ${track.stops[jobs[jobIndex]].name}`);
    }

    if (radarCd <= 0) {
      for (const rs of track.radarS) {
        if (Math.abs(wrapDelta(rs, proj.s, track.total)) < 16 && Math.abs(player.speed) > RADAR_LIMIT) {
          radarCd = 8;
          flash("radar");
          sfx.radar();
          const which = track.radarS.indexOf(rs);
          if (cfg.mode === "rush") {
            time += 1.5;
            say(which === 1 ? "كمين +١.٥ ث" : "رادار +١.٥ ث");
          } else {
            money = Math.max(0, money - 70);
            say(which === 1 ? "كمين! غرامة ٧٠ ج" : "رادار! غرامة ٧٠ ج");
          }
          break;
        }
      }
    }

    const tollD = wrapDelta(track.tollS, proj.s, track.total);
    if (tollD > -8 && tollD < 16) {
      if (!tollLatch && player.speed > TOLL_LIMIT) {
        tollLatch = true;
        player.speed = Math.min(player.speed, TOLL_LIMIT);
        if (cfg.mode === "rush") {
          time += 1;
          say("الكوبري عايز تهدية");
        } else {
          money = Math.max(0, money - 15);
          say("نقطة مرور الكوبري — ١٥ ج");
        }
      }
    } else if (Math.abs(tollD) > 40) tollLatch = false;

    const gasD = Math.abs(wrapDelta(track.gasS, proj.s, track.total));
    if (gasD < 16 && proj.lat > 2.5 && Math.abs(player.speed) < 3.8 && fuel < 96) {
      if (!gasLatch) {
        if (pay(GAS_COST)) {
          fuel = 100;
          fuelWarned = false;
          gasLatch = true;
          say(`تملى التانك — ${GAS_COST} ج`);
          flash("cash");
          sfx.cash();
        } else {
          gasLatch = true;
          say("الفلوس مش مكفية البنزين");
        }
      }
    } else if (gasD > 30) gasLatch = false;

    if (bumpCd <= 0) {
      for (const b of track.bumps) {
        if (Math.abs(wrapDelta(b, proj.s, track.total)) < 2.5 && Math.abs(player.speed) > 8) {
          bumpCd = 1.15;
          player.speed *= 0.55;
          shake = Math.max(shake, reduceMotion ? 0 : 0.3);
          if (messageT <= 0) say("مطب!");
          sfx.blip(120, 0.07, "triangle", 0.04);
          burst(player.x, player.z);
          break;
        }
      }
    }

    if (phase === "play" && fuel <= 0 && !fuelWarned) {
      fuelWarned = true;
      say("البنزين خلّص — دور على البنزينة");
      flash("fuel");
    }
    if (phase === "play" && cfg.mode === "shift" && !halfWarned && time >= SHIFT_SECONDS - 30) {
      halfWarned = true;
      say("فاضل نص دقيقة");
    }
    if (phase === "play" && cfg.mode === "shift" && time >= SHIFT_SECONDS) {
      phase = "summary";
      settle();
      publish();
      return;
    }

    if (alongWrong(proj) && messageT <= 0) say("إنت عكس الاتجاه");
  }

  function alongWrong(proj: { yaw: number }) {
    const fx = -Math.sin(player.yaw);
    const fz = -Math.cos(player.yaw);
    const tx = -Math.sin(proj.yaw);
    const tz = -Math.cos(proj.yaw);
    return fx * tx + fz * tz < -0.45 && Math.abs(player.speed) > 3;
  }

  function drawPeople() {
    let i = 0;
    const bobT = performance.now() / 1000;
    for (let sIdx = 0; sIdx < track.stops.length; sIdx++) {
      const n = Math.min(3, waiting[sIdx] ?? 0);
      const sm = track.sample(track.stops[sIdx].s);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      for (let k = 0; k < n; k++) {
        const bob = Math.sin(bobT * 2.2 + sIdx + k) * 0.04;
        dummy.position.set(sm.x + rx * (7.15 + k * 0.72), 0.64 + bob, sm.z + rz * (7.15 + k * 0.72));
        dummy.rotation.set(0, sm.yaw + k, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();
        people.setMatrixAt(i, dummy.matrix);
        people.setColorAt(i, cloth[(sIdx + k) % cloth.length]);
        i += 1;
      }
    }
    for (const c of crossers) {
      if (i >= PEOPLE) break;
      const sm = track.sample(c.s);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      const bob = Math.sin(bobT * 4.2 + c.s) * 0.05;
      dummy.position.set(sm.x + rx * c.lat, 0.72 + bob, sm.z + rz * c.lat);
      dummy.rotation.set(0, sm.yaw + (c.dir > 0 ? Math.PI / 2 : -Math.PI / 2), 0);
      dummy.scale.set(0.82, 1.2, 0.82);
      dummy.updateMatrix();
      people.setMatrixAt(i, dummy.matrix);
      people.setColorAt(i, cloth[i % cloth.length]);
      i += 1;
    }
    for (let k = 0; k < 8 && i < PEOPLE; k++) {
      const dir = k % 2 === 0 ? 1 : -1;
      const sm = track.sample(bobT * 1.6 * dir + k * 97);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      const lat = (k % 2 === 0 ? 1 : -1) * (6.15 + (k % 3) * 0.28);
      const bob = Math.sin(bobT * 3.1 + k) * 0.05;
      dummy.position.set(sm.x + rx * lat, 0.64 + bob, sm.z + rz * lat);
      dummy.rotation.set(0, sm.yaw, 0);
      dummy.scale.set(0.92, 1, 0.92);
      dummy.updateMatrix();
      people.setMatrixAt(i, dummy.matrix);
      people.setColorAt(i, cloth[k % cloth.length]);
      i += 1;
    }
    dummy.scale.set(0, 0, 0);
    dummy.position.set(0, -24, 0);
    dummy.updateMatrix();
    for (; i < PEOPLE; i++) people.setMatrixAt(i, dummy.matrix);
    people.instanceMatrix.needsUpdate = true;
    if (people.instanceColor) people.instanceColor.needsUpdate = true;
  }

  function render(dt: number) {
    applyDusk(duskNow());
    const fwX = -Math.sin(player.yaw);
    const fwZ = -Math.cos(player.yaw);
    const dist = camMode === 0 ? 6.5 : camMode === 2 ? 16 : camMode === 3 ? 0.2 : 11;
    const height = camMode === 3 ? 1.35 : 3.1 + camMode * 0.45;
    const back = camMode === 3 ? -1.15 : dist;
    desired.set(player.x - fwX * back, height, player.z - fwZ * back);
    if (shake > 0 && !reduceMotion) {
      desired.x += (Math.random() - 0.5) * shake * 1.4;
      desired.y += (Math.random() - 0.5) * shake;
    }
    const k = 1 - Math.exp(-5 * dt);
    camPos.lerp(desired, phase === "menu" ? Math.min(1, k * 1.2) : k);
    camera.position.copy(camPos);
    const lookAhead = camMode === 3 ? 14 : 7;
    look.set(player.x + fwX * lookAhead, camMode === 3 ? 1.1 : 1.2, player.z + fwZ * lookAhead);
    camera.lookAt(look);
    const base = camMode === 3 ? 78 : 68;
    camera.fov = base + Math.min(1, Math.abs(player.speed) / 30) * 8;
    camera.updateProjectionMatrix();

    playerMesh.group.position.set(player.x, 0, player.z);
    playerMesh.group.rotation.y = player.yaw;
    playerMesh.group.rotation.z = steerVis * -0.045;
    playerMesh.group.rotation.x = (player.speed > 1 ? -0.02 : 0.03) * Math.min(1, Math.abs(player.speed) / 20);
    wheelSpin += player.speed * dt * 2.2;
    for (const w of playerMesh.wheels) w.rotation.x = wheelSpin;
    playerMesh.rider.visible = pax.length > 0 && phase !== "menu";

    const cursors: Record<VehicleId, number> = {
      malaky: 0,
      taxi: 0,
      micro: 0,
      tuktuk: 0,
      truck: 0,
    };
    const paintNpc = (kind: VehicleId, s: number, yaw: number, lat: number, color?: THREE.Color) => {
      const pool = pools.get(kind)!;
      const i = cursors[kind]++;
      if (i >= POOL) return;
      const sm = track.sample(s);
      const rx = Math.cos(sm.yaw);
      const rz = -Math.sin(sm.yaw);
      dummy.position.set(sm.x + rx * lat, 0, sm.z + rz * lat);
      dummy.rotation.set(0, yaw, 0);
      dummy.scale.set(1, 1, 1);
      dummy.updateMatrix();
      pool.body.setMatrixAt(i, dummy.matrix);
      pool.glass.setMatrixAt(i, dummy.matrix);
      pool.wheels.setMatrixAt(i, dummy.matrix);
      pool.lights.setMatrixAt(i, dummy.matrix);
      if (color) pool.body.setColorAt(i, color);
    };

    for (const n of npcs) {
      if (!n.alive) continue;
      const sm = track.sample(n.s);
      paintNpc(n.kind, n.s, sm.yaw, laneLat(n.lane), n.color);
    }
    for (const w of wrongs) {
      const sm = track.sample(w.s);
      paintNpc("tuktuk", w.s, sm.yaw + Math.PI, w.lat, tukColor);
    }
    dummy.scale.set(0, 0, 0);
    dummy.position.set(0, -30, 0);
    dummy.updateMatrix();
    for (const kind of KINDS) {
      const pool = pools.get(kind)!;
      for (let i = cursors[kind]; i < POOL; i++) {
        pool.body.setMatrixAt(i, dummy.matrix);
        pool.glass.setMatrixAt(i, dummy.matrix);
        pool.wheels.setMatrixAt(i, dummy.matrix);
        pool.lights.setMatrixAt(i, dummy.matrix);
      }
      pool.body.instanceMatrix.needsUpdate = true;
      pool.glass.instanceMatrix.needsUpdate = true;
      pool.wheels.instanceMatrix.needsUpdate = true;
      pool.lights.instanceMatrix.needsUpdate = true;
      if (pool.body.instanceColor) pool.body.instanceColor.needsUpdate = true;
    }

    drawPeople();

    for (const spark of sparks) {
      if (spark.life <= 0) continue;
      spark.life -= dt;
      spark.v.y -= 9 * dt;
      spark.m.position.addScaledVector(spark.v, dt);
      if (spark.life <= 0) spark.m.visible = false;
    }

    drawMap();
    renderer.render(scene, camera);
  }

  const mapPts = track.pts.filter((_, i) => i % 2 === 0);
  let minX = Infinity;
  let maxX = -Infinity;
  let minZ = Infinity;
  let maxZ = -Infinity;
  for (const p of mapPts) {
    minX = Math.min(minX, p.x);
    maxX = Math.max(maxX, p.x);
    minZ = Math.min(minZ, p.z);
    maxZ = Math.max(maxZ, p.z);
  }

  function drawMap() {
    const ctx = map.getContext("2d");
    if (!ctx) return;
    const w = map.width;
    const h = map.height;
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = "rgba(20,24,30,0.72)";
    ctx.beginPath();
    ctx.arc(w / 2, h / 2, w / 2 - 2, 0, Math.PI * 2);
    ctx.fill();
    const pad = 16;
    const sx = (w - pad * 2) / (maxX - minX || 1);
    const sy = (h - pad * 2) / (maxZ - minZ || 1);
    const sc = Math.min(sx, sy);
    const ox = w / 2 - ((minX + maxX) / 2) * sc;
    const oy = h / 2 - ((minZ + maxZ) / 2) * sc;
    const px = (x: number, z: number) => [ox + x * sc, oy + z * sc] as const;
    ctx.beginPath();
    mapPts.forEach((p, i) => {
      const [x, y] = px(p.x, p.z);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.closePath();
    ctx.strokeStyle = "#f0b429";
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.fillStyle = "#1aa6a6";
    track.stops.forEach((stop, i) => {
      const sm = track.sample(stop.s);
      const [x, y] = px(sm.x, sm.z);
      const hot = cfg.mode === "rush" ? jobs[jobIndex] === i : false;
      ctx.fillStyle = hot ? "#f0b429" : "#1aa6a6";
      ctx.fillRect(x - (hot ? 3 : 1.6), y - (hot ? 3 : 1.6), hot ? 6 : 3.2, hot ? 6 : 3.2);
    });
    const gas = track.sample(track.gasS);
    const [gx, gy] = px(gas.x, gas.z);
    ctx.fillStyle = "#f0b429";
    ctx.beginPath();
    ctx.arc(gx, gy, 3.2, 0, Math.PI * 2);
    ctx.fill();
    const [x, y] = px(player.x, player.z);
    ctx.fillStyle = "#f6f1e7";
    ctx.beginPath();
    ctx.arc(x, y, 3.5, 0, Math.PI * 2);
    ctx.fill();
    const fx = -Math.sin(player.yaw);
    const fz = -Math.cos(player.yaw);
    const [hx, hy] = px(player.x + fx * 22, player.z + fz * 22);
    ctx.strokeStyle = "#f6f1e7";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(hx, hy);
    ctx.stroke();
  }

  function frame(now: number) {
    if (!running) return;
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    acc += dt;
    let steps = 0;
    while (acc >= 1 / 60 && steps < 5) {
      if (hitstop > 0) hitstop = Math.max(0, hitstop - 1 / 60);
      else if (phase !== "pause" && phase !== "summary") step(1 / 60);
      acc -= 1 / 60;
      steps++;
    }
    render(dt);
    hudAcc += dt;
    if (hudAcc > 0.12) {
      hudAcc = 0;
      if (phase === "play" || phase === "summary" || phase === "pause") publish();
    }
    raf = requestAnimationFrame(frame);
  }

  function resize() {
    const w = canvas.clientWidth || 1;
    const h = canvas.clientHeight || 1;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.6);
    renderer.setPixelRatio(dpr);
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  resize();
  const ro = new ResizeObserver(() => resize());
  ro.observe(canvas);

  const onDown = (e: KeyboardEvent) => {
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code)) e.preventDefault();
    keys.add(e.code);
    if (e.repeat) return;
    if (e.code === "Space" || e.code === "KeyH") honk();
    if (e.code === "KeyC") cycleCam();
    if (e.code === "Escape") {
      if (phase === "play") phase = "pause";
      else if (phase === "pause") phase = "play";
      publish();
    }
  };
  const onUp = (e: KeyboardEvent) => keys.delete(e.code);
  const onBlur = () => keys.clear();
  window.addEventListener("keydown", onDown);
  window.addEventListener("keyup", onUp);
  window.addEventListener("blur", onBlur);

  function honk() {
    if (hornCd > 0) return;
    hornCd = 0.85;
    sfx.unlock();
    sfx.horn();
  }

  function cycleCam() {
    camMode = (camMode + 1) % 4;
  }

  window.__controlsTest = {
    getYaw: () => player.yaw,
    getSpeed: () => player.speed,
    setKeys: (codes: string[]) => {
      probeKeys = codes.length ? new Set(codes) : null;
      if (probeKeys && phase !== "play") start(cfg);
    },
    setSteer: (v: number) => {
      probeSteer = v;
    },
  };

  publish();
  raf = requestAnimationFrame(frame);

  return {
    getHud: hud,
    setPreview: (next) => {
      const paintChanged = next.paint !== cfg.paint;
      const nightChanged = next.night !== cfg.night;
      cfg = { ...next, vehicle: "tuktuk" };
      sfx.on = cfg.sound;
      save.sound = cfg.sound;
      writeSave(save);
      if (paintChanged && phase === "menu") swapPlayer("tuktuk", cfg.paint);
      if (nightChanged) applyDusk(duskNow());
      if (phase === "menu") publish();
    },
    start,
    pause: () => {
      if (phase === "play") {
        phase = "pause";
        publish();
      }
    },
    resume: () => {
      if (phase === "pause") {
        phase = "play";
        publish();
      }
    },
    quit: () => {
      persist();
      phase = "menu";
      probeKeys = null;
      bootCinematic();
      spawnTraffic(track.stops[0].s);
      publish();
    },
    finish: () => {
      if (phase !== "play") return;
      phase = "summary";
      settle();
      publish();
    },
    buy: (id: UpgradeId) => {
      const def = UPGRADES.find((u) => u.id === id);
      if (!def) return;
      const lvl = save.upgrades[id];
      if (lvl >= def.max) return;
      const cost = def.costs[lvl];
      if (save.wallet < cost) return;
      save.wallet -= cost;
      save.upgrades[id] = lvl + 1;
      writeSave(save);
      sfx.unlock();
      sfx.cash();
      publish();
    },
    setTouch: (t) => {
      touch.steer = t.steer;
      touch.throttle = t.throttle;
      touch.brake = t.brake;
    },
    horn: honk,
    cycleCam,
    toggleSound: () => {
      sfx.on = !sfx.on;
      cfg.sound = sfx.on;
      save.sound = sfx.on;
      writeSave(save);
      if (sfx.on) sfx.unlock();
      publish();
    },
    dispose: () => {
      running = false;
      cancelAnimationFrame(raf);
      ro.disconnect();
      window.removeEventListener("keydown", onDown);
      window.removeEventListener("keyup", onUp);
      window.removeEventListener("blur", onBlur);
      if (window.__controlsTest?.getYaw === (() => player.yaw) || window.__controlsTest) {
        delete window.__controlsTest;
      }
      sfx.stop();
      renderer.dispose();
    },
  };
}

function buildRoad(scene: THREE.Scene, track: Track) {
  const pts = track.pts;
  const half = ROAD_HALF;
  const positions: number[] = [];
  const uvs: number[] = [];
  const n = pts.length;
  const edge = (i: number, lat: number) => {
    const p = pts[i];
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    return [p.x + rx * lat, 0.02, p.z + rz * lat] as const;
  };
  let distAcc = 0;
  for (let i = 0; i < n; i++) {
    const a = edge(i, -half);
    const b = edge(i, half);
    const c = edge((i + 1) % n, -half);
    const d = edge((i + 1) % n, half);
    positions.push(...a, ...b, ...d, ...a, ...d, ...c);
    const v0 = distAcc / 8;
    const v1 = (distAcc + pts[i].len) / 8;
    uvs.push(0, v0, 1, v0, 1, v1, 0, v0, 1, v1, 0, v1);
    distAcc += pts[i].len;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2));
  geo.computeVertexNormals();
  const asphalt = asphaltTexture();
  const mat = new THREE.MeshStandardMaterial({
    color: "#ffffff",
    map: asphalt ?? undefined,
    roughness: 0.96,
    metalness: 0.02,
  });
  scene.add(new THREE.Mesh(geo, mat));

  const dashes: THREE.Matrix4[] = [];
  const dash = new THREE.Object3D();
  for (let i = 0; i < n; i += 6) {
    const p = pts[i];
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    dash.position.set(p.x + rx * 0, 0.045, p.z + rz * 0);
    dash.rotation.set(0, p.yaw, 0);
    dash.scale.set(1, 1, 1);
    dash.updateMatrix();
    dashes.push(dash.matrix.clone());
  }
  const dashMesh = new THREE.InstancedMesh(
    new THREE.BoxGeometry(0.12, 0.015, 1.6),
    new THREE.MeshStandardMaterial({ color: "#d9d3c6", roughness: 0.7 }),
    Math.max(1, dashes.length),
  );
  dashes.forEach((m, i) => dashMesh.setMatrixAt(i, m));
  scene.add(dashMesh);

  const curbs: THREE.Matrix4[] = [];
  const walks: THREE.Matrix4[] = [];
  const curb = new THREE.Object3D();
  for (let i = 0; i < n; i += 2) {
    const p = pts[i];
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    for (const side of [-1, 1]) {
      curb.position.set(p.x + rx * side * (half + 0.35), 0.12, p.z + rz * side * (half + 0.35));
      curb.rotation.set(0, p.yaw, 0);
      curb.scale.set(1, 1, 1);
      curb.updateMatrix();
      curbs.push(curb.matrix.clone());
      curb.position.set(p.x + rx * side * (half + 2.15), 0.06, p.z + rz * side * (half + 2.15));
      curb.updateMatrix();
      walks.push(curb.matrix.clone());
    }
  }
  const curbMesh = new THREE.InstancedMesh(
    new THREE.BoxGeometry(0.28, 0.18, 7.2),
    new THREE.MeshStandardMaterial({ color: "#d7d0c4", roughness: 0.85 }),
    curbs.length,
  );
  curbs.forEach((m, i) => curbMesh.setMatrixAt(i, m));
  const walkTex = sidewalkTexture();
  const walkMesh = new THREE.InstancedMesh(
    new THREE.BoxGeometry(2.6, 0.08, 7.2),
    new THREE.MeshStandardMaterial({ color: "#ffffff", map: walkTex ?? undefined, roughness: 0.94 }),
    walks.length,
  );
  walks.forEach((m, i) => walkMesh.setMatrixAt(i, m));
  scene.add(curbMesh, walkMesh);
}

function buildCity(scene: THREE.Scene, track: Track) {
  const kit = buildingKit();
  const mats = kit.facadeMats;
  const meshes: THREE.InstancedMesh[] = [];
  kit.sets.forEach((set) => {
    const mesh = new THREE.InstancedMesh(kit.box, set, 90);
    mesh.count = 0;
    mesh.frustumCulled = false;
    scene.add(mesh);
    meshes.push(mesh);
  });
  const counts = kit.sets.map(() => 0);
  const dummy = new THREE.Object3D();
  const tanks: THREE.Matrix4[] = [];
  const tankO = new THREE.Object3D();
  const pts = track.pts;
  for (let i = 0; i < pts.length; i += 4) {
    const p = pts[i];
    const nxt = pts[(i + 8) % pts.length];
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    const hsh = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1;
    const bending = Math.abs(wrapAngle(nxt.yaw - p.yaw)) > 0.28;
    const nearS = (s: number, pad: number) => {
      let d = Math.abs(p.s - s);
      if (d > track.total * 0.5) d = track.total - d;
      return d < pad;
    };
    if (track.stops.some((stop) => nearS(stop.s, 18)) || nearS(track.gasS, 12)) continue;
    const outward = Math.sign(p.x * rx + p.z * rz) || 1;
    const sides = bending ? [outward] : [-1, 1];
    for (const side of sides) {
      const floors = 5 + Math.floor(hsh * 4);
      const height = floors * 2.9;
      const width = 6.2 + hsh * 1.4;
      const along = 8.2 + (1 - hsh) * 3.2;
      const lateral = 13.2 + (hsh - 0.5) * 0.6;
      const idx = (i + (side > 0 ? 1 : 0)) % meshes.length;
      if (counts[idx] >= 90) continue;
      dummy.position.set(p.x + rx * side * lateral, height / 2, p.z + rz * side * lateral);
      dummy.rotation.set(0, p.yaw, 0);
      dummy.scale.set(width, height, along);
      dummy.updateMatrix();
      meshes[idx].setMatrixAt(counts[idx]++, dummy.matrix);
      if (hsh > 0.35) {
        tankO.position.set(p.x + rx * side * lateral, height + 0.75, p.z + rz * side * lateral);
        tankO.rotation.set(0, hsh, 0);
        tankO.scale.set(1, 1, 1);
        tankO.updateMatrix();
        tanks.push(tankO.matrix.clone());
      }
    }
  }
  meshes.forEach((m, i) => {
    m.count = counts[i];
    m.instanceMatrix.needsUpdate = true;
  });
  if (tanks.length) {
    const tankMesh = new THREE.InstancedMesh(
      new THREE.CylinderGeometry(0.85, 0.85, 1.35, 8),
      new THREE.MeshStandardMaterial({ color: "#b7bcc2", roughness: 0.45, metalness: 0.35 }),
      tanks.length,
    );
    tankMesh.frustumCulled = false;
    tanks.forEach((m, i) => tankMesh.setMatrixAt(i, m));
    scene.add(tankMesh);
  }
  return mats;
}

function buildLamps(scene: THREE.Scene, track: Track) {
  const mats: THREE.Matrix4[] = [];
  const heads: THREE.Matrix4[] = [];
  const o = new THREE.Object3D();
  const pts = track.pts;
  for (let i = 0; i < pts.length; i += 8) {
    const p = pts[i];
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    o.position.set(p.x + rx * 11.4, 3.1, p.z + rz * 11.4);
    o.rotation.set(0, 0, 0);
    o.scale.set(1, 1, 1);
    o.updateMatrix();
    mats.push(o.matrix.clone());
    o.position.y = 6.3;
    o.updateMatrix();
    heads.push(o.matrix.clone());
  }
  const pole = new THREE.InstancedMesh(
    new THREE.CylinderGeometry(0.12, 0.16, 6.2, 6),
    new THREE.MeshStandardMaterial({ color: "#2c3138", roughness: 0.6 }),
    mats.length,
  );
  mats.forEach((m, i) => pole.setMatrixAt(i, m));
  scene.add(pole);
  const bulbMat = new THREE.MeshStandardMaterial({
    color: "#fff1cc",
    emissive: "#ffd78a",
    emissiveIntensity: 0.05,
  });
  const bulbs = new THREE.InstancedMesh(new THREE.SphereGeometry(0.28, 8, 8), bulbMat, heads.length);
  heads.forEach((m, i) => bulbs.setMatrixAt(i, m));
  scene.add(bulbs);
  return bulbMat;
}


declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
      setSteer?: (v: number) => void;
    };
  }
}
