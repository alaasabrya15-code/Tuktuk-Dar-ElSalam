import { STOP_NAMES } from "./types";

export const LANE_W = 3.45;
export const ROAD_HALF = 8.15;

export type Sample = { x: number; z: number; s: number; yaw: number; len: number };

export type Proj = {
  i: number;
  s: number;
  x: number;
  z: number;
  yaw: number;
  lat: number;
  dist: number;
};

export type Track = {
  pts: Sample[];
  total: number;
  stops: { name: string; s: number }[];
  tollS: number;
  radarS: number[];
  gasS: number;
  bumps: number[];
  streetLength: number;
  sample: (s: number) => { x: number; z: number; yaw: number; s: number };
  project: (x: number, z: number, hint: number) => Proj;
};

export function laneLat(lane: number) {
  return (lane - 1.5) * LANE_W;
}

export function wrapDelta(a: number, b: number, total: number) {
  let d = a - b;
  const h = total * 0.5;
  while (d > h) d -= total;
  while (d < -h) d += total;
  return d;
}

export function wrapAngle(d: number) {
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return d;
}

export function buildTrack(): Track {
  // 2.2 km outbound Fayoum Street corridor; the parallel return leg preserves the driving loop.
  const straight = 2200;
  const radius = 18;
  const segStraight = 440;
  const segArc = 36;
  const raw: { x: number; z: number }[] = [];

  for (let i = 0; i <= segStraight; i++) {
    const u = i / segStraight;
    const env = Math.sin(u * Math.PI);
    const wob = env * (Math.sin(u * Math.PI * 4) * 2.1 + Math.sin(u * Math.PI * 9) * 0.55);
    raw.push({ x: -radius + wob, z: -straight / 2 + u * straight });
  }
  for (let i = 1; i <= segArc; i++) {
    const ang = Math.PI - (i / segArc) * Math.PI;
    raw.push({ x: Math.cos(ang) * radius, z: straight / 2 + Math.sin(ang) * radius });
  }
  for (let i = 1; i <= segStraight; i++) {
    const u = i / segStraight;
    const env = Math.sin(u * Math.PI);
    const wob = env * (Math.sin(u * Math.PI * 3.5 + 0.6) * 1.8);
    raw.push({ x: radius + wob, z: straight / 2 - u * straight });
  }
  for (let i = 1; i < segArc; i++) {
    const ang = -(i / segArc) * Math.PI;
    raw.push({ x: Math.cos(ang) * radius, z: -straight / 2 + Math.sin(ang) * radius });
  }

  const pts: Sample[] = [];
  let s = 0;
  const N = raw.length;
  for (let i = 0; i < N; i++) {
    const a = raw[i];
    const b = raw[(i + 1) % N];
    const dx = b.x - a.x;
    const dz = b.z - a.z;
    const len = Math.hypot(dx, dz) || 0.001;
    const yaw = Math.atan2(-dx / len, -dz / len);
    pts.push({ x: a.x, z: a.z, s, yaw, len });
    s += len;
  }
  const total = s;

  const stopProgress = [0.012, 0.095, 0.19, 0.29, 0.41, 0.57, 0.65, 0.74, 0.83, 0.94, 0.988];
  const stops = STOP_NAMES.map((name, i) => ({ name, s: stopProgress[i] * straight }));

  const tollS = stops[0].s + 6;
  const radarS = [0.24, 0.62, 0.87].map((t) => t * straight);
  const gasS = straight * 0.48;
  // Speed bumps are concentrated by the school-complex section.
  const bumps = [0.565, 0.585, 0.605, 0.625].map((t) => t * straight);

  function sample(dist: number) {
    let sDist = dist % total;
    if (sDist < 0) sDist += total;
    let lo = 0;
    let hi = pts.length - 1;
    while (lo < hi) {
      const mid = (lo + hi + 1) >> 1;
      if (pts[mid].s <= sDist) lo = mid;
      else hi = mid - 1;
    }
    const p = pts[lo];
    const n = pts[(lo + 1) % pts.length];
    const u = Math.min(1, Math.max(0, (sDist - p.s) / p.len));
    return {
      x: p.x + (n.x - p.x) * u,
      z: p.z + (n.z - p.z) * u,
      yaw: p.yaw,
      s: sDist,
    };
  }

  function project(x: number, z: number, hint: number): Proj {
    const scan = (from: number, count: number) => {
      let best: Proj | null = null;
      for (let k = 0; k < count; k++) {
        const i = (from + k + pts.length * 8) % pts.length;
        const p = pts[i];
        const n = pts[(i + 1) % pts.length];
        const dx = n.x - p.x;
        const dz = n.z - p.z;
        const l2 = dx * dx + dz * dz || 1;
        let t = ((x - p.x) * dx + (z - p.z) * dz) / l2;
        if (t < 0) t = 0;
        else if (t > 1) t = 1;
        const px = p.x + dx * t;
        const pz = p.z + dz * t;
        const dist = Math.hypot(x - px, z - pz);
        if (!best || dist < best.dist) {
          const rx = Math.cos(p.yaw);
          const rz = -Math.sin(p.yaw);
          best = {
            i,
            s: p.s + p.len * t,
            x: px,
            z: pz,
            yaw: p.yaw,
            lat: (x - px) * rx + (z - pz) * rz,
            dist,
          };
        }
      }
      return best!;
    };

    if (hint < 0) return scan(0, pts.length);
    const near = scan(hint - 30, 70);
    if (near.dist > 24) return scan(0, pts.length);
    return near;
  }

  return { pts, total, stops, tollS, radarS, gasS, bumps, streetLength: straight, sample, project };
}
