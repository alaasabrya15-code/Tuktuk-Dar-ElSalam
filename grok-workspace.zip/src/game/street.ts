import * as THREE from "three";
import { ROAD_HALF, type Track } from "./track";

/** Sidewalk spill into the right lane — checked by the sim. */
export const OCCUPATIONS: { s: number; lat: number }[] = [];

function texOf(c: HTMLCanvasElement) {
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

function board(lines: string[], bg: string, fg: string, h = 320) {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = h;
  const g = c.getContext("2d");
  if (!g) return null;
  g.fillStyle = bg;
  g.fillRect(0, 0, 512, h);
  g.fillStyle = "#f0b429";
  g.fillRect(0, 0, 512, 14);
  g.direction = "rtl";
  g.textAlign = "center";
  g.fillStyle = fg;
  const step = Math.min(64, (h - 40) / lines.length);
  lines.forEach((line, i) => {
    g.font = i === 0 ? "800 54px Tajawal, 'DejaVu Sans', sans-serif" : "700 36px Tajawal, 'DejaVu Sans', sans-serif";
    g.fillText(line, 256, 70 + i * step);
  });
  return texOf(c);
}

function stamp(list: THREE.Matrix4[], o: THREE.Object3D) {
  o.updateMatrix();
  list.push(o.matrix.clone());
}

function addInstances(
  scene: THREE.Scene,
  geo: THREE.BufferGeometry,
  mat: THREE.Material,
  mats: THREE.Matrix4[],
  colors?: THREE.Color[],
) {
  if (!mats.length) return null;
  const mesh = new THREE.InstancedMesh(geo, mat, mats.length);
  mesh.frustumCulled = false;
  mesh.castShadow = false;
  mesh.receiveShadow = true;
  mats.forEach((m, i) => mesh.setMatrixAt(i, m));
  if (colors) colors.forEach((c, i) => mesh.setColorAt(i, c));
  scene.add(mesh);
  return mesh;
}

function side(p: { x: number; z: number; yaw: number }, lat: number, y: number) {
  const rx = Math.cos(p.yaw);
  const rz = -Math.sin(p.yaw);
  return { x: p.x + rx * lat, y, z: p.z + rz * lat };
}

/** Props that make Fayoum Street read as Dar El Salam: vendors, gallons, racks, crosswalks, footbridge, dust. */
export function dressStreet(scene: THREE.Scene, track: Track) {
  OCCUPATIONS.length = 0;
  const o = new THREE.Object3D();
  const racks: THREE.Matrix4[] = [];
  const cloth: THREE.Matrix4[] = [];
  const clothCols: THREE.Color[] = [];
  const gallons: THREE.Matrix4[] = [];
  const chairs: THREE.Matrix4[] = [];
  const produce: THREE.Matrix4[] = [];
  const produceCols: THREE.Color[] = [];
  const carts: THREE.Matrix4[] = [];
  const stripes: THREE.Matrix4[] = [];
  const cones: THREE.Matrix4[] = [];
  const colors = ["#c45c3e", "#1d4e89", "#f4f1ea", "#2f6b3a", "#111", "#e6c27a", "#6b3a5d"].map(
    (h) => new THREE.Color(h),
  );
  const veg = ["#2f6b3a", "#c0392b", "#e67e22", "#f4d03f", "#8e44ad"].map((h) => new THREE.Color(h));

  const pts = track.pts;
  for (let i = 8; i < pts.length; i += 7) {
    const p = pts[i];
    const nxt = pts[(i + 6) % pts.length];
    const bend = Math.abs(((nxt.yaw - p.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
    if (bend > 0.18) continue;
    const hsh = Math.abs(Math.sin(i * 9.17) * 43758.5453) % 1;
    // right sidewalk spill (Egypt drives on the right)
    if (i % 14 === 8) {
      const lat = 5.55 + hsh * 0.7;
      const at = side(p, lat, 0.55);
      o.position.set(at.x, 0.55, at.z);
      o.rotation.set(0, p.yaw, 0);
      o.scale.set(1.1, 0.9, 0.7);
      stamp(carts, o);
      OCCUPATIONS.push({ s: p.s, lat });
      for (let k = 0; k < 3; k++) {
        const vegAt = side(p, lat - 0.15, 1.05);
        o.position.set(vegAt.x, 1.05 + k * 0.02, vegAt.z);
        o.scale.set(0.28, 0.22, 0.28);
        stamp(produce, o);
        produceCols.push(veg[(i + k) % veg.length]);
      }
    }
    if (i % 11 === 1) {
      const at = side(p, ROAD_HALF + 2.4, 0.7);
      o.position.set(at.x, 0.7, at.z);
      o.rotation.set(0, p.yaw, 0);
      o.scale.set(1.4, 1.15, 0.35);
      stamp(racks, o);
      for (let k = 0; k < 4; k++) {
        o.position.set(at.x, 0.85, at.z);
        o.scale.set(0.22, 0.55, 0.08);
        o.position.x += Math.cos(p.yaw) * (k - 1.5) * 0.28;
        o.position.z += -Math.sin(p.yaw) * (k - 1.5) * 0.28;
        stamp(cloth, o);
        clothCols.push(colors[(i + k) % colors.length]);
      }
    }
    if (i % 9 === 4) {
      const at = side(p, ROAD_HALF + 1.7, 0.22);
      for (let k = 0; k < 3; k++) {
        o.position.set(at.x, 0.18 + k * 0.28, at.z);
        o.rotation.set(0, p.yaw + k, 0);
        o.scale.set(0.32, 0.42, 0.32);
        stamp(gallons, o);
      }
    }
    if (i % 13 === 2) {
      const at = side(p, ROAD_HALF + 2.1, 0.42);
      o.position.set(at.x, 0.42, at.z);
      o.rotation.set(0, p.yaw + 0.4, 0);
      o.scale.set(0.42, 0.08, 0.42);
      stamp(chairs, o);
    }
  }

  for (const stop of track.stops) {
    for (let k = -3; k <= 3; k++) {
      const sm = track.sample(stop.s + k * 1.15);
      o.position.set(sm.x, 0.05, sm.z);
      o.rotation.set(0, sm.yaw, 0);
      o.scale.set(7.2, 1, 0.38);
      stamp(stripes, o);
    }
  }

  const kamin = track.radarS[1] ?? track.total * 0.41;
  for (let k = 0; k < 6; k++) {
    const sm = track.sample(kamin - 6 + k * 2.2);
    const rx = Math.cos(sm.yaw);
    const rz = -Math.sin(sm.yaw);
    const lat = k % 2 === 0 ? 2.2 : 5.4;
    o.position.set(sm.x + rx * lat, 0.35, sm.z + rz * lat);
    o.rotation.set(0, sm.yaw, 0);
    o.scale.set(1, 1, 1);
    stamp(cones, o);
  }

  const metal = new THREE.MeshStandardMaterial({ color: "#8d949c", roughness: 0.45, metalness: 0.35 });
  addInstances(scene, new THREE.BoxGeometry(1, 1, 1), metal, racks);
  addInstances(
    scene,
    new THREE.BoxGeometry(1, 1, 1),
    new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.8 }),
    cloth,
    clothCols,
  );
  addInstances(
    scene,
    new THREE.CylinderGeometry(0.5, 0.5, 1, 8),
    new THREE.MeshStandardMaterial({ color: "#d5ebe8", roughness: 0.4 }),
    gallons,
  );
  addInstances(
    scene,
    new THREE.BoxGeometry(1, 1, 1),
    new THREE.MeshStandardMaterial({ color: "#f4f1ea", roughness: 0.7 }),
    chairs,
  );
  addInstances(
    scene,
    new THREE.SphereGeometry(0.5, 6, 5),
    new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.7 }),
    produce,
    produceCols,
  );
  addInstances(
    scene,
    new THREE.BoxGeometry(1, 1, 1),
    new THREE.MeshStandardMaterial({ color: "#6b4a2b", roughness: 0.85 }),
    carts,
  );
  addInstances(
    scene,
    new THREE.BoxGeometry(1, 0.02, 1),
    new THREE.MeshStandardMaterial({ color: "#f4f0e4", roughness: 0.6 }),
    stripes,
  );
  const coneGeo = new THREE.ConeGeometry(0.22, 0.7, 7);
  coneGeo.translate(0, 0.35, 0);
  addInstances(
    scene,
    coneGeo,
    new THREE.MeshStandardMaterial({ color: "#e23b2b", roughness: 0.55 }),
    cones,
  );

  footbridge(scene, track, track.total * 0.5);
  dust(scene, track);
}

function footbridge(scene: THREE.Scene, track: Track, dist: number) {
  const sm = track.sample(dist);
  const g = new THREE.Group();
  g.position.set(sm.x, 0, sm.z);
  g.rotation.y = sm.yaw;
  const concrete = new THREE.MeshStandardMaterial({ color: "#c8c2b6", roughness: 0.86 });
  const rail = new THREE.MeshStandardMaterial({ color: "#3d4650", roughness: 0.5, metalness: 0.2 });
  const deck = new THREE.Mesh(new THREE.BoxGeometry(24, 0.16, 1.8), concrete);
  deck.position.y = 4.7;
  const r1 = new THREE.Mesh(new THREE.BoxGeometry(24, 0.9, 0.08), rail);
  r1.position.set(0, 5.2, 0.85);
  const r2 = r1.clone();
  r2.position.z = -0.85;
  for (const sideX of [-11.2, 11.2]) {
    const stair = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.14, 5.2), concrete);
    stair.position.set(sideX, 2.4, 3.2);
    stair.rotation.x = -0.72;
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.28, 4.7, 0.28), concrete);
    post.position.set(sideX, 2.35, 0);
    g.add(stair, post);
  }
  g.add(deck, r1, r2);
  scene.add(g);
}

function dust(scene: THREE.Scene, track: Track) {
  const n = 280;
  const pos = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const sm = track.sample((i / n) * track.total);
    const rx = Math.cos(sm.yaw);
    const rz = -Math.sin(sm.yaw);
    const lat = (i % 2 === 0 ? 1 : -1) * (4 + (i % 9));
    pos[i * 3] = sm.x + rx * lat;
    pos[i * 3 + 1] = 1.2 + (i % 7) * 0.7;
    pos[i * 3 + 2] = sm.z + rz * lat;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  const pts = new THREE.Points(
    geo,
    new THREE.PointsMaterial({
      color: "#cbb89a",
      size: 0.22,
      transparent: true,
      opacity: 0.28,
      depthWrite: false,
      sizeAttenuation: true,
    }),
  );
  pts.frustumCulled = false;
  const base = pos.slice(0);
  pts.onBeforeRender = () => {
    const t = performance.now() * 0.00015;
    const arr = geo.attributes.position.array as Float32Array;
    for (let i = 0; i < n; i++) {
      arr[i * 3] = base[i * 3] + Math.sin(t + i) * 0.35;
      arr[i * 3 + 1] = base[i * 3 + 1] + Math.sin(t * 2 + i * 0.7) * 0.2;
    }
    geo.attributes.position.needsUpdate = true;
  };
  scene.add(pts);
}

export function placeLocalSigns(scene: THREE.Scene, track: Track) {
  const hang = (dist: number, lat: number, lines: string[], bg: string, fg = "#f6f1e7", w = 4.2, h = 2.4) => {
    const map = board(lines, bg, fg, Math.round(256 * (h / 2.2)));
    if (!map) return;
    const sm = track.sample(dist);
    const rx = Math.cos(sm.yaw);
    const rz = -Math.sin(sm.yaw);
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(w, h),
      new THREE.MeshStandardMaterial({ map, roughness: 0.6, side: THREE.DoubleSide }),
    );
    mesh.position.set(sm.x + rx * lat, 3.4, sm.z + rz * lat);
    mesh.rotation.y = sm.yaw;
    scene.add(mesh);
  };

  hang(track.stops[1].s - 8, 10.2, ["موقف كوبري دار السلام", "السيدة زينب", "الجيزة", "الزهراء · المعادي", "الهرم · التحرير"], "#0b3a82");
  hang(track.stops[6].s - 4, 11.4, ["مترو دار السلام", "الخط الأول"], "#c0392b");
  hang(track.total * 0.5 - 10, -11, ["كوبري المشاة", "ناحية السوق"], "#3d4650");
  hang(track.stops[12].s, 11, ["شارع المحجر", "مدخل الحي"], "#1c2833", "#f0b429", 3.6, 1.8);
  hang(track.stops[13].s - 12, 10.6, ["شارع أحمد زكي", "آخر شارع الفيوم"], "#1c2833", "#f0b429", 4.4, 2);

  const pts = track.pts;
  for (let i = 20; i < pts.length; i += 46) {
    const p = pts[i];
    const bend = Math.abs(((pts[(i + 8) % pts.length].yaw - p.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
    if (bend > 0.16) continue;
    hang(p.s, 12.2, ["شارع الفيوم", "حي دار السلام"], "#16324f", "#f6f1e7", 3.4, 1.5);
  }
}
