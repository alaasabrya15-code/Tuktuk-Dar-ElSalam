import * as THREE from "three";
import { ROAD_HALF, type Track } from "./track";

const plasters = ["#d9c7a6", "#cbb496", "#e6d5b8", "#b9ad9a", "#c9a48c"];
const signBands = ["#c0392b", "#1a5276", "#1e8449", "#b7950b", "#6c3483"];

function texOf(c: HTMLCanvasElement) {
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

function pair(seed: number) {
  const face = document.createElement("canvas");
  face.width = 512;
  face.height = 1024;
  const glow = document.createElement("canvas");
  glow.width = 512;
  glow.height = 1024;
  const g = face.getContext("2d");
  const e = glow.getContext("2d");
  if (!g || !e) return null;
  const plaster = plasters[seed % plasters.length];
  g.fillStyle = plaster;
  g.fillRect(0, 0, 512, 1024);
  e.fillStyle = "#000";
  e.fillRect(0, 0, 512, 1024);

  // heavy weathering & dirt streaks
  for (let i = 0; i < 220; i++) {
    const a = 0.02 + (i % 7) * 0.01;
    g.fillStyle = `rgba(55,40,25,${a})`;
    g.fillRect((i * 53) % 512, (i * 97) % 820, 12 + (i % 40), 6 + (i % 22));
  }
  // vertical dirt streaks from AC / rain
  for (let i = 0; i < 18; i++) {
    const x = 20 + ((i * 97) % 470);
    g.fillStyle = `rgba(40,30,20,${0.08 + (i % 4) * 0.03})`;
    g.fillRect(x, 80 + (i % 5) * 40, 3 + (i % 3), 180 + (i % 6) * 50);
  }

  // Weathered exposed-concrete parapet, common on unfinished upper floors.
  g.fillStyle = "#8f8c83";
  g.fillRect(0, 0, 512, 90);
  for (let i = 0; i < 95; i++) {
    const shade = 95 + (i * 17) % 55;
    g.fillStyle = "rgba(110,108,102,0.18)";
    g.fillRect((i * 47) % 512, (i * 29) % 88, 10 + (i % 24), 3 + (i % 7));
  }
  g.fillStyle = "#6f6d66";
  g.fillRect(0, 82, 512, 8);
  g.fillStyle = "rgba(235,228,211,0.24)";
  g.fillRect(0, 4, 512, 5);

  const floorH = 100;
  for (let f = 0; f < 8; f++) {
    const y = 100 + f * floorH;
    // balcony slab
    g.fillStyle = "rgba(55,48,40,0.55)";
    g.fillRect(8, y + 68, 496, 10);
    g.fillStyle = "#4a535a";
    g.fillRect(10, y + 42, 492, 3);
    for (let x = 16; x < 500; x += 10) g.fillRect(x, y + 42, 3, 26);

    for (let w = 0; w < 4; w++) {
      const x = 28 + w * 120;
      const wave = Math.sin(seed * 2.1 + f * 1.7 + w * 2.4);
      const lit = wave > 0.2;
      const open = wave < -0.5;
      // window frame
      g.fillStyle = "#e8e0d2";
      g.fillRect(x - 4, y + 4, 72, 58);
      // glass
      g.fillStyle = open ? "#4a6a78" : lit ? "#f5d9a8" : "#7a93a0";
      g.fillRect(x, y + 8, 64, 50);
      if (!open) {
        g.strokeStyle = "rgba(255,255,255,0.35)";
        g.lineWidth = 1.5;
        g.beginPath();
        g.moveTo(x + 32, y + 8);
        g.lineTo(x + 32, y + 58);
        g.moveTo(x, y + 33);
        g.lineTo(x + 64, y + 33);
        g.stroke();
      }
      if (lit && !open) {
        e.fillStyle = "#ffcc77";
        e.fillRect(x, y + 8, 64, 50);
      }
      // AC unit
      if ((f + w + seed) % 3 === 0) {
        g.fillStyle = "#f0ebe3";
        g.fillRect(x + 68, y + 14, 28, 22);
        g.fillStyle = "#a8b0b8";
        g.fillRect(x + 70, y + 22, 24, 4);
        g.fillStyle = "rgba(0,0,0,0.25)";
        g.fillRect(x + 72, y + 16, 20, 3);
      }
      // laundry / hanging clothes on balcony
      if ((f * 3 + w + seed) % 4 === 0) {
        const cloth = ["#c45c3e", "#1d4e89", "#f4f1ea", "#2f6b3a", "#222", "#d4a017"];
        g.fillStyle = cloth[(f + w) % cloth.length];
        g.fillRect(x + 4, y + 62, 16, 28);
        g.fillStyle = cloth[(f + w + 2) % cloth.length];
        g.fillRect(x + 24, y + 64, 14, 24);
        g.fillStyle = cloth[(f + w + 1) % cloth.length];
        g.fillRect(x + 42, y + 60, 12, 30);
      }
      // window dirt / reflection variation
      g.fillStyle = `rgba(20,15,10,${0.04 + (seed + f + w) % 3 * 0.02})`;
      g.fillRect(x + 4, y + 12, 56, 18);
    }
  }

  // roof water tanks / parapet details (Egyptian rooftops)
  g.fillStyle = "#8a7a68";
  g.fillRect(0, 0, 512, 18);
  for (let i = 0; i < 4; i++) {
    const tx = 40 + i * 120 + (seed % 30);
    g.fillStyle = "#c8c2b8";
    g.fillRect(tx, 8, 36, 28);
    g.fillStyle = "#9a948a";
    g.fillRect(tx + 4, 12, 28, 8);
    g.fillStyle = "#6a655c";
    g.fillRect(tx + 8, 28, 20, 6);
  }

  // commercial ground floor band
  g.fillStyle = signBands[seed % signBands.length];
  g.fillRect(0, 820, 512, 48);
  // simple Arabic-looking shop name bars
  g.fillStyle = "#f5f0e6";
  g.font = "bold 22px Tajawal, Arial";
  g.textAlign = "center";
  const shopNames = ["ميني ماركت", "مخبز", "صيدلية", "كوافير", "لحوم", "خضروات", "أدوات منزلية", "كافيه"];
  g.fillText(shopNames[seed % shopNames.length], 256, 852);

  // dark shop front
  g.fillStyle = "#161412";
  g.fillRect(0, 868, 512, 156);
  // metal shutter
  const shutter = seed % 2 === 0 ? "#1a5c42" : "#3a4650";
  g.fillStyle = shutter;
  g.fillRect(24, 880, 210, 120);
  for (let y = 880; y < 1000; y += 8) {
    g.fillStyle = "rgba(0,0,0,0.3)";
    g.fillRect(24, y, 210, 2);
  }
  // door
  g.fillStyle = "#0a0a0a";
  g.fillRect(90, 910, 70, 90);
  e.fillStyle = "#ffb15a";
  e.globalAlpha = 0.8;
  e.fillRect(100, 922, 50, 60);
  e.globalAlpha = 1;
  // goods / crates in shop window
  const goods = ["#e07a2f", "#f2c14e", "#d35400", "#8d6e63", "#27ae60", "#c0392b"];
  goods.forEach((hex, i) => {
    g.fillStyle = hex;
    g.fillRect(260 + i * 38, 900 + (i % 2) * 16, 32, 48 - (i % 2) * 10);
  });
  // extra AC units on lower floors for density
  for (let i = 0; i < 5; i++) {
    const ax = 30 + ((i * 97 + seed * 13) % 420);
    const ay = 200 + ((i * 53) % 500);
    g.fillStyle = "#e8e4dc";
    g.fillRect(ax, ay, 32, 24);
    g.fillStyle = "#a0a8b0";
    g.fillRect(ax + 3, ay + 10, 26, 5);
    g.fillStyle = "rgba(0,0,0,0.2)";
    g.fillRect(ax + 5, ay + 4, 22, 3);
  }
  // more weathering on lower walls
  for (let i = 0; i < 55; i++) {
    g.fillStyle = `rgba(30,22,15,${0.05 + (i % 5) * 0.02})`;
    g.fillRect((i * 41) % 500, 860 + (i % 8) * 12, 18 + (i % 15), 7);
  }
  // random graffiti / stickers
  for (let i = 0; i < 6; i++) {
    g.fillStyle = `rgba(${40 + (i % 3) * 30},${30 + i * 10},${20},${0.35})`;
    g.fillRect(20 + ((i * 83) % 460), 750 + (i % 4) * 20, 40 + (i % 3) * 15, 8 + (i % 2) * 4);
  }

  const map = texOf(face);
  map.anisotropy = 16;
  const emissiveMap = texOf(glow);
  return { map, emissiveMap };
}

export type BuildingKit = {
  box: THREE.BoxGeometry;
  facadeMats: THREE.MeshStandardMaterial[];
  sets: THREE.Material[][];
};

let kit: BuildingKit | null = null;

export function buildingKit(): BuildingKit {
  if (kit) return kit;
  const box = new THREE.BoxGeometry(1, 1, 1);
  const roof = new THREE.MeshStandardMaterial({ color: "#7a6e5e", roughness: 0.92, metalness: 0.05 });
  const facadeMats: THREE.MeshStandardMaterial[] = [];
  const sets: THREE.Material[][] = [];
  for (let i = 0; i < 5; i++) {
    const maps = pair(i + 1);
    const facade = new THREE.MeshStandardMaterial({
      color: "#ffffff",
      map: maps?.map,
      emissive: "#ffcc77",
      emissiveMap: maps?.emissiveMap,
      emissiveIntensity: 0,
      roughness: 0.82,
      metalness: 0.04,
    });
    facadeMats.push(facade);
    sets.push([facade, facade, roof, roof, facade, facade]);
  }
  kit = { box, facadeMats, sets };
  return kit;
}

export function asphaltTexture() {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 512;
  const g = c.getContext("2d");
  if (!g) return null;
  // base worn asphalt
  g.fillStyle = "#7a7570";
  g.fillRect(0, 0, 512, 512);
  // noise grain
  for (let i = 0; i < 3200; i++) {
    const v = 70 + ((i * 17) % 55);
    g.fillStyle = `rgba(${v},${v - 3},${v - 6},0.32)`;
    g.fillRect((i * 13) % 512, (i * 29) % 512, 2 + (i % 2), 2);
  }
  // dark oil / tire patches
  for (let i = 0; i < 28; i++) {
    g.fillStyle = `rgba(45,40,35,${0.22 + (i % 5) * 0.06})`;
    g.beginPath();
    g.ellipse(30 + ((i * 97) % 450), 25 + ((i * 61) % 460), 35 + (i % 6) * 14, 12 + (i % 4) * 8, i * 0.4, 0, Math.PI * 2);
    g.fill();
  }
  // faded lane marks
  g.strokeStyle = "rgba(200,190,160,0.18)";
  g.lineWidth = 3;
  for (let i = 0; i < 9; i++) {
    g.beginPath();
    g.moveTo((i * 55) % 512, 0);
    g.lineTo(((i * 55) % 512) + 25, 512);
    g.stroke();
  }
  // repair patches (lighter / darker rectangles)
  for (let i = 0; i < 12; i++) {
    const x = (i * 137) % 420;
    const y = (i * 89) % 430;
    g.fillStyle = i % 2 === 0 ? "rgba(95,90,82,0.55)" : "rgba(55,50,45,0.5)";
    g.fillRect(x, y, 55 + (i % 4) * 20, 28 + (i % 3) * 12);
  }
  // small pothole-ish dark spots
  for (let i = 0; i < 9; i++) {
    g.fillStyle = "rgba(30,28,25,0.65)";
    g.beginPath();
    g.ellipse(80 + ((i * 53) % 350), 60 + ((i * 71) % 380), 8 + (i % 3) * 4, 5 + (i % 2) * 3, 0, 0, Math.PI * 2);
    g.fill();
  }
  const map = texOf(c);
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  return map;
}

export function sidewalkTexture() {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 256;
  const g = c.getContext("2d");
  if (!g) return null;
  g.fillStyle = "#b8aa96";
  g.fillRect(0, 0, 256, 256);
  // broken tiles
  g.strokeStyle = "rgba(70,58,45,0.45)";
  g.lineWidth = 2;
  for (let y = 0; y < 256; y += 64) {
    for (let x = 0; x < 256; x += 64) {
      g.strokeRect(x + 1, y + 1, 62, 62);
      if ((x + y) % 128 === 0) {
        g.fillStyle = "rgba(80,65,48,0.22)";
        g.fillRect(x + 6, y + 6, 52, 52);
      }
      // cracks
      if ((x * y) % 3 === 0) {
        g.strokeStyle = "rgba(50,40,30,0.35)";
        g.beginPath();
        g.moveTo(x + 10, y + 15);
        g.lineTo(x + 45, y + 50);
        g.stroke();
      }
    }
  }
  // dirt patches
  for (let i = 0; i < 18; i++) {
    g.fillStyle = `rgba(90,75,55,${0.15 + (i % 4) * 0.05})`;
    g.beginPath();
    g.ellipse((i * 47) % 240, (i * 73) % 240, 12 + (i % 4) * 6, 8 + (i % 3) * 4, 0, 0, Math.PI * 2);
    g.fill();
  }
  const map = texOf(c);
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  return map;
}

export function bumpTexture() {
  const c = document.createElement("canvas");
  c.width = 128;
  c.height = 32;
  const g = c.getContext("2d");
  if (!g) return null;
  for (let x = 0; x < 128; x += 16) {
    g.fillStyle = (x / 16) % 2 === 0 ? "#f0b429" : "#161616";
    g.fillRect(x, 0, 16, 32);
  }
  const map = texOf(c);
  map.wrapS = THREE.RepeatWrapping;
  map.repeat.set(8, 1);
  return map;
}

function stamp(list: THREE.Matrix4[], o: THREE.Object3D) {
  o.updateMatrix();
  list.push(o.matrix.clone());
}

function addInstances(
  scene: THREE.Scene,
  geo: THREE.BufferGeometry,
  mat: THREE.Material,
  mats: THREE.Matrix4[],
  colors?: THREE.Color[],
) {
  if (!mats.length) return;
  const mesh = new THREE.InstancedMesh(geo, mat, mats.length);
  mesh.frustumCulled = false;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  mats.forEach((m, i) => mesh.setMatrixAt(i, m));
  mesh.instanceMatrix.needsUpdate = true;
  if (colors) {
    colors.forEach((c, i) => mesh.setColorAt(i, c));
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }
  scene.add(mesh);
}

function sideOf(p: { x: number; z: number; yaw: number }, lat: number, y: number) {
  const rx = Math.cos(p.yaw);
  const rz = -Math.sin(p.yaw);
  return { x: p.x + rx * lat, y, z: p.z + rz * lat };
}

export function dressFayoum(scene: THREE.Scene, track: Track) {
  const kit = buildingKit();
  const dummy = new THREE.Object3D();
  const pts = track.pts;

  const scatter = (lateral: number, cap: number) => {
    const meshes = kit.sets.map((mats) => {
      const mesh = new THREE.InstancedMesh(kit.box, mats, cap);
      mesh.count = 0;
      mesh.frustumCulled = false;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      scene.add(mesh);
      return mesh;
    });
    const counts = kit.sets.map(() => 0);
    return { meshes, counts };
  };

  const outer = scatter(0, 110);
  const median = scatter(0, 90);

  const awnings: THREE.Matrix4[] = [];
  const awningCols: THREE.Color[] = [];
  const crates: THREE.Matrix4[] = [];
  const crateCols: THREE.Color[] = [];
  const bikes: THREE.Matrix4[] = [];
  const dishes: THREE.Matrix4[] = [];
  const acs: THREE.Matrix4[] = [];
  const laundry: THREE.Matrix4[] = [];
  const laundryCols: THREE.Color[] = [];
  const holes: THREE.Matrix4[] = [];
  const wires: number[] = [];

  const cloth = ["#c45c3e", "#1aa6a6", "#f0b429", "#1f6b4a", "#24527e", "#f4f1ea"].map((h) => new THREE.Color(h));
  const woods = ["#c9842a", "#a86b32", "#d35400", "#e6c27a"].map((h) => new THREE.Color(h));
  const o = new THREE.Object3D();

  for (let i = 0; i < pts.length; i += 4) {
    const p = pts[i];
    const nxt = pts[(i + 8) % pts.length];
    const bend = Math.abs(((nxt.yaw - p.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
    if (bend > 0.22) continue;
    const hsh = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1;
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    for (const side of [-1, 1]) {
      const idx = (i + (side > 0 ? 1 : 0)) % 5;
      if (outer.counts[idx] < 95 && i % 5 === 0) {
        const floors = 3 + Math.floor(hsh * 5);
        const height = floors * 2.75 + (hsh > 0.7 ? 1.2 : 0);
        const depth = 8.5 + hsh * 3.5;
        const width = 5.4 + (1 - hsh) * 2.2;
        dummy.position.set(p.x + rx * side * (ROAD_HALF + 7.2 + hsh * 0.8), height / 2, p.z + rz * side * (ROAD_HALF + 7.2 + hsh * 0.8));
        dummy.rotation.set(0, p.yaw + (hsh - 0.5) * 0.08, 0);
        dummy.scale.set(width, height, depth);
        dummy.updateMatrix();
        outer.meshes[idx].setMatrixAt(outer.counts[idx]++, dummy.matrix);
      }
      if (i % 8 === 0) {
        const at = sideOf(p, side * (ROAD_HALF + 2.3), 2.85);
        o.position.set(at.x, at.y, at.z);
        o.rotation.set(0, p.yaw, 0);
        o.scale.set(3.6, 0.08, 2.4);
        stamp(awnings, o);
        awningCols.push(cloth[(i + side) & 5]);
      }
      if (i % 4 === 0) {
        const at = sideOf(p, side * (ROAD_HALF + 1.55), 0.28);
        o.position.set(at.x, 0.28, at.z);
        o.rotation.set(0, p.yaw + (hsh - 0.5) * 0.4, 0);
        o.scale.set(0.65 + hsh * 0.45, 0.5 + hsh * 0.2, 0.5 + hsh * 0.25);
        stamp(crates, o);
        crateCols.push(woods[(i + side) & 3]);
        // stack second crate sometimes
        if (hsh > 0.6) {
          o.position.y = 0.7;
          o.scale.set(0.55, 0.45, 0.5);
          stamp(crates, o);
          crateCols.push(woods[(i + 1) & 3]);
        }
      }
      if (i % 16 === 4) {
        const at = sideOf(p, side * (ROAD_HALF + 0.85), 0.42);
        o.position.set(at.x, 0.42, at.z);
        o.rotation.set(0, p.yaw + 0.4, 0);
        o.scale.set(1, 1, 1);
        stamp(bikes, o);
      }
      if (hsh > 0.55 && i % 8 === 0) {
        const at = sideOf(p, side * 16.5, 8 + hsh * 6);
        o.position.set(at.x, at.y, at.z);
        o.rotation.set(0.9, p.yaw, 0);
        o.scale.set(1, 1, 1);
        stamp(dishes, o);
      }
      if (i % 6 === 2 || i % 6 === 5) {
        const at = sideOf(p, side * 12.4, 3.8 + (i % 4) * 0.9);
        o.position.set(at.x, at.y, at.z);
        o.rotation.set(0, p.yaw, 0);
        o.scale.set(0.42, 0.32, 0.28);
        stamp(acs, o);
        // laundry lines hanging
        const line = sideOf(p, side * 12.15, at.y - 0.55);
        o.position.set(line.x, line.y, line.z);
        o.scale.set(0.07, 0.65 + hsh * 0.3, 0.4);
        stamp(laundry, o);
        laundryCols.push(cloth[(i + 2) % cloth.length]);
        if (hsh > 0.45) {
          o.position.y -= 0.35;
          o.scale.set(0.06, 0.5, 0.32);
          stamp(laundry, o);
          laundryCols.push(cloth[(i + 4) % cloth.length]);
        }
      }
    }
    if (Math.abs(p.x) > 30 && Math.abs(p.z) < 280 && i % 8 === 0) {
      const idx = i % 5;
      if (median.counts[idx] < 70) {
        const toward = Math.sign(p.x) || 1;
        const floors = 5 + Math.floor(hsh * 3);
        const height = floors * 2.9;
        dummy.position.set(p.x - toward * 20, height / 2, p.z);
        dummy.rotation.set(0, p.yaw, 0);
        dummy.scale.set(7.2, height, 11);
        dummy.updateMatrix();
        median.meshes[idx].setMatrixAt(median.counts[idx]++, dummy.matrix);
      }
    }
    if (i % 18 === 0) {
      o.position.set(p.x, 0.03, p.z);
      o.rotation.set(0, p.yaw, 0);
      o.scale.set(1, 1, 1);
      stamp(holes, o);
    }
  }

  outer.meshes.forEach((m, i) => {
    m.count = outer.counts[i];
    m.instanceMatrix.needsUpdate = true;
  });
  median.meshes.forEach((m, i) => {
    m.count = median.counts[i];
    m.instanceMatrix.needsUpdate = true;
  });

  const awningMat = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.7 });
  addInstances(scene, new THREE.BoxGeometry(1, 1, 1), awningMat, awnings, awningCols);
  const crateMat = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.86 });
  addInstances(scene, new THREE.BoxGeometry(1, 1, 1), crateMat, crates, crateCols);
  const bikeGeo = new THREE.BoxGeometry(0.35, 0.7, 1.5);
  bikeGeo.translate(0, 0.45, 0);
  addInstances(
    scene,
    bikeGeo,
    new THREE.MeshStandardMaterial({ color: "#1b1e24", roughness: 0.6, metalness: 0.2 }),
    bikes,
  );
  const dishGeo = new THREE.SphereGeometry(0.55, 8, 6);
  dishGeo.scale(1, 0.28, 1);
  addInstances(
    scene,
    dishGeo,
    new THREE.MeshStandardMaterial({ color: "#d5d8dc", roughness: 0.4, metalness: 0.45 }),
    dishes,
  );
  addInstances(
    scene,
    new THREE.BoxGeometry(1, 1, 1),
    new THREE.MeshStandardMaterial({ color: "#f4f1ea", roughness: 0.5 }),
    acs,
  );
  const clothMat = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.8 });
  addInstances(scene, new THREE.BoxGeometry(1, 1, 1), clothMat, laundry, laundryCols);
  const holeGeo = new THREE.CircleGeometry(0.42, 8);
  holeGeo.rotateX(-Math.PI / 2);
  addInstances(
    scene,
    holeGeo,
    new THREE.MeshStandardMaterial({ color: "#2a2928", roughness: 0.7, metalness: 0.25 }),
    holes,
  );

  for (let i = 0; i < pts.length; i += 8) {
    const a = pts[i];
    const b = pts[(i + 8) % pts.length];
    if (Math.abs(a.x) < 20 || Math.abs(b.x) < 20) continue;
    const ra = Math.cos(a.yaw);
    const rza = -Math.sin(a.yaw);
    const rb = Math.cos(b.yaw);
    const rzb = -Math.sin(b.yaw);
    const ax = a.x + ra * 11.2;
    const az = a.z + rza * 11.2;
    const bx = b.x + rb * 11.2;
    const bz = b.z + rzb * 11.2;
    const sag = 0.55;
    wires.push(ax, 6.15, az, (ax + bx) / 2, 6.15 - sag, (az + bz) / 2);
    wires.push((ax + bx) / 2, 6.15 - sag, (az + bz) / 2, bx, 6.15, bz);
  }
  if (wires.length) {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(wires, 3));
    scene.add(new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: "#2c3036" })));
  }

  // Dense, instanced architectural depth on the actual street-facing building shells.
  // This replaces a handful of isolated detail groups with reusable geometry so the
  // majority of the visible frontage gets balconies, rails, AC units, pipes and tanks.
  const trimMat = new THREE.MeshStandardMaterial({ color: "#aaa092", roughness: 0.94 });
  const ironMat = new THREE.MeshStandardMaterial({ color: "#343a3e", roughness: 0.58, metalness: 0.32 });
  const pipeMat = new THREE.MeshStandardMaterial({ color: "#77736b", roughness: 0.72, metalness: 0.18 });
  const acMat = new THREE.MeshStandardMaterial({ color: "#c8c9c3", roughness: 0.68, metalness: 0.08 });
  const tankMat = new THREE.MeshStandardMaterial({ color: "#b9b9b2", roughness: 0.7, metalness: 0.06 });
  const awningMats = ["#b83c32", "#e5d5b5", "#176b56", "#d6a52d", "#315b78"].map(
    (color) => new THREE.MeshStandardMaterial({ color, roughness: 0.86 }),
  );
  const slabMatrices: THREE.Matrix4[] = [];
  const railMatrices: THREE.Matrix4[] = [];
  const postMatrices: THREE.Matrix4[] = [];
  const pipeMatrices: THREE.Matrix4[] = [];
  const acMatrices: THREE.Matrix4[] = [];
  const tankMatrices: THREE.Matrix4[] = [];
  const canopyBuckets = awningMats.map(() => [] as THREE.Matrix4[]);
  const detail = new THREE.Object3D();
  const put = (list: THREE.Matrix4[], x: number, y: number, z: number, sx: number, sy: number, sz: number, yaw: number) => {
    detail.position.set(x, y, z);
    detail.rotation.set(0, yaw, 0);
    detail.scale.set(sx, sy, sz);
    detail.updateMatrix();
    list.push(detail.matrix.clone());
  };

  // Track samples are ~5 m apart. Every 20 samples gives dense frontage without
  // creating a separate draw call for every balcony component.
  for (let i = 0; i < pts.length; i += 20) {
    const p = pts[i];
    const next = pts[(i + 8) % pts.length];
    const bend = Math.abs(((next.yaw - p.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
    if (bend > 0.22) continue;
    const hsh = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1;
    const floors = 3 + Math.floor(hsh * 5);
    const height = floors * 2.75 + (hsh > 0.7 ? 1.2 : 0);
    const depth = 8.5 + hsh * 3.5;
    const width = 5.4 + (1 - hsh) * 2.2;
    for (const side of [-1, 1]) {
      const cx = p.x + Math.cos(p.yaw) * side * (ROAD_HALF + 7.2 + hsh * 0.8);
      const cz = p.z - Math.sin(p.yaw) * side * (ROAD_HALF + 7.2 + hsh * 0.8);
      const fx = side * (width / 2 + 0.08);
      for (let floor = 1; floor < floors; floor++) {
        if ((floor + i) % 4 === 0) continue;
        const y = floor * 2.75 - 0.12;
        put(slabMatrices, cx + Math.cos(p.yaw) * (fx + side * 0.18), y,
          cz - Math.sin(p.yaw) * (fx + side * 0.18), 0.62, 0.16, depth * 0.72, p.yaw);
        for (let n = 0; n <= 8; n++) {
          const zLocal = -depth * 0.35 + depth * 0.7 * n / 8;
          put(postMatrices, cx + Math.cos(p.yaw) * (fx + side * 0.5) + Math.sin(p.yaw) * zLocal,
            y + 0.46, cz - Math.sin(p.yaw) * (fx + side * 0.5) + Math.cos(p.yaw) * zLocal,
            0.055, 0.72, 0.055, p.yaw);
        }
        put(railMatrices, cx + Math.cos(p.yaw) * (fx + side * 0.5), y + 0.84,
          cz - Math.sin(p.yaw) * (fx + side * 0.5), 0.08, 0.07, depth * 0.72, p.yaw);
        if ((floor + i) % 2 === 0) {
          const zLocal = (floor % 2 ? -1 : 1) * depth * 0.22;
          put(acMatrices, cx + Math.cos(p.yaw) * (fx + side * 0.22) + Math.sin(p.yaw) * zLocal,
            y + 1.25, cz - Math.sin(p.yaw) * (fx + side * 0.22) + Math.cos(p.yaw) * zLocal,
            0.52, 0.34, 0.38, p.yaw);
        }
      }
      for (const zLocal of [-depth * 0.43, depth * 0.43]) {
        put(pipeMatrices, cx + Math.cos(p.yaw) * (fx + side * 0.12) + Math.sin(p.yaw) * zLocal,
          height / 2, cz - Math.sin(p.yaw) * (fx + side * 0.12) + Math.cos(p.yaw) * zLocal,
          0.075, height, 0.075, p.yaw);
      }
      const awningIndex = (i + (side > 0 ? 1 : 0)) % awningMats.length;
      put(canopyBuckets[awningIndex], cx + Math.cos(p.yaw) * (fx + side * 0.58), 3.08,
        cz - Math.sin(p.yaw) * (fx + side * 0.58), 0.95, 0.14, depth * 0.78, p.yaw);
      for (const zLocal of [-depth * 0.34, depth * 0.34]) {
        put(postMatrices, cx + Math.cos(p.yaw) * (fx + side * 0.92) + Math.sin(p.yaw) * zLocal,
          2.55, cz - Math.sin(p.yaw) * (fx + side * 0.92) + Math.cos(p.yaw) * zLocal,
          0.045, 1.05, 0.045, p.yaw);
      }
      put(tankMatrices, cx + Math.cos(p.yaw) * side * width * 0.12 + Math.sin(p.yaw) * depth * 0.18,
        height + 0.62, cz - Math.sin(p.yaw) * side * width * 0.12 + Math.cos(p.yaw) * depth * 0.18,
        1.24, 1.25, 1.24, p.yaw);
    }
  }
  addInstances(scene, new THREE.BoxGeometry(1, 1, 1), trimMat, slabMatrices);
  addInstances(scene, new THREE.BoxGeometry(1, 1, 1), ironMat, railMatrices);
  addInstances(scene, new THREE.BoxGeometry(1, 1, 1), ironMat, postMatrices);
  addInstances(scene, new THREE.BoxGeometry(1, 1, 1), pipeMat, pipeMatrices);
  addInstances(scene, new THREE.BoxGeometry(1, 1, 1), acMat, acMatrices);
  const tankGeo = new THREE.CylinderGeometry(0.5, 0.54, 1, 12);
  addInstances(scene, tankGeo, tankMat, tankMatrices);
  canopyBuckets.forEach((matrices, i) => {
    addInstances(scene, new THREE.BoxGeometry(1, 1, 1), awningMats[i], matrices);
  });

}

const SHOPS = [
  { name: "سوبر ماركت", sub: "دار السلام", bg: "#0e6b3c", fg: "#ffffff" },
  { name: "صيدلية", sub: "خدمة يومية", bg: "#c0392b", fg: "#ffffff" },
  { name: "موبايلات", sub: "صيانة وشحن", bg: "#1a365d", fg: "#f0b429" },
  { name: "خضار وفاكهة", sub: "شارع الفيوم", bg: "#1e8449", fg: "#ffffff" },
  { name: "ملابس", sub: "جملة وقطاعي", bg: "#6c3483", fg: "#ffffff" },
  { name: "سنتر دروس", sub: "كل المراحل", bg: "#1a5276", fg: "#f6f1e7" },
  { name: "مخبز بلدي", sub: "عيش سخن", bg: "#b9770e", fg: "#1c1406" },
  { name: "قهوة", sub: "شاي · قهوة", bg: "#6e2c00", fg: "#f6f1e7" },
  { name: "مكتب بريد", sub: "دار السلام", bg: "#0b5ea8", fg: "#ffffff" },
  { name: "مكتبة", sub: "كتب وملازم", bg: "#5d4e37", fg: "#f6f1e7" },
  { name: "كوافير", sub: "حلاقة وتجميل", bg: "#8e44ad", fg: "#ffffff" },
  { name: "أدوات منزلية", sub: "جملة", bg: "#16a085", fg: "#ffffff" },
  { name: "لحوم ودواجن", sub: "طازج يومياً", bg: "#922b21", fg: "#f6f1e7" },
  { name: "محل حلويات", sub: "شرقي وغربي", bg: "#b9770e", fg: "#1c1406" },
  { name: "كهرباء وسباكة", sub: "صيانة", bg: "#1c2833", fg: "#f0b429" },
];

function shopTex(name: string, sub: string, bg: string, fg: string) {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 160;
  const g = c.getContext("2d");
  if (!g) return null;
  g.fillStyle = bg;
  g.fillRect(0, 0, 512, 160);
  g.fillStyle = fg;
  g.fillRect(0, 0, 512, 8);
  g.direction = "rtl";
  g.textAlign = "center";
  g.fillStyle = fg;
  g.font = "800 64px Tajawal, 'DejaVu Sans', sans-serif";
  g.fillText(name, 256, 78);
  g.font = "500 32px Tajawal, 'DejaVu Sans', sans-serif";
  g.globalAlpha = 0.85;
  g.fillText(sub, 256, 128);
  return texOf(c);
}

export function placeShopSigns(scene: THREE.Scene, track: Track) {
  const buckets = SHOPS.map(() => [] as THREE.Matrix4[]);
  const o = new THREE.Object3D();
  const pts = track.pts;
  for (let i = 4; i < pts.length; i += 4) {
    const p = pts[i];
    const nxt = pts[(i + 6) % pts.length];
    const bend = Math.abs(((nxt.yaw - p.yaw + Math.PI * 3) % (Math.PI * 2)) - Math.PI);
    if (bend > 0.2) continue;
    const side = i % 10 < 5 ? 1 : -1;
    const at = sideOf(p, side * 11.6, 3.55);
    o.position.set(at.x, at.y, at.z);
    o.rotation.set(0, p.yaw, 0);
    o.scale.set(1, 1, 1);
    o.updateMatrix();
    buckets[i % SHOPS.length].push(o.matrix.clone());
  }
  SHOPS.forEach((shop, i) => {
    const map = shopTex(shop.name, shop.sub, shop.bg, shop.fg);
    if (!map || !buckets[i].length) return;
    const mat = new THREE.MeshStandardMaterial({ map, roughness: 0.65, side: THREE.DoubleSide });
    addInstances(scene, new THREE.PlaneGeometry(4.4, 1.35), mat, buckets[i]);
  });
}

function flagTex() {
  const c = document.createElement("canvas");
  c.width = 96;
  c.height = 64;
  const g = c.getContext("2d");
  if (!g) return null;
  g.fillStyle = "#ce1126";
  g.fillRect(0, 0, 96, 21);
  g.fillStyle = "#ffffff";
  g.fillRect(0, 21, 96, 22);
  g.fillStyle = "#111111";
  g.fillRect(0, 43, 96, 21);
  g.fillStyle = "#c5a15a";
  g.beginPath();
  g.arc(48, 32, 8, 0, Math.PI * 2);
  g.fill();
  return texOf(c);
}

export function buildLandmarks(scene: THREE.Scene, track: Track) {
  const stone = new THREE.MeshStandardMaterial({ color: "#e7dcc8", roughness: 0.9 });
  const concrete = new THREE.MeshStandardMaterial({ color: "#b7b1a8", roughness: 0.84 });
  const yellow = new THREE.MeshStandardMaterial({ color: "#e6c56a", roughness: 0.62 });
  const white = new THREE.MeshStandardMaterial({ color: "#f4f0e6", roughness: 0.7 });
  const green = new THREE.MeshStandardMaterial({ color: "#1f6b4a", roughness: 0.55 });
  const red = new THREE.MeshStandardMaterial({ color: "#b3392b", roughness: 0.6 });
  const teal = new THREE.MeshStandardMaterial({ color: "#1a7a78", roughness: 0.55 });
  const dark = new THREE.MeshStandardMaterial({ color: "#2a3138", roughness: 0.5, metalness: 0.2 });
  const flagMat = new THREE.MeshStandardMaterial({ map: flagTex() ?? undefined, roughness: 0.6, side: THREE.DoubleSide });

  const spot = (dist: number, lat: number) => {
    const sm = track.sample(dist);
    const rx = Math.cos(sm.yaw);
    const rz = -Math.sin(sm.yaw);
    return { x: sm.x + rx * lat, z: sm.z + rz * lat, yaw: sm.yaw };
  };
  const put = (index: number, lat: number, build: (g: THREE.Group) => void) => {
    const p = spot(track.stops[index].s, lat);
    const g = new THREE.Group();
    g.position.set(p.x, 0, p.z);
    g.rotation.y = p.yaw;
    build(g);
    scene.add(g);
  };

  put(0, 0, (g) => {
    const deck = new THREE.Mesh(new THREE.BoxGeometry(30, 0.5, 9), concrete);
    deck.position.y = 6.3;
    const railL = new THREE.Mesh(new THREE.BoxGeometry(30, 0.85, 0.16), dark);
    railL.position.set(0, 6.9, 4.2);
    const railR = railL.clone();
    railR.position.z = -4.2;
    for (const x of [-13, 13]) {
      for (const z of [-3.2, 3.2]) {
        const col = new THREE.Mesh(new THREE.BoxGeometry(0.85, 6.3, 0.85), concrete);
        col.position.set(x, 3.15, z);
        g.add(col);
      }
    }
    ["#f4f1ea", "#c0392b", "#1a365d", "#f0b429", "#2c3e50", "#95a5a6", "#e6c27a"].forEach((hex, i) => {
      const car = new THREE.Mesh(
        new THREE.BoxGeometry(1.65, 1.2, 3.6),
        new THREE.MeshStandardMaterial({ color: hex, roughness: 0.5 }),
      );
      car.position.set(-9.2 + i * 3.05, 7.15, i % 2 === 0 ? 1.6 : -1.6);
      g.add(car);
    });
    g.add(deck, railL, railR);
  });

  put(0, 18.5, (g) => {
    ["#f7f7f4", "#e7e4dc", "#d5dde2", "#f4f1ea"].forEach((hex, i) => {
      const bus = new THREE.Mesh(
        new THREE.BoxGeometry(2.05, 2.15, 4.8),
        new THREE.MeshStandardMaterial({ color: hex, roughness: 0.55 }),
      );
      bus.position.set((i % 2) * 2.4, 1.15, (i - 1.5) * 5.6);
      const glass = new THREE.Mesh(
        new THREE.BoxGeometry(1.9, 0.45, 1.3),
        new THREE.MeshStandardMaterial({ color: "#9fd0d8", roughness: 0.15, metalness: 0.2 }),
      );
      glass.position.set((i % 2) * 2.4, 1.85, (i - 1.5) * 5.6 - 1.4);
      g.add(bus, glass);
    });
  });

  // Dar El Salam metro entrance: stairs, ticket hall and red line fascia.
  put(1, 13.2, (g) => {
    g.rotation.y += Math.PI / 2;
    const hall = new THREE.Mesh(new THREE.BoxGeometry(8.5, 3.1, 5.2), white);
    hall.position.set(0, 1.55, -1.2);
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(9.2, 0.24, 5.8), red);
    canopy.position.set(0, 3.2, -1.2);
    const stairMat = new THREE.MeshStandardMaterial({ color: "#9c9b96", roughness: 0.88 });
    for (let k = 0; k < 7; k++) {
      const step = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.16, 0.48), stairMat);
      step.position.set(0, 0.12 + k * 0.16, 1.0 + k * 0.48);
      g.add(step);
    }
    const signMap = shopTex("محطة مترو دار السلام", "الخط الأول", "#a52b2b", "#ffffff");
    if (signMap) {
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(7.4, 1.25), new THREE.MeshStandardMaterial({ map: signMap, side: THREE.DoubleSide }));
      sign.position.set(0, 3.9, 1.55);
      g.add(sign);
    }
    g.add(hall, canopy);
  });

  // Health office: low public-service building with a visible red cross.
  put(2, 13.2, (g) => {
    g.rotation.y += Math.PI / 2;
    const block = new THREE.Mesh(new THREE.BoxGeometry(12, 6.2, 8), stone);
    block.position.set(0, 3.1, -0.5);
    const fascia = new THREE.Mesh(new THREE.BoxGeometry(12.15, 0.72, 8.12), green);
    fascia.position.set(0, 5.25, -0.5);
    const door = new THREE.Mesh(new THREE.BoxGeometry(1.5, 2.8, 0.18), dark);
    door.position.set(0, 1.4, 3.58);
    const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.34, 1.2, 0.12), white);
    crossV.position.set(-4.4, 4.35, 3.62);
    const crossH = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.34, 0.12), white);
    crossH.position.set(-4.4, 4.35, 3.62);
    for (const x of [-2.8, 2.8]) {
      const win = new THREE.Mesh(new THREE.BoxGeometry(1.45, 1.35, 0.12), teal);
      win.position.set(x, 3.2, 3.62);
      g.add(win);
    }
    g.add(block, fascia, door, crossV, crossH);
  });

  // Main telephone exchange: wider civic facade, rooftop aerials and a WE sign.
  put(3, 13.4, (g) => {
    g.rotation.y += Math.PI / 2;
    const block = new THREE.Mesh(new THREE.BoxGeometry(15, 10, 9), concrete);
    block.position.y = 5;
    const band = new THREE.Mesh(new THREE.BoxGeometry(15.2, 1.05, 9.2), teal);
    band.position.set(0, 7.5, 0);
    const entry = new THREE.Mesh(new THREE.BoxGeometry(2.1, 3.2, 0.2), dark);
    entry.position.set(0, 1.6, 4.58);
    for (const x of [-5.2, -2.6, 2.6, 5.2]) {
      const win = new THREE.Mesh(new THREE.BoxGeometry(1.45, 1.65, 0.14), white);
      win.position.set(x, 4.4, 4.6);
      g.add(win);
    }
    const aerial = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 4.8, 7), dark);
    aerial.position.set(5.7, 12.4, -2.4);
    const dish = new THREE.Mesh(new THREE.SphereGeometry(1.05, 10, 8), white);
    dish.scale.set(1, 0.22, 1);
    dish.position.set(-4.8, 10.9, -2.4);
    const signMap = shopTex("WE", "سنترال دار السلام", "#5b2c83", "#ffffff");
    if (signMap) {
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(5.2, 1.5), new THREE.MeshStandardMaterial({ map: signMap, side: THREE.DoubleSide }));
      sign.position.set(0, 8.2, 4.66);
      g.add(sign);
    }
    g.add(block, band, entry, aerial, dish);
  });

  put(5, 13.4, (g) => {
    g.rotation.y += Math.PI / 2;
    const wall = new THREE.Mesh(new THREE.BoxGeometry(22, 3.2, 0.4), yellow);
    wall.position.set(0, 1.6, -2);
    const school = new THREE.Mesh(new THREE.BoxGeometry(16, 7, 8), yellow);
    school.position.set(0, 3.5, -6);
    const gate = new THREE.Mesh(new THREE.BoxGeometry(3.2, 2.6, 0.3), dark);
    gate.position.set(0, 1.3, -1.8);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 5, 6), dark);
    pole.position.set(6, 5.2, -1.5);
    const flag = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 1.1), flagMat);
    flag.position.set(7.1, 7.1, -1.5);
    g.add(wall, school, gate, pole, flag);
  });

  put(6, 13.6, (g) => {
    g.rotation.y += Math.PI / 2;
    const school = new THREE.Mesh(new THREE.BoxGeometry(14, 6.5, 7), yellow);
    school.position.y = 3.25;
    const band = new THREE.Mesh(new THREE.BoxGeometry(14.2, 0.35, 7.2), green);
    band.position.y = 5.4;
    const gate = new THREE.Mesh(new THREE.BoxGeometry(2.4, 2.4, 0.25), dark);
    gate.position.set(0, 1.2, 3.6);
    g.add(school, band, gate);
  });

  put(4, 12.2, (g) => {
    g.rotation.y += Math.PI / 2;
    const block = new THREE.Mesh(new THREE.BoxGeometry(13, 8.5, 8.5), stone);
    block.position.set(0, 4.25, -0.4);
    const band = new THREE.Mesh(new THREE.BoxGeometry(13.2, 0.85, 8.7), new THREE.MeshStandardMaterial({ color: "#174c78", roughness: 0.65 }));
    band.position.set(0, 6.8, -0.4);
    const entrance = new THREE.Mesh(new THREE.BoxGeometry(1.8, 3.1, 0.18), dark);
    entrance.position.set(0, 1.55, 3.92);
    for (const x of [-4.5, -2.4, 2.4, 4.5]) {
      for (const y of [3.1, 5.5]) {
        const win = new THREE.Mesh(new THREE.BoxGeometry(1.25, 1.05, 0.12), teal);
        win.position.set(x, y, 3.95);
        g.add(win);
      }
    }
    const signMap = shopTex("الإدارة التعليمية", "دار السلام", "#174c78", "#ffffff");
    if (signMap) {
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(7.2, 1.4), new THREE.MeshStandardMaterial({ map: signMap, side: THREE.DoubleSide }));
      sign.position.set(0, 7.45, 4.05);
      g.add(sign);
    }
    g.add(block, band, entrance);
  });

  put(8, 12.4, (g) => {
    g.rotation.y += Math.PI / 2;
    const post = new THREE.Mesh(new THREE.BoxGeometry(8, 4.2, 5), yellow);
    post.position.y = 2.1;
    const band = new THREE.Mesh(new THREE.BoxGeometry(8.1, 0.7, 5.1), teal);
    band.position.y = 3.5;
    g.add(post, band);
  });


  {
    const p = spot(track.gasS, 11.2);
    const g = new THREE.Group();
    g.position.set(p.x, 0, p.z);
    g.rotation.y = p.yaw;
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.22, 5.4), red);
    canopy.position.y = 3.6;
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(7.2, 0.12, 1.1), white);
    stripe.position.y = 3.48;
    [-3, 3].forEach((x) => {
      const col = new THREE.Mesh(new THREE.BoxGeometry(0.28, 3.5, 0.28), white);
      col.position.set(x, 1.75, -2);
      g.add(col);
    });
    const pump = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.45, 0.35), dark);
    pump.position.set(0, 0.75, 0.2);
    g.add(canopy, stripe, pump);
    scene.add(g);
  }


  // Grounded wayfinding for the documented Fayoum Street landmarks.
  const landmarkLabel = (index: number, lat: number, title: string, sub: string, bg: string, width = 5.8) => {
    const p = spot(track.stops[index].s, lat);
    const map = shopTex(title, sub, bg, "#ffffff");
    if (!map) return;
    const sign = new THREE.Mesh(
      new THREE.PlaneGeometry(width, 1.55),
      new THREE.MeshStandardMaterial({ map, roughness: 0.7, side: THREE.DoubleSide }),
    );
    sign.position.set(p.x, 4.15, p.z);
    sign.rotation.y = p.yaw;
    scene.add(sign);
  };
  landmarkLabel(1, 12.8, "محطة مترو دار السلام", "الخط الأول", "#a52b2b", 6.6);
  landmarkLabel(2, 12.8, "مكتب صحة دار السلام", "خدمات المواطنين", "#176b56", 5.8);
  landmarkLabel(3, 12.8, "سنترال دار السلام", "الشبكة الرئيسية", "#174c78", 5.8);
  landmarkLabel(4, 12.8, "الإدارة التعليمية", "دار السلام", "#5d4037", 5.8);
  landmarkLabel(5, 13.8, "مجمع مدارس شارع الفيوم", "مدرسة جمال عبد الناصر", "#174c78", 7.2);
  landmarkLabel(6, 13.8, "مدرسة جمال عبد الناصر", "مدرسة ثانوية بنات", "#174c78", 6.2);
  landmarkLabel(8, 13.4, "سوق الخضار", "خلف المدرسة المعمارية", "#1e8449", 5.8);
  landmarkLabel(9, 13.0, "منطقة الملاءة", "نهاية شارع الفيوم", "#5d4037", 5.8);

  // Produce market cluster behind the architecture school: striped canopies, poles and crates.
  {
    const roofMats = ["#1e8449", "#f0b429", "#c0392b", "#f4f1e7"].map(
      (color) => new THREE.MeshStandardMaterial({ color, roughness: 0.82, side: THREE.DoubleSide }),
    );
    const poleMat = new THREE.MeshStandardMaterial({ color: "#55504a", roughness: 0.8, metalness: 0.15 });
    const crateMats = ["#a86b32", "#c9842a", "#8e5a2b"].map(
      (color) => new THREE.MeshStandardMaterial({ color, roughness: 0.9 }),
    );
    const fruitMats = ["#c0392b", "#e67e22", "#2f6b3a", "#f4d03f"].map(
      (color) => new THREE.MeshStandardMaterial({ color, roughness: 0.72 }),
    );
    for (let k = 0; k < 5; k++) {
      const p = track.sample(track.stops[8].s + (k - 2) * 4.2);
      const rx = Math.cos(p.yaw);
      const rz = -Math.sin(p.yaw);
      const cx = p.x + rx * 15.2;
      const cz = p.z + rz * 15.2;
      const stall = new THREE.Group();
      stall.position.set(cx, 0, cz);
      stall.rotation.y = p.yaw;
      const roof = new THREE.Mesh(new THREE.BoxGeometry(3.8, 0.16, 2.8), roofMats[k % roofMats.length]);
      roof.position.y = 2.65;
      stall.add(roof);
      for (const x of [-1.72, 1.72]) {
        for (const z of [-1.2, 1.2]) {
          const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.06, 2.65, 6), poleMat);
          pole.position.set(x, 1.32, z);
          stall.add(pole);
        }
      }
      for (let c = 0; c < 3; c++) {
        const crate = new THREE.Mesh(new THREE.BoxGeometry(0.82, 0.52, 0.7), crateMats[(k + c) % crateMats.length]);
        crate.position.set(-1.0 + c * 1.0, 0.38, 1.05);
        stall.add(crate);
        const fruit = new THREE.Mesh(new THREE.SphereGeometry(0.19, 7, 6), fruitMats[(k + c) % fruitMats.length]);
        fruit.position.set(-1.0 + c * 1.0, 0.78, 1.05);
        stall.add(fruit);
      }
      scene.add(stall);
    }
  }

  // Parked private cars along the curb, as seen in the street reference photos.
  {
    const bodyMats = ["#f4f1ea", "#c7c4bc", "#8b9297", "#6b747b", "#b8a58d", "#263746"].map(
      (color) => new THREE.MeshStandardMaterial({ color, roughness: 0.58, metalness: 0.08 }),
    );
    const glassMat = new THREE.MeshStandardMaterial({ color: "#253c49", roughness: 0.22, metalness: 0.16 });
    const tireMat = new THREE.MeshStandardMaterial({ color: "#17191c", roughness: 0.88 });
    const lampMat = new THREE.MeshStandardMaterial({ color: "#f6e8bd", emissive: "#c6a66c", emissiveIntensity: 0.12 });
    for (let i = 0; i < 12; i++) {
      const sm = track.sample(105 + i * 176);
      const side = i % 2 === 0 ? -1 : 1;
      const car = new THREE.Group();
      car.position.set(
        sm.x + Math.cos(sm.yaw) * side * (ROAD_HALF - 1.15),
        0,
        sm.z - Math.sin(sm.yaw) * side * (ROAD_HALF - 1.15),
      );
      car.rotation.y = sm.yaw;
      const body = new THREE.Mesh(new THREE.BoxGeometry(1.72, 0.82, 4.05), bodyMats[i % bodyMats.length]);
      body.position.y = 0.72;
      const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.42, 0.76, 2.05), glassMat);
      cabin.position.set(0, 1.43, -0.12);
      car.add(body, cabin);
      for (const x of [-0.83, 0.83]) {
        for (const z of [-1.28, 1.28]) {
          const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.34, 0.34, 0.18, 10), tireMat);
          wheel.rotation.z = Math.PI / 2;
          wheel.position.set(x, 0.36, z);
          car.add(wheel);
        }
      }
      for (const x of [-0.55, 0.55]) {
        const headlamp = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.18, 0.06), lampMat);
        headlamp.position.set(x, 0.82, 2.04);
        car.add(headlamp);
      }
      scene.add(car);
    }
  }


  // Church compound confirmed on Fayoum Street. Exact frontage chainage is approximate
  // until a georeferenced street-level pin is available.
  {
    const p = spot(track.streetLength * 0.35, 16.2);
    const compound = new THREE.Group();
    compound.position.set(p.x, 0, p.z);
    compound.rotation.y = p.yaw + Math.PI / 2;
    const plaster = new THREE.MeshStandardMaterial({ color: "#e4d8c4", roughness: 0.86 });
    const trim = new THREE.MeshStandardMaterial({ color: "#b79d79", roughness: 0.78 });
    const roof = new THREE.MeshStandardMaterial({ color: "#8c8173", roughness: 0.82 });
    const glass = new THREE.MeshStandardMaterial({ color: "#426a78", roughness: 0.28, metalness: 0.12 });
    const main = new THREE.Mesh(new THREE.BoxGeometry(10.5, 8.2, 13), plaster);
    main.position.set(0, 4.1, 0);
    const naveRoof = new THREE.Mesh(new THREE.BoxGeometry(10.8, 0.5, 13.3), roof);
    naveRoof.position.set(0, 8.35, 0);
    const apse = new THREE.Mesh(new THREE.BoxGeometry(5.4, 5.2, 5.2), plaster);
    apse.position.set(0, 2.6, -8.8);
    const admin = new THREE.Mesh(new THREE.BoxGeometry(6.2, 5.6, 6.5), trim);
    admin.position.set(-9.1, 2.8, -1.2);
    const service = new THREE.Mesh(new THREE.BoxGeometry(6.8, 4.8, 6), plaster);
    service.position.set(9.0, 2.4, -1.5);
    compound.add(main, naveRoof, apse, admin, service);
    for (const x of [-3.4, 0, 3.4]) {
      const win = new THREE.Mesh(new THREE.BoxGeometry(1.15, 2.15, 0.14), glass);
      win.position.set(x, 4.5, 6.58);
      compound.add(win);
    }
    const door = new THREE.Mesh(new THREE.BoxGeometry(1.8, 3.2, 0.2), trim);
    door.position.set(0, 1.6, 6.62);
    compound.add(door);
    const arch = new THREE.Mesh(new THREE.TorusGeometry(1.0, 0.14, 8, 18, Math.PI), trim);
    arch.position.set(0, 3.35, 6.7);
    arch.rotation.z = Math.PI;
    compound.add(arch);
    const dome = new THREE.Mesh(new THREE.SphereGeometry(2.15, 16, 9, 0, Math.PI * 2, 0, Math.PI / 2), roof);
    dome.position.set(0, 8.55, -0.8);
    compound.add(dome);
    const tower = new THREE.Mesh(new THREE.BoxGeometry(2.2, 4.5, 2.2), trim);
    tower.position.set(4.1, 10.4, 3.8);
    const towerCap = new THREE.Mesh(new THREE.ConeGeometry(1.35, 1.8, 8), roof);
    towerCap.position.set(4.1, 13.55, 3.8);
    const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.22, 1.55, 0.22), dark);
    crossV.position.set(4.1, 15.15, 3.8);
    const crossH = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.22, 0.22), dark);
    crossH.position.set(4.1, 15.35, 3.8);
    compound.add(tower, towerCap, crossV, crossH);
    const signMap = shopTex("كنيسة مارمينا", "والقديس أغسطينوس", "#6b4b36", "#ffffff");
    if (signMap) {
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(8.5, 1.6), new THREE.MeshStandardMaterial({ map: signMap, side: THREE.DoubleSide }));
      sign.position.set(0, 6.65, 6.72);
      compound.add(sign);
    }
    scene.add(compound);
  }

  // Palm-lined frontage around the six-school complex, matching the documented planting.
  {
    const p = spot(track.stops[5].s, 17.2);
    const group = new THREE.Group();
    group.position.set(p.x, 0, p.z);
    group.rotation.y = p.yaw;
    const trunkMat = new THREE.MeshStandardMaterial({ color: "#765332", roughness: 0.92 });
    const leafMat = new THREE.MeshStandardMaterial({ color: "#2f673c", roughness: 0.82 });
    for (let i = 0; i < 7; i++) {
      const z = -18 + i * 6;
      const h = 4.4 + (i % 3) * 0.35;
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.27, h, 7), trunkMat);
      trunk.position.set(0, h / 2, z);
      group.add(trunk);
      for (let f = 0; f < 7; f++) {
        const leaf = new THREE.Mesh(new THREE.ConeGeometry(0.16, 3.2, 5), leafMat);
        const angle = (f / 7) * Math.PI * 2;
        leaf.position.set(Math.cos(angle) * 1.25, h + 0.45, z + Math.sin(angle) * 1.25);
        leaf.rotation.z = Math.cos(angle) * 0.72;
        leaf.rotation.x = Math.sin(angle) * 0.72;
        group.add(leaf);
      }
    }
    scene.add(group);
  }


  {
    const p = spot(track.stops[5].s, 22.5);
    const campus = new THREE.Group();
    campus.position.set(p.x, 0, p.z);
    campus.rotation.y = p.yaw + Math.PI / 2;
    const wallMat = new THREE.MeshStandardMaterial({ color: "#d9c7a6", roughness: 0.9 });
    const blue = new THREE.MeshStandardMaterial({ color: "#174c78", roughness: 0.7 });
    const windowMat = new THREE.MeshStandardMaterial({ color: "#52798a", roughness: 0.3, metalness: 0.1 });
    for (let i = 0; i < 4; i++) {
      const z = (i - 1.5) * 11;
      const block = new THREE.Mesh(new THREE.BoxGeometry(7.8, 6.2 + (i % 2) * 1.2, 8.4), wallMat);
      block.position.set(0, 3.1 + (i % 2) * 0.6, z);
      const fascia = new THREE.Mesh(new THREE.BoxGeometry(8, 0.55, 8.55), blue);
      fascia.position.set(0, 5.6 + (i % 2) * 1.2, z);
      campus.add(block, fascia);
      for (const zz of [z - 2.3, z, z + 2.3]) {
        const win = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.2, 1.25), windowMat);
        win.position.set(-3.96, 3.7, zz);
        campus.add(win);
      }
    }
    const fenceMat = new THREE.MeshStandardMaterial({ color: "#4b5359", roughness: 0.7, metalness: 0.25 });
    for (let i = 0; i < 17; i++) {
      const post = new THREE.Mesh(new THREE.BoxGeometry(0.12, 1.65, 0.12), fenceMat);
      post.position.set(-5.1, 0.82, -22 + i * 2.75);
      campus.add(post);
    }
    const rail = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 44), fenceMat);
    rail.position.set(-5.1, 1.45, 0);
    campus.add(rail);
    scene.add(campus);
  }


  // Dar El Salam post office, documented among the street's daily public services.
  {
    const p = spot(track.streetLength * 0.24, 13.8);
    const office = new THREE.Group();
    office.position.set(p.x, 0, p.z);
    office.rotation.y = p.yaw + Math.PI / 2;
    const wall = new THREE.MeshStandardMaterial({ color: "#d8c8ad", roughness: 0.88 });
    const redBand = new THREE.MeshStandardMaterial({ color: "#a83b32", roughness: 0.72 });
    const glass = new THREE.MeshStandardMaterial({ color: "#426a78", roughness: 0.28 });
    const block = new THREE.Mesh(new THREE.BoxGeometry(8.8, 5.2, 7.2), wall);
    block.position.y = 2.6;
    const band = new THREE.Mesh(new THREE.BoxGeometry(8.95, 0.72, 7.35), redBand);
    band.position.y = 4.2;
    const door = new THREE.Mesh(new THREE.BoxGeometry(1.5, 2.7, 0.14), dark);
    door.position.set(0, 1.35, 3.65);
    const win = new THREE.Mesh(new THREE.BoxGeometry(2.1, 1.45, 0.14), glass);
    win.position.set(-2.5, 3.0, 3.65);
    const signMap = shopTex("مكتب بريد دار السلام", "خدمات بريدية", "#a83b32", "#ffffff");
    office.add(block, band, door, win);
    if (signMap) {
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(6.8, 1.25), new THREE.MeshStandardMaterial({ map: signMap, side: THREE.DoubleSide }));
      sign.position.set(0, 4.95, 3.72);
      office.add(sign);
    }
    scene.add(office);
  }

  // Traffic unit at the school complex, with a small blue-and-white booth.
  {
    const p = spot(track.stops[5].s, 16.5);
    const unit = new THREE.Group();
    unit.position.set(p.x, 0, p.z);
    unit.rotation.y = p.yaw + Math.PI / 2;
    const booth = new THREE.Mesh(new THREE.BoxGeometry(2.8, 2.8, 2.5), white);
    booth.position.y = 1.4;
    const roof = new THREE.Mesh(new THREE.BoxGeometry(3.0, 0.28, 2.7), dark);
    roof.position.y = 2.85;
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(2.84, 0.52, 2.55), new THREE.MeshStandardMaterial({ color: "#174c78", roughness: 0.65 }));
    stripe.position.y = 2.0;
    const window = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.8, 1.15), teal);
    window.position.set(-1.42, 1.65, 0);
    unit.add(booth, roof, stripe, window);
    const signMap = shopTex("وحدة مرور", "دار السلام", "#174c78", "#ffffff");
    if (signMap) {
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.7, 0.9), new THREE.MeshStandardMaterial({ map: signMap, side: THREE.DoubleSide }));
      sign.position.set(-1.48, 2.75, 0);
      sign.rotation.y = -Math.PI / 2;
      unit.add(sign);
    }
    scene.add(unit);
  }

  // Informal minibus terminus at Al-Mala'a, the documented end-of-street stand.
  {
    const p = spot(track.stops[9].s, 18.2);
    const stand = new THREE.Group();
    stand.position.set(p.x, 0, p.z);
    stand.rotation.y = p.yaw + Math.PI / 2;
    const canopy = new THREE.Mesh(new THREE.BoxGeometry(5.8, 0.18, 10.5), new THREE.MeshStandardMaterial({ color: "#d9d4c9", roughness: 0.82 }));
    canopy.position.set(0, 3.0, 0);
    const postMat = new THREE.MeshStandardMaterial({ color: "#686d70", roughness: 0.7, metalness: 0.2 });
    for (const x of [-2.65, 2.65]) {
      for (const z of [-4.7, 4.7]) {
        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.08, 3, 7), postMat);
        post.position.set(x, 1.5, z);
        stand.add(post);
      }
    }
    const signMap = shopTex("موقف الميكروباصات", "منطقة الملاءة", "#174c78", "#ffffff");
    if (signMap) {
      const sign = new THREE.Mesh(new THREE.PlaneGeometry(5.6, 1.35), new THREE.MeshStandardMaterial({ map: signMap, side: THREE.DoubleSide }));
      sign.position.set(0, 3.9, 5.2);
      stand.add(sign);
    }
    for (let i = 0; i < 3; i++) {
      const van = new THREE.Group();
      const body = new THREE.Mesh(new THREE.BoxGeometry(1.9, 1.8, 4.4), new THREE.MeshStandardMaterial({ color: ["#f1eee5", "#d8d8d2", "#e5e0d4"][i], roughness: 0.6 }));
      body.position.y = 1.0;
      const glass = new THREE.Mesh(new THREE.BoxGeometry(1.65, 0.68, 1.65), new THREE.MeshStandardMaterial({ color: "#496674", roughness: 0.25, metalness: 0.12 }));
      glass.position.set(0, 1.78, -0.35);
      van.add(body, glass);
      van.position.set((i - 1) * 2.2, 0, -7.2);
      stand.add(van);
    }
    stand.add(canopy);
    scene.add(stand);
  }

  const bumpMat = new THREE.MeshStandardMaterial({ map: bumpTexture() ?? undefined, roughness: 0.55 });
  for (const b of track.bumps) {
    const sm = track.sample(b);
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(13.5, 0.16, 0.9), bumpMat);
    mesh.position.set(sm.x, 0.09, sm.z);
    mesh.rotation.y = sm.yaw;
    scene.add(mesh);
  }

  // denser Egyptian palm / street trees
  const trunkMat = new THREE.MeshStandardMaterial({ color: "#6b4a2b", roughness: 0.9 });
  const leafMat = new THREE.MeshStandardMaterial({ color: "#2f5a38", roughness: 0.75 });
  const leafMat2 = new THREE.MeshStandardMaterial({ color: "#3d7a48", roughness: 0.8 });
  for (let t = 0.01; t < 0.99; t += 0.045) {
    const side = (Math.floor(t * 100) % 2 === 0) ? 1 : -1;
    const lat = 18 + (t * 37) % 6;
    const p = spot(track.total * t, side * lat);
    const h = 2.8 + (t * 50) % 1.6;
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.22, h, 7), trunkMat);
    trunk.position.set(p.x, h / 2, p.z);
    // layered palm crown
    const crown1 = new THREE.Mesh(new THREE.SphereGeometry(1.05 + (t % 0.3), 7, 5), leafMat);
    crown1.position.set(p.x, h + 0.3, p.z);
    crown1.scale.set(1.15, 0.7, 1.15);
    const crown2 = new THREE.Mesh(new THREE.SphereGeometry(0.85, 6, 5), leafMat2);
    crown2.position.set(p.x + 0.25, h + 0.55, p.z - 0.15);
    crown2.scale.set(1.1, 0.55, 1.1);
    scene.add(trunk, crown1, crown2);
  }
}

export function buildPosts(scene: THREE.Scene, track: Track) {
  const metal = new THREE.MeshStandardMaterial({ color: "#c5ccd3", roughness: 0.45, metalness: 0.25 });
  const cam = new THREE.MeshStandardMaterial({ color: "#f0b429", emissive: "#f0b429", emissiveIntensity: 0.35 });
  const boothMat = new THREE.MeshStandardMaterial({ color: "#1d4e89", roughness: 0.6 });
  const addCam = (s: number) => {
    const sm = track.sample(s);
    const rx = Math.cos(sm.yaw);
    const rz = -Math.sin(sm.yaw);
    const g = new THREE.Group();
    g.position.set(sm.x + rx * 10.6, 0, sm.z + rz * 10.6);
    g.rotation.y = sm.yaw;
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 4.4, 6), metal);
    pole.position.y = 2.2;
    const eye = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.22, 0.45), cam);
    eye.position.set(-0.2, 4.2, 0);
    g.add(pole, eye);
    scene.add(g);
  };
  for (const s of track.radarS) addCam(s);
  const sm = track.sample(track.tollS);
  const rx = Math.cos(sm.yaw);
  const rz = -Math.sin(sm.yaw);
  const booth = new THREE.Mesh(new THREE.BoxGeometry(1.6, 2.2, 1.6), boothMat);
  booth.position.set(sm.x + rx * 9.4, 1.1, sm.z + rz * 9.4);
  booth.rotation.y = sm.yaw;
  scene.add(booth);
}

/** More realistic low-poly Egyptian pedestrians with arms, variety & density */
export function placePeople(scene: THREE.Scene, track: Track) {
  const skins = ["#c49a78", "#a87b5c", "#d4b48c", "#8d6e4a", "#b08968", "#e0b896"].map(
    (c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.68 }),
  );
  const shirts = [
    "#1e3a5f", "#2d5a3d", "#8b3a2a", "#3a3a4a", "#c45c3e", "#1aa6a6",
    "#f0b429", "#ffffff", "#e8e0d2", "#4a6741", "#6b2d5c", "#2c3e50",
  ].map((c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.72 }));
  const pants = ["#2a2e35", "#3d4450", "#1a1e24", "#4a3f35", "#5c4033", "#1c2833"].map(
    (c) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.8 }),
  );

  const bodyGeo = new THREE.CapsuleGeometry(0.17, 0.42, 4, 6);
  const headGeo = new THREE.SphereGeometry(0.125, 8, 6);
  const legGeo = new THREE.CapsuleGeometry(0.065, 0.38, 3, 5);
  const armGeo = new THREE.CapsuleGeometry(0.045, 0.28, 3, 5);

  // denser placement along the track
  for (let i = 0; i < track.pts.length; i += 4) {
    const p = track.pts[i];
    const hsh = Math.abs(Math.sin(i * 7.13 + 1.7) * 43758.5453) % 1;
    if (hsh < 0.12) continue;

    const side = hsh > 0.55 ? 1 : -1;
    const rx = Math.cos(p.yaw);
    const rz = -Math.sin(p.yaw);
    const lateral = ROAD_HALF + 2.55 + (hsh % 0.55) * 1.4;
    const g = new THREE.Group();
    g.position.set(p.x + rx * side * lateral, 0, p.z + rz * side * lateral);
    // face along or against traffic randomly
    g.rotation.y = p.yaw + (hsh - 0.5) * 0.9 + (side > 0 ? Math.PI : 0) + (hsh > 0.75 ? Math.PI * 0.5 : 0);

    const scale = 0.88 + (hsh % 0.25); // height variation
    g.scale.set(scale, scale, scale);

    const skin = skins[i % skins.length];
    const shirt = shirts[i % shirts.length];
    const pant = pants[i % pants.length];

    // torso
    const torso = new THREE.Mesh(bodyGeo, shirt);
    torso.position.y = 1.02;
    // head
    const head = new THREE.Mesh(headGeo, skin);
    head.position.y = 1.48;
    // legs slightly apart / walking pose
    const legL = new THREE.Mesh(legGeo, pant);
    legL.position.set(-0.09, 0.38, hsh > 0.5 ? 0.06 : -0.04);
    legL.rotation.x = hsh > 0.5 ? 0.15 : -0.12;
    const legR = new THREE.Mesh(legGeo, pant);
    legR.position.set(0.09, 0.38, hsh > 0.5 ? -0.05 : 0.05);
    legR.rotation.x = hsh > 0.5 ? -0.12 : 0.15;
    // arms
    const armL = new THREE.Mesh(armGeo, shirt);
    armL.position.set(-0.26, 1.05, 0);
    armL.rotation.z = 0.35 + (hsh % 0.3);
    armL.rotation.x = (hsh - 0.5) * 0.4;
    const armR = new THREE.Mesh(armGeo, shirt);
    armR.position.set(0.26, 1.05, 0);
    armR.rotation.z = -0.35 - (hsh % 0.25);
    armR.rotation.x = (0.5 - hsh) * 0.4;

    g.add(torso, head, legL, legR, armL, armR);
    scene.add(g);

    // occasional second person nearby (group / talking)
    if (hsh > 0.72 && i % 3 === 0) {
      const g2 = g.clone();
      g2.position.x += rx * side * 0.7 + rz * 0.55;
      g2.position.z += rz * side * 0.7 - rx * 0.55;
      g2.rotation.y += 0.6;
      g2.scale.setScalar(0.92 + (hsh % 0.15));
      scene.add(g2);
    }
  }

  // Extra parent/student groups at the school exits during the daytime route.
  for (let j = 0; j < 28; j++) {
    const stop = track.stops[j % 2 === 0 ? 5 : 6];
    const sm = track.sample(stop.s + ((j % 7) - 3) * 2.1);
    const side = j % 2 === 0 ? 1 : -1;
    const rx = Math.cos(sm.yaw);
    const rz = -Math.sin(sm.yaw);
    const h = Math.abs(Math.sin(j * 8.31) * 43758.5453) % 1;
    const person = new THREE.Group();
    person.position.set(sm.x + rx * side * (ROAD_HALF + 3.1 + (j % 3) * 0.65), 0, sm.z + rz * side * (ROAD_HALF + 3.1 + (j % 3) * 0.65));
    person.rotation.y = sm.yaw + (side > 0 ? Math.PI : 0) + (h - 0.5) * 0.8;
    const scale = j % 4 === 0 ? 0.72 : 0.92 + h * 0.12;
    person.scale.setScalar(scale);
    const torso = new THREE.Mesh(bodyGeo, shirts[(j + 3) % shirts.length]);
    torso.position.y = 1.02;
    const head = new THREE.Mesh(headGeo, skins[(j + 2) % skins.length]);
    head.position.y = 1.48;
    const legL = new THREE.Mesh(legGeo, pants[j % pants.length]);
    legL.position.set(-0.09, 0.38, 0.04);
    const legR = new THREE.Mesh(legGeo, pants[(j + 1) % pants.length]);
    legR.position.set(0.09, 0.38, -0.04);
    const armL = new THREE.Mesh(armGeo, shirts[(j + 3) % shirts.length]);
    armL.position.set(-0.26, 1.05, 0);
    armL.rotation.z = 0.28;
    const armR = new THREE.Mesh(armGeo, shirts[(j + 3) % shirts.length]);
    armR.position.set(0.26, 1.05, 0);
    armR.rotation.z = -0.28;
    person.add(torso, head, legL, legR, armL, armR);
    scene.add(person);
  }

}
