import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { DarSalam } from "@/components/dar-salam";
import "@/styles.css";

const root = document.getElementById("root");
if (root) createRoot(root).render(<StrictMode><DarSalam /></StrictMode>);
